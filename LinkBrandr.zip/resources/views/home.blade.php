@extends('www.layouts.main')

@section('content')
    <section class="features-section" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-heading">{!! $page_heading !!}</div>

                        <div class="panel-body">
                            {!!   $html !!}
                        </div>

                        <div class="panel-body">
                            <h3>Pages</h3>
                            <ul>
                                <li><a href="/branding/edit-profile">Edit Brandr Profile</a> </li>
                                <li><a href="/share-link/createLink">Add Link to Share</a> </li>
                                <li><a href="{{ str_replace("https","http",url('/')) }}/share-link/listing">List Shared Links</a> </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@extends('admin.layouts.app')

@section('body-content-custom')

    <div class="row">

        <div class="col-lg-4 col-md-6 col-sm-12 clearfix">
            <div class="main-box">
                <div class="listing_cont" style="height: 184px;">
                    <div class="main-box-header clearfix">
                        <h4>Public User Management</h4>
                    </div>

                    <div class="main-box-body clearfix">
                        <p class="listing">
                            <a href="/users/userListing">User Listing</a><br>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection

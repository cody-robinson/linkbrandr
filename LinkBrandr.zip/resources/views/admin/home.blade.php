@extends('admin.layouts.app')

@section('body-content')
    {!! $html !!}
@endsection

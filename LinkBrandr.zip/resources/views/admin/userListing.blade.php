@extends('admin.layouts.app')

@section('body-title', 'User Listing')

@section('body-content')
    <!-- this project rolls it's own user management system
    add some basic styles/scripts to utilize data tables -->
    <style>
        .no-sort:after {
            content: '' !important;
        }
    </style>
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th class="no-sort">Username</th>
                <th class="no-sort">Full Name</th>
                <th class="no-sort">Account Status</th>
                <th class="no-sort">Business Name</th>
                <th class="no-sort">Sign-up Date</th>
                <th class="no-sort"></th>
            </tr>
            </thead>
            <tbody>
            @foreach ($UsersInfo as $UserInfo)
                <tr>
                    <td><a href="/users/user-profile/{{ $UserInfo->ID }}">@if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail) {{ $UserInfo->Person->PrimaryEmail }} @elseif(is_numeric($UserInfo->Username) && !$UserInfo->Person->PrimaryEmail) {{ $UserInfo->Username }} @else{{ $UserInfo->Username }}@endif</a></td>
                    <td>
                        {{ $UserInfo->FullName }}
                    </td>
                    <td>
                        @if($UserInfo->UserProfile)
                            @if($UserInfo->UserProfile->IsPaidSubscription==1) <strong class="text-success">Paid</strong>
                            @else <strong class="text-danger">Trial</strong>
                            @endif
                            and
                            @if(strtotime($UserInfo->UserProfile->AccountExpiryDate) < time() ) <strong class="text-danger">Expired</strong>
                            @else <strong class="text-success">Active</strong>
                            @endif
                        @else
                            No Profile Created
                        @endif
                    </td>
                    <td>@if($UserInfo->UserProfile){{ $UserInfo->UserProfile->BusinessName }} @else No Profile Created @endif</td>
                    <td>{{ $UserInfo->SignupDate }}</td>
                    <td><a href="/users/delete-user/{{ $UserInfo->ID }}" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a></td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('.table').DataTable( {
                "iDisplayLength": 50,
                "bLengthChange": true,
                searching: false
            } );
        } );
    </script>

@endsection

@extends('admin.layouts.app')
{{ UI::includeScript('https://code.jquery.com/ui/1.12.1/jquery-ui.js') }}
{{ UI::includeStylesheet('https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css') }}
{{ UI::includeScript(common_path('scripts/form/field-element.js')) }}


@section('body-content-custom')

    <div class="main-box clearfix">
        <div class="main-box-header">
            <h2>{!! $PageHeading !!}</h2>
            @if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail)
                <p>This user signed up with Facebook.</p>
            @elseif(is_numeric($UserInfo->Username) && !$UserInfo->Person->PrimaryEmail)
                <p>This user signed up with Facebook and withheld access to some of their information, including their email.</p>
            @endif
        </div>
        <div class="main-box-body">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    @if($UserInfo->UserProfile)
                    <th>Location</th>
                    <th>Birthday</th>
                    <th>Gender</th>
                    @endif
                    <th>Username</th>
                    <th>Business Name</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{ $UserInfo->Person->FirstName }}</td>
                        <td>{{ $UserInfo->Person->LastName }}</td>
                        @if($UserInfo->UserProfile)
                        <td>{{ $UserInfo->UserProfile->Location }}</td>
                        <td>{{ $UserInfo->UserProfile->Birthday }}</td>
                        <td>{{ $UserInfo->UserProfile->Gender }}</td>
                        @endif
                        <td>@if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail) {{ $UserInfo->Person->PrimaryEmail }} @else{{ $UserInfo->Username }}@endif</td>
                        <td>@if($UserInfo->UserProfile){{ $UserInfo->UserProfile->BusinessName }} @else No Profile Created @endif</td>
                    </tr>
                </tbody>
            </table>

        <div class="main-box-header">
            <h2>Subscription Info</h2>
        </div>

            <p><strong>Subscription Status: </strong>
                @if($UserInfo->UserProfile)
                    @if($UserInfo->UserProfile->IsPaidSubscription==1) <strong class="text-success">Paid</strong>
                    @else <strong class="text-danger">Trial</strong>
                    @endif
                    and
                    @if(strtotime($UserInfo->UserProfile->AccountExpiryDate) < time() ) <strong class="text-danger">Expired</strong>
                    @else <strong class="text-success">Active</strong>
                    @endif
                @else
                    No Profile Created
                @endif
            </p>
            <p><strong>Subscription Expiry Date: </strong>
                @if($UserInfo->UserProfile) {{ date("M d, Y",strtotime($UserInfo->UserProfile->AccountExpiryDate)) }}
                @else
                    No Profile Created
                @endif
            </p>

            @if($UserInfo->UserProfile) <p class="form-inline"><strong>Reset Expiry Date to: </strong><input type="text" id="subscriptionDatePicker" class="form-control" style="width:200px; display:inline-block"> <input type="button" class="btn btn-default" value="Update" id="expiryUpdateButton" /></p> @endif

        <div class="main-box-header">
            <h2>Links This User Shared</h2>
        </div>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th>URL</th>
                    <th>Share Type</th>
                    <th>Slug</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($UserInfo->SharedLinks as $Links)
                    <tr>
                        <td>{{ $Links->Link }}</td>
                        <td>{{ $Links->ShareType }}</td>
                        <td>{{ $Links->Slug }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>

    @if($UserInfo->UserProfile)
    <script>


	$('#subscriptionDatePicker').datepicker({
		dateFormat: 'yy-mm-dd'
	});
	$('#subscriptionDatePicker').datepicker('setDate',new Date('{{ $UserInfo->UserProfile->AccountExpiryDate }}'));

	$('#expiryUpdateButton').on('click',function(){
        var newDate = $('#subscriptionDatePicker').val();
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:"/users/expiry-update/{{ $UserInfo->UserProfile->ID }}",
            data:{date:newDate,  _token: CSRF_TOKEN},
			type: 'POST',
            dataType:"JSON",
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN,
			},
			cache:false,
			success: function(response) {
                if(response.result != false){
                	window.location.reload();
                }
                else{
                	console.log(response);
                }
			}
        });
    });
    </script>
    @endif

@endsection

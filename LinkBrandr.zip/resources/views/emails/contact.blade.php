Mitchell,

<p>There has been a new LinkBrandr contact form submission.</p>

From: {{ $Name }}<br>
Email: {{ $Email }}<br>
Message: {{ $Message }}
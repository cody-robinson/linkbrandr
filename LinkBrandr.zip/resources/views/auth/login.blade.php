@extends('www.layouts.main')

@section('content')
    <section id="login-section" class="form-section section">
        <div class="section-inner">
            <div class="container text-center">
                <div class="space-50"></div>
                <h2 class="counter-desc">Log In</h2>
                <br>
                <div class="form-wrapper">
                    <div class="form-box">

                        <form class="form-horizontal" role="form" method="POST" action="{{ url('/login') }}">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="form-group col-sm-12">
                                    <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                                </div>

                                @if (isset($existingAccountAlert))
                                    <div class="alert alert-danger existing-account">
                                        <i class="fa fa-warning fa-fw fa-lg"></i>
                                        {!! $existingAccountAlert !!}
                                        <br>
                                        <a href="" class="btn btn-danger">Use Existing Account</a>
                                        <a href="" class="btn btn-danger">Create New Account</a>
                                    </div>
                                @endif

                                <div class="form-group col-sm-12">
                                    <div class="divider">
                                        <span class="or-text">OR</span>
                                    </div><!--//divider-->
                                </div>

                                <div class="col-sm-3"></div>
                                <div class="form-group {{ $errors->has('email') ? ' has-error' : '' }} col-sm-6 col-xs-12">
                                    <input id="email" type="text" class="form-control" name="email" value="{{ old('email') }}" placeholder="Email address">

                                    @if ($errors->has('email'))
                                        <span class="help-block">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                                    @endif
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }} col-sm-6 col-xs-12">
                                    <input id="password" type="password" class="form-control" name="password" placeholder="Password">

                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                                                    <strong>{{ $errors->first('password') }}</strong>
                                                                </span>
                                    @endif
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="form-group col-sm-12">
                                    <div class="checkbox">
                                        <input type="checkbox" name="remember"> Remember Me
                                    </div>
                                </div>
                                <div class="form-group col-sm-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-sign-in"></i> Login
                                    </button>
                                </div>
                                <div class="form-group col-sm-12">
                                    <a class="btn btn-link" href="{{ url('/password/reset') }}">Forgot Your Password?</a>
                                </div>
                                <div class="form-group col-sm-12">
                                    <a href="/register" class="btn btn-primary"><i class="fa fa-btn fa-sign-in"></i> Sign Up</a>
                                </div>
                            </div>
                        </form>

                    </div><!--//form-box-->
                </div><!--//form-wrapper-->

            </div><!--//container-->
        </div><!--//section-inner-->
    </section>
@endsection

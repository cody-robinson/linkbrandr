@extends('www.layouts.main')

@section('content')
<section id="add-link-section" class="section form-section">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel">
                    <div class="panel-heading">
                        <h1>{!! $page_heading !!}</h1>
                        <h2>Client Dashboard / Add New Link</h2>
                    </div>
                </div>
                <br>
                <div class="panel panel-default">
                    <div class="panel-heading">

                    </div>

                    <div class="panel-body">
                        {!! form_open($form) !!}

                        <div class="form-group">
                        {!! form_element($form['Link'],['widget'=>['placeholder'=>'ex. www.linkbrandr.com']]) !!}
                        {!! form_element($form['LBRUserProfiles_ID']) !!}
                        </div>

                        <div class="form-group">
                            <input type="hidden" name="UserID" value="{!! $userID !!}" />
                            <input type="submit" value="Save" class="btn btn-primary"/>
                        </div>

                        {!! form_close($form) !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@extends('www.layouts.publicViewapp')

@section('content')

    <!-- if button isn't set, make whole bar a link -->
    @if (!empty($user->ProfileURL))
        <a href="{!! $user->ProfileURL !!}" class="brandr-wrapper" target="_blank">
    @endif

    <!-- theme changes by adding class theme-one, theme-two, or theme-three -->
    <table class="brandr-bar {!! $CSSClassName !!}" style="background-color: {!! $BackgroundColor !!}">
        <tbody>
        <tr>
            <td class="branding" style="width: 20%;">
                <table style="@if ($CSSClassName != 'theme-one') background-color: {!! $ButtonColor !!} @endif">
                    <tbody>
                    <tr>
                        <td>
                            @if (!empty($user->ProfileImage))
                                <div class="image-cropper @if ($user->ImageType == 'Headshot')with-crop @elseif($user->ImageType == 'Logo')no-crop @endif @if ($user->ImageOrientation == 'landscape')landscape @elseif($user->ImageOrientation == 'portrait')portrait @endif">
                                    <img src="{!! url('/public/uploads/profile-images/'.$user->ID.".".pathinfo($user->ProfileImage, PATHINFO_EXTENSION))  !!}?avoidCache={!! $user->LastModified !!}"/>
                                </div>
                            @else
                                <div class="space"></div>
                            @endif
                        </td>

                        <td class="client-details @if (empty($user->BusinessName) && empty($user->BusinessDescription))empty @endif">
                            <h1 class="name" @if ($CSSClassName == 'theme-one') style="color: {!! $ButtonColor !!}" @endif>{!! $user->BusinessName !!}</h1>
                            <h2 class="title">@if (!empty($user->BusinessDescription)){!! $user->BusinessDescription !!}@endif</h2>
                            <i class="fa fa-caret-right" style="@if ($CSSClassName == 'theme-two') color: {!! $ButtonColor !!} @endif"></i>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>

            <td class="tagline" style="width: 60%;">
                @if (!empty($user->Headline))
                    <p>{!! $user->Headline !!}</p>
                @endif
            </td>

            <td class="contact-button" style="width: 20%;">
                @if (!empty($user->ButtonText) && !empty($user->ProfileURL))
                    <a href="{!! $user->ProfileURL !!}" class="btn btn-default get-in-touch" style="@if ($CSSClassName == 'theme-one') background-color: {!! $ButtonColor !!}; @endif @if ($CSSClassName == 'theme-two') border-color: {!! $ButtonColor !!}; @endif" target="_blank">{!! $user->ButtonText !!}</a>
                @endif
            </td>

        </tr>
        </tbody>
    </table>
    <div class="spacer"></div>

    @if (!empty($user->ProfileURL))
        </a>
    @endif

    <div class="iframe-wrapper">
        <iframe frameborder="0" class="iframe" src="" id="sharedLinkIframe" data-url="{!! $sharedLink !!}"></iframe>
    </div>

<script>
	function setIframeSrc() {
		var iframe = document.getElementById('sharedLinkIframe');
		var s = iframe.getAttribute('data-url');

		if ( -1 == navigator.userAgent.indexOf("MSIE") ) {
			iframe.src = s;
		}
		else {
			iframe.location = s;
		}
	}
	window.onload = function(){
        setIframeSrc();
        checkDeviceType();

        // only want to apply overflow hidden to html of iframe page
        $('html').css("overflow", "hidden");
	};

    function checkDeviceType(){

        var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
        if (iOS) {
            $("#sharedLinkIframe").attr('scrolling', 'no');
        } else {
            $("#sharedLinkIframe").attr('scrolling', 'yes');
        }
    }
</script>

@endsection
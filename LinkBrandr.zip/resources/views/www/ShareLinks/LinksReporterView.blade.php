@extends('www.layouts.dashboard')

@section('content')

    <!-- New Link Modal -->
    <div class="modal fade" id="newLinkModal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">New Link</h4>
                </div>
                <div class="modal-body" id="shareLinkForm">
                    {!! form_open($form) !!}

                    <div class="form-group">
                        <label>Paste the URL of the link you want to share.</label>
                        {!! form_element($form['Link'],['widget'=>['placeholder'=>'ex. http://www.businessinsider.com/benefits-of-going']]) !!}
                        <span id="link-error" style="color:darkred"></span>
                        <!-- hidden input to pass amp url -->
                        <input type="hidden" id="amp-url" name="AmpUrl">
                        {!! form_element($form['LBRUserProfiles_ID']) !!}
                    </div>

                    <div class="form-group text-center">
                        <input type="hidden" name="UserID" value="{!! $userID !!}" />
                        <input type="submit" value="Generate branded link" class="btn btn-primary" onclick="validateCreateLink();"/>
                    </div>

                    {!! form_close($form) !!}
                </div>
            </div>

        </div>
    </div>

    <section id="link-listing-section" class="link-listing-section section">

        <div class="section-inner">
            <div class="fixed-create-link-container">
                <div class="fixed-create-link">
                    <div class="row">
                        <!--<div class="col-md-4">
                            <div class="total-links">
                                @php
                                    $totalLinks = count($sharedLinks);
                                @endphp

                               <p>{{ $totalLinks }} links</p>
                            </div>
                        </div> -->
                        <div class="col-md-12">
                            <div class="right trial-msg">
                                @if($daysToExpire!=null && !$isPaidAccount && !$isStripeCustomer)<a href="/subscription">You have {!! $daysToExpire !!} days left in your free trial, click here to add your payment details now.</a>@endif
                                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#newLinkModal">Create New Link</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <article class="tabbed-content tabs-side">
                <div class="row">
                    <div class="col-md-4">
                        <div id="listing-sidebar">
                            @if( $totalLinks == 0)
                                <div class="listing-item get-started">
                                    <br>
                                    <h5>Once you have shared some links, they will be listed here.</h5>
                                    <br>
                                    <button type="button" class="btn btn-lg" data-toggle="modal" data-target="#newLinkModal">Add Your First Link</button>
                                </div>
                            @else
                                <nav class="tabs">
                                    <ul>
                                        @foreach ($sharedLinks as $link)
                                            <li class="listing-item" onclick="makeActiveLink(this)">
                                                <a href="#side_tab_{{ $link->ID }}">
                                                    <div class="preview-content">
                                                        <input type="hidden" name="link-id" value="{{ $link->ID }}" />
                                                        <p class="date-added">
                                                            <span> {{ date('F d, Y', strtotime($link->DateAdded)) }}</span>
                                                        </p>
                                                        <h2>{{ $link->Title }}</h2>
                                                    </div>
                                                    <div class="link-meta" style="display: none;">
                                                        <a href="/share-link/delete-link/{!! $link->ID !!}" class="delete-btn">Delete</a>
                                                    </div>
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </nav>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-8">
                    <div class="link-details-container">

                    @if( $totalLinks == 0)
                        <div class="get-started">
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-5 col-sm-12">
                                    <h5>Congratulations, you're now ready to create your first branded link!</h5><br>

                                    <h5>Click this button and paste the URL of the link you'd like to share. Your branding will be added automatically!</h5>
                                </div>
                                <div class="col-md-3">
                                    <img class="arrow" src="/public/images/red-arrow.png">
                                </div>
                            </div>
                        </div>
                    @endif
                    @foreach ($sharedLinks as $link)
                        <div id="side_tab_{{ $link->ID }}" class="item" data-title="Tab 1">
                            <div class="mobile-only" style="display: none;">
                                <h3 class="date-added">{{ date('F d, Y', strtotime($link->DateAdded)) }}</h3>
                                <h3 class="title">{{ $link->Title }}</h3>
                            </div>
                                <div class="item-content extra-details">
                                    <div class="dog-ear"></div>
                                    <div class="link-meta">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h3 class="date-added">{{ date('F d, Y', strtotime($link->DateAdded)) }}</h3>
                                                <h3 class="title">{{ $link->Title }}</h3>
                                                <h3 class="link">{{ str_limit($link->Link, $limit = 50, $end = '...') }}</h3>
                                            </div>
                                        </div>
                                    </div>

                                    <hr>

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="share">
                                                <div class="row">
                                                    <div class="col-lg-9">
                                                        <h3 class="branding">Select your Branding: </h3>

                                                        <label @if($link->IsIframeSupported == "0") style="color: #dde0e2;" @endif>
                                                            <input type="radio" class="share-type-btn" value="iframe" @if ($link->ShareType == 'iframe') checked="checked" @endif
                                                            name="sharetype-{!! $link->ID !!}" @if($link->IsIframeSupported == "0") disabled @endif/>
                                                            Brandr Bar
                                                        </label>
                                                        <label>
                                                            <input type="radio" class="share-type-btn" value="splash" @if ($link->ShareType == 'splash') checked="checked" @endif name="sharetype-{!! $link->ID !!}"/>
                                                            Redirect Page
                                                        </label>
                                                        <label @if($link->IsIframeSupported == "0") style="color: #dde0e2;" @endif>
                                                            <input type="radio" class="share-type-btn" value="both" @if ($link->ShareType == 'both') checked="checked" @endif
                                                            name="sharetype-{!! $link->ID !!}" @if($link->IsIframeSupported == "0") disabled @endif/>
                                                            Both
                                                        </label><br>
                                                        @if($link->IsIframeSupported == "0")
                                                            <p class="smaller">*This link does not support the Brandr Bar.</p>
                                                        @endif
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <a id="preview-link-{{ $link->ID }}" href="@if ($shortUrl == 'lbdr.co')http://lbdr.co/@else{!! url('/link') !!}/@endif{{ $link->Slug }}" class="preview-btn" target="_blank">Preview Link</a>
                                                    </div>
                                                </div>


                                                <h3 class="share">Share your Branded link:</h3>

                                                <!-- facebook share -->
                                                <a class="btn btn-primary btn-rounded fb" href="http://www.facebook.com/share.php?u=@if($shortUrl == 'lbdr.co')http://lbdr.co/{{ $link->Slug }} @else{!! url('/link/') !!}/{{ $link->Slug }}@endif" target="_blank">
                                                    <i class="fa fa-facebook"></i> Facebook
                                                </a>
                                                <!-- twitter share -->
                                                <a class="btn btn-primary btn-rounded tw" href="https://twitter.com/share?url=@if($shortUrl == 'lbdr.co')http://lbdr.co/{{ $link->Slug }} @else{!! url('/link/') !!}/{{ $link->Slug }}@endif" target="_blank">
                                                    <i class="fa fa-twitter"></i> Twitter
                                                </a>
                                                <!-- linkedin share-->
                                                <a class="btn btn-primary btn-rounded li" href="http://www.linkedin.com/shareArticle?mini=true&url=@if($shortUrl == 'lbdr.co')http://lbdr.co/{{ $link->Slug }} @else{!! url('/link/') !!}/{{ $link->Slug }}@endif" target="_blank">
                                                    <i class="fa fa-linkedin"></i> LinkedIn
                                                </a>

                                                <div class="copy-link">
                                                    <!-- if else statements are super picky about whitespace, need to leave this syntax as is -->
                                                    <a id='full-url-link-wrapper-{!! $link->ID !!}' class='full-url-link-wrapper' href="@if ($shortUrl == 'lbdr.co')http://lbdr.co/@else{!! url('/link') !!}/@endif{{ $link->Slug }}" target="_blank">
                                                        <p id="fullurl-{!! $link->ID !!}" class="full-url" data-url="@if($shortUrl == 'lbdr.co')http://lbdr.co/{{ $link->Slug }} @else{!! url('/link/') !!}/{{ $link->Slug }}@endif">
                                                            @if($shortUrl == 'lbdr.co')
                                                                http://lbdr.co/<span id="link-slug-{!! $link->ID !!}">{{ $link->Slug }}</span>@else
                                                                {!! url('/link') !!}/<span id="link-slug-{!! $link->ID !!}">{{ $link->Slug }}</span>@endif
                                                        </p>
                                                    </a>
                                                    <input type="text" id="shareslug-{!! $link->ID !!}" class="slug-url-input" value="{{ $link->Slug }}" style="display: none;"/>
                                                    <span id="error-shareslug-{!! $link->ID !!}" class="slug-error-msg"></span>
                                                    <button class="btn save-slug-btn btn-primary btn-sm" id="{!! $link->ID !!}" style="display: none;">Save</button>

                                                    <button class="btn copy-url btn btn-primary btn-sm" id="slug-copy-{!! $link->ID !!}" data-clipboard-text="@if ($shortUrl == 'lbdr.co')http://lbdr.co/@else{!! url('/link') !!}/@endif{{ $link->Slug }}">Copy short-link</button>
                                                    <button class="btn update-slug-btn btn btn-primary btn-sm" id="update-slug-{!! $link->ID !!}" onclick="showSlugInput(this)">Customize short-link</button>
                                                </div>

                                                <a href="/share-link/delete-link/{!! $link->ID !!}" class="delete-btn delete-mobile-only" style="display: none;" onclick="return confirm('Are you sure you want to delete this link?');">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    </div>
                </div>
            </article>

        </div>
    </section>

    <script src="/public/js/clipboard.min.js"></script>
    <script>

		// set nav to full width on this page only
		(function(){
			$('nav div.container').css({
				'width' : '100%',
				'padding' : '0 20px'
			});
		})();

		//copy url button
		var clipboard = new Clipboard('.btn');

		clipboard.on('success', function(e) {
			$(".copy-url").each(function(){
				$(this).text("Copy short-link");
			});

			var trigger =  e.trigger;
			$(trigger).text("Copied");

			e.clearSelection();
		});

        function validateCreateLink(){
            event.preventDefault();

        	var link = $('#link').val();

            // check if link input is empty
            if(link.length===0){
            	$('#link-error').html('Please enter URL to share.');
            	return false;
            }
            else {

                // check if they are trying to share a pdf
                var file_type = link.substr(link.lastIndexOf('.')).toLowerCase();
                if (file_type  === '.pdf') {
                    $('#link-error').html('You cannot share a PDF.');
                    return false;
                } else {

                    const urls = {
                        "urls": [
                            link
                        ]
                    };

                    // Google Amp API call returns cached AMP url if one exists
                    $.ajax({
                        url: 'https://acceleratedmobilepageurl.googleapis.com/v1/ampUrls:batchGet?key=AIzaSyAFBflvRgeb_hFrkEZogAxnpJnOOfzLASo',
                        type: 'POST',
                        data: JSON.stringify(urls),
                        contentType: 'application/json',
                        success: function( data ) {
                            if(data){
                                if(data.ampUrls){
                                    $('#amp-url').val(data.ampUrls[0].cdnAmpUrl);
                                }
                            }

                            $("#shareLinkForm form").submit();
                        }
                    });



                }
            }

        }

        window.onload = function(){
            checkDeviceType();
        };

        function checkDeviceType(){

            var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
            if (iOS) {
                $("#sharedLinkIframe").attr('scrolling', 'no');
            } else {
                $("#sharedLinkIframe").attr('scrolling', 'yes');
            }
        }

    </script>

@endsection
@extends('www.layouts.publicViewapp')

@section('content')

<input type="hidden" value="{!! $user->LBRBackgroundImages_ID !!}" id="backgroundImage" />
@if(isset($redirectToBrandr))<input type="hidden" value="{!! $redirectToBrandr !!}" id="redirectToBrandr" />@endif

<div class="splash-page">
    <div class="row">
        <div class="col-lg-4 col-lg-push-8 col-md-5 col-md-push-7 col-sm-12">
            <div class="countdown">
                <span>Article Loading in</span>
                <span class="larger">3</span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
            <div class="splash-client-details">
                @if (!empty($user->ProfileImage))
                    <div class="image-cropper @if ($user->ImageType == 'Headshot')with-crop @elseif($user->ImageType == 'Logo')no-crop @endif @if ($user->ImageOrientation == 'landscape')landscape @elseif($user->ImageOrientation == 'portrait')portrait @endif"><img src="{!! url('/public/uploads/profile-images/'.$user->ID.".".pathinfo($user->ProfileImage, PATHINFO_EXTENSION))  !!}?avoidCache={!! $user->LastModified !!}"></div>
                @endif
                <div class="name">{!! $user->BusinessName !!}</div>
                <div class="title">{!! $user->BusinessDescription !!}</div>
            </div>
        </div>
        <div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
            <div class="splash-tagline">
                <p>{!! $user->Headline !!}</p>
            </div>

            @if (!empty($user->ButtonText) && !empty($user->ProfileURL))
                <div class="splash-button">
                    <a href="{!! $user->ProfileURL !!}" target="_blank" style="background-color: {!! $ButtonColor !!}">{!! $user->ButtonText !!}</a>
                </div>
            @endif
        </div>
    </div>
</div>

<script>

	$(document).ready(function(){
        //find out if we're in preview by checking iFrame parent url
        var pathname = (window.location != window.parent.location)
                ? document.referrer
                : document.location.href;

        var previewPath = "/share-link/listing";
        var previewPathPascal = "/ShareLink/listing";
        var previewPathCapitalize = "/Sharelink/listing";
        var previewPathLowerCase = "/sharelink/listing";
        var splashPreview = "/link/splash-preview";

        var match = pathname.indexOf(previewPath);
        var matchPascal = pathname.indexOf(previewPathPascal);
        var matchCapitalize = pathname.indexOf(previewPathCapitalize);
        var matchLowerCase = pathname.indexOf(previewPathLowerCase);
        var matchSplashPreview = pathname.indexOf(splashPreview);

        // start at 4 to get the full 3,2,1 countdown
		var counter = 4;
		var interval = setInterval(function() {
			counter--;
			$("div.countdown span.larger").text(counter);

			if (counter == 0) {

				clearInterval(interval);
                var shareTypeBoth = $('#redirectToBrandr').val();

                //not a match, therefore not in preview
                if(match == -1 && matchPascal == -1 && matchCapitalize == -1 && matchLowerCase == -1 && matchSplashPreview == -1){

                    //if redirecting to brandr
                    if(shareTypeBoth == 'true'){
                        window.location.replace("/link/{!! $slug !!}?showBrandr=true");
                    } else {
                        // Redirect to share link
                        window.location.replace("{!! $sharedLink !!}");
                    }
                //in preview with sharetype both
                } else if (shareTypeBoth == 'true'){
                    var url = window.location.href;
                    url += "?showBrandr=true";
                    window.location.href = url;
                }

			}
		}, 1000);

        var backgroundImage = $("#backgroundImage").val();

        if(backgroundImage != ""){
            $.backstretch("/public/images/splash_backgrounds/background-" + backgroundImage + ".jpg");
        } else {
            $.backstretch("/public/images/background.jpg");
        }
	});

</script>

@endsection
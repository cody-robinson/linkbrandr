@extends('www.layouts.dashboard')

@section ('css')
@endsection

@section('content')
    <section id="change-password-section" class="section form-section">
    <div class="container">
        <div class="space-50"></div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel">
                    <div class="panel-heading">
                        <h1>Change Password</h1>
                    </div>
                </div>
                <br>
                <div class="panel panel-default">
                    <div class="panel-heading"></div>

                    <div class="panel-body">
                        @if (Session::has('success'))
                            <div class="alert alert-success">{!! Session::get('success') !!}</div>
                        @endif
                        @if (Session::has('failure'))
                            <div class="alert alert-danger">{!! Session::get('failure') !!}</div>
                        @endif
                        <form action="" method="post" role="form">
                            {{csrf_field()}}

                            <div class="form-group{{ $errors->has('old') ? ' has-error' : '' }}">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="password" class="control-label">Old Password</label>
                                        <input id="password" type="password" class="form-control" name="old">

                                        @if ($errors->has('old'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('old') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="password" class="control-label">Password</label>
                                        <input id="password" type="password" class="form-control" name="password">

                                        @if ($errors->has('password'))
                                            <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="password-confirm" class="control-label">Confirm Password</label>
                                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                        @if ($errors->has('password_confirmation'))
                                            <span class="help-block">
                                            <strong>{{ $errors->first('password_confirmation') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary form-control">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </section>
@endsection

@section('scripts')

@endsection
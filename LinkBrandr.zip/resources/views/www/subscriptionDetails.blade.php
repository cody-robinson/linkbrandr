@extends('www.layouts.dashboard')

@section('content')

    <script src='https://js.stripe.com/v2/' type='text/javascript'></script>

    <section id="subscription-details" class="section form-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="center-title">
                        <h2>Select your payment plan</h2>
                        <br><br>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">

                        <div class="panel-body">

                            @if (session('message') && session('message') == 'success')
                                <div class="alert alert-success">
                                    Your account details were successfully updated!
                                </div>
                            @endif

                            @if($isPaidSubscription)
                                <!-- if they have a paid account, they can update their payment details or cancel their subscription -->
                                    <div class="row">
                                        <div class="col-md-6 margin-b-30">
                                            <div class="update-subscription-box">
                                                <h4>Update your account details.</h4>

                                                <form action="/Subscription/updateCard" method="POST">
                                                    {{ csrf_field() }}
                                                    <script
                                                            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                            data-key="{!! $stripeAPIKey !!}"
                                                            data-image="/public/images/lb-small.png"
                                                            data-name="LinkBrandr"
                                                            data-panel-label="Update Card Details"
                                                            data-label="Update Card Details"
                                                            data-allow-remember-me=false
                                                            data-locale="auto">
                                                    </script>
                                                </form>
                                            </div>
                                        </div>

                                        <div class="col-md-6 margin-b-30">
                                            <div class="cancel-subscription-box">
                                                <h4>Cancel your subscription.</h4>
                                                <a href="/Subscription/cancelSubscription" class="button btn btn-primary" onclick="return confirm('Are you sure you would like to cancel your subscription?')">Cancel Subscription</a>
                                            </div>
                                        </div>
                                    </div>
                            @else
                                    <div class="row">
                                        <div class="col-md-6 margin-b-30">
                                            <div class="price-box best-plan">
                                                <div class="price-header">
                                                    <h1><span class="dolor">$</span>7.99 <span class="peroid">/Month</span></h1>
                                                    <h4>Pay as you go!</h4>
                                                    <br>
                                                </div>

                                                <div class="price-footer">
                                                    <form action="/Subscription/subscribeMonthly" method="POST">
                                                        {{ csrf_field() }}
                                                        <script
                                                                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                                data-key="{!! $stripeAPIKey !!}"
                                                                data-image="/public/images/lb-small.png"
                                                                data-name="LinkBrandr"
                                                                data-description="Monthly Subscription"
                                                                data-billing-address ="true"
                                                                data-email="{!! $userEmail !!}"
                                                                data-label="Add payment details">
                                                        </script>
                                                    </form>
                                                </div>
                                                <br>
                                            </div>
                                        </div><!--/col-->
                                        <div class="col-md-6 margin-b-30">
                                            <div class="price-box">
                                                <div class="price-header">

                                                    <h1><span class="dolor">$</span>79.99 <span class="peroid">/Annually</span></h1>
                                                    <h4>2 months for free!</h4>
                                                </div>
                                                <ul class="list-unstyled price-features">
                                                    <li>Easy to use dashboard</li>
                                                    <li>Link shortening & customization</li>
                                                    <li>LinkBrandr Bar & Redirection Page</li>
                                                    <li>Exponential reach on shares and retweets</li>
                                                    <li>Call to action on every page</li>
                                                </ul>
                                                <div class="price-footer">
                                                    <form action="/Subscription/subscribeAnnually" method="POST">
                                                        {{ csrf_field() }}
                                                        <script
                                                                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                                data-key="{!! $stripeAPIKey !!}"
                                                                data-image="/public/images/lb-small.png"
                                                                data-name="LinkBrandr"
                                                                data-description="Annual Subscription"
                                                                data-billing-address ="true"
                                                                data-email="{!! $userEmail !!}"
                                                                data-label="Add payment details">
                                                        </script>
                                                    </form>
                                                </div>
                                            </div>
                                        </div><!--/col-->
                                        <div class="col-md-12">
                                            <br>
                                            <p class="price-info"><span class="bold">* All prices in USD</span></p>
                                        </div>
                                    </div>

                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
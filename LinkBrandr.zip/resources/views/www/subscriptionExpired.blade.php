@extends('www.layouts.dashboard')

@section('content')
    <section id="subscription-expired" class="section form-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="center-title">
                        <h2>Select your payment plan</h2>
                        <br>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="alert alert-danger">
                                <i class="fa fa-warning fa-fw fa-lg"></i>
                                <strong>Attention!</strong> Your account has expired. Please enter payment details below to continue using LinkBrandr.
                            </div>
                        </div>
                        <br>

                        <div class="panel-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 margin-b-30">
                                        <div class="price-box best-plan">
                                            <div class="price-header">

                                                <h1><span class="dolor">$</span>7.99 <span class="peroid">/Month</span></h1>
                                                <h4>Pay as you go!</h4>
                                                <br>
                                            </div>

                                            <div class="price-footer">
                                                <form action="/Subscription/subscribeMonthly" method="POST">
                                                    {{ csrf_field() }}
                                                    <script
                                                            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                            data-key="{!! $stripeAPIKey !!}"
                                                            data-image="/public/images/lb-small.png"
                                                            data-name="LinkBrandr"
                                                            data-description="Monthly Subscription"
                                                            data-billing-address ="true"
                                                            data-email="{!! $userEmail !!}"
                                                            data-label="Add payment details">
                                                    </script>
                                                </form>
                                            </div>
                                            <br>
                                        </div>
                                    </div><!--/col-->
                                    <div class="col-md-6 margin-b-30">
                                        <div class="price-box">
                                            <div class="price-header">

                                                <h1><span class="dolor">$</span>79.99 <span class="peroid">/Annually</span></h1>
                                                <h4>2 months for free!</h4>
                                            </div>
                                            <ul class="list-unstyled price-features">
                                                <li>Easy to use dashboard</li>
                                                <li>Link shortening & customization</li>
                                                <li>LinkBrandr Bar & Redirection Page</li>
                                                <li>Exponential reach on shares and retweets</li>
                                                <li>Call to action on every page</li>
                                            </ul>
                                            <div class="price-footer">
                                                <form action="/Subscription/subscribeAnnually" method="POST">
                                                    {{ csrf_field() }}
                                                    <script
                                                            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                            data-key="{!! $stripeAPIKey !!}"
                                                            data-image="/public/images/lb-small.png"
                                                            data-name="LinkBrandr"
                                                            data-description="Annual Subscription"
                                                            data-billing-address ="true"
                                                            data-email="{!! $userEmail !!}"
                                                            data-label="Add payment details">
                                                    </script>
                                                </form>
                                            </div>
                                        </div>
                                    </div><!--/col-->
                                    <div class="col-md-12">
                                        <br>
                                        <p class="price-info"><span class="bold">* All prices in USD</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@extends('www.layouts.main')

@section('content')
    <section>
        <div class="container">
            <div class="row block">
                <div class="col-lg-9">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item">Contact</li>
                    </ul>
                    <h1 style="margin-bottom:25px;">Contact Us</h1>
                    <p>Feel free to contact us using the form below or email us directly at support@linkbrandr.com</p>

                    @if (session('message') && session('message') == 'success')
                        <div class="alert alert-success">
                            Thanks for contacting LinkBrandr!
                        </div>
                    @endif

                    <div class="container" style="margin-top:25px;">
                        <form class="form-horizontal" role="form" method="POST" action="/contactFormSubmission">
                            {{ csrf_field() }}
                            <div class="form-group{{ $errors->has('Name') ? ' has-error' : '' }} ">
                                <input id="Name" type="text" class="form-control" name="Name" value="{{ old('Name') }}" required placeholder="Full Name">

                                @if ($errors->has('Name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('Name') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group{{ $errors->has('Email') ? ' has-error' : '' }}">
                                <input id="Email" type="email" class="form-control" name="Email" value="{{ old('Email') }}" required placeholder="Email Address">

                                @if ($errors->has('Email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('Email') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group{{ $errors->has('Message') ? ' has-error' : '' }}">
                                <textarea id="Message" type="text" class="form-control" name="Message" value="{{ old('Message') }}" required placeholder="Message"></textarea>

                                @if ($errors->has('Message'))
                                    <span class="help-block">
                                    <strong>{{ $errors->first('Message') }}</strong>
                                </span>
                                @endif
                            </div>

                            <button type="submit" class="btn btn-primary btn-rounded form-control col-sm-6 ">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
@extends('www.layouts.dashboard')

@section('content')
    <section id="welcome-section" class="section form-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h1 class="text-center">Welcome to LinkBrandr!</h1>
                            <br>
                            <p>We’re happy to have you on board. Let’s set up your account so that you can start sharing links and building your brand! On the next page we’ll create your personal <strong>Brandr Bar</strong> and <strong>Redirect Page</strong>. And don’t worry: you can always change the designs later on by going to the “Edit Profile” page.</p>

                            <p>Read more about the two options below and then click on “Get Started” once you’re ready to create your own!</p>
                        </div>
                    </div>
                    <br>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12 demo-brandr-bar panel">
                                    <div class="panel-body">
                                        <h4>Brandr Bar</h4>
                                        <p class="instructions">
                                            The <strong>Brandr Bar</strong> is our most popular tool. All of the elements on the Brandr Bar are customizable and the end result will look similar to what you see below. The website you share will load below the Brandr Bar. You can select from three available themes and various colour options.
                                        </p>
                                        <img src="/public/images/brandr-template.png">
                                    </div>
                                </div>
                            </div>

                            <div class="demo-brandr-bar panel">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-7 col-md-6">
                                            <h4>Redirect Page</h4>
                                            <p class="instructions">
                                                You also have the option of using our <strong>Redirect Page</strong>.  A custom page like the one to the right will be displayed for a few seconds while the link you are sharing loads. Choose from multiple background images and customize the text any way you wish!
                                            </p>
                                        </div>
                                        <div class="col-lg-5 col-md-6">
                                            <img src="/public/images/splash-template.png" class="splash-template">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <p>You can always switch between using the <strong>Brandr Bar, Redirect Page</strong>, or <strong>both</strong> - for any link you share. Click on the “Get Started” button below and create your own!</p>

                        <a href="/branding/edit-profile?NewProfile" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="drip-registration-details">
            <input type="hidden" id="email" name="email" value="{!! $email !!}">
            <input type="hidden" id="firstName" name="firstName" value="{!! $firstName !!}">
            <input type="hidden" id="lastName" name="lastName" value="{!! $lastName !!}">
        </div>
    </section>

    <!-- Send info to Drip after registration was successful
    (we know that because they were redirect here.) -->
    <script>

        $(document).ready(function(){
            var email = $('.drip-registration-details #email').val();
            var firstName = $('.drip-registration-details #firstName').val();
            var lastName = $('.drip-registration-details #lastName').val();

            _dcq.push(["identify", {
                email: email,
                first_name: firstName,
                last_name: lastName
            }]);
        });

    </script>

@endsection
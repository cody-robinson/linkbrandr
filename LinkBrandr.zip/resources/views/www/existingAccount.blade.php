@extends('www.layouts.main')

@section('content')

    <section id="existing-account-section" class="form-section section">
        <div class="section-inner">
            <div class="container text-center">
                <div class="space-80"></div>
                <div class="form-wrapper">
                    <div class="form-box">

                        <h3>You already have a LinkBrandr Account!</h3>
                        @if($accountType == 'social')
                            <h4>The email address for your Facebook account matches an existing LinkBrandr account. Would you like to merge accounts?</h4>
                            <p>If you choose to merge accounts, your old account will be deleted after saving all existing links to your new Facebook account.</p>
                        @elseif($accountType == 'email')
                            <h4>Your email address is already associated with a LinkBrandr account created through Facebook Login.</h4>
                            <p>Login to your existing account through Facebook Login or continue creating a new account using the links below.</p>
                        @endif

                        <!-- if creating a FB account and email account already exists, offer ability to merge accounts -->
                        @if($accountType == 'social')
                        <form class="form-horizontal" role="form" method="POST" action="{{ url('/home/mergeAccounts') }}">
                            {{ csrf_field() }}
                            <div class="row">
                                <input type="hidden" name="userEmail" value="{!! $userEmail !!}">
                                <div class="form-group offset-sm-3 col-sm-6 col-xs-12">
                                    <button type="submit" class="btn btn-primary form-control">
                                        Merge Accounts
                                    </button>
                                </div>
                            </div>
                        </form>
                        @endif

                        <!-- if creating an email account and FB account already exists, prompt them to log in with FB -->
                        @if($accountType == 'email')
                            <form class="form-horizontal" role="form" method="POST" action="{{ url('/home/deleteNewAccount') }}">
                                {{ csrf_field() }}
                                <input type="hidden" name="userEmail" value="{!! $userEmail !!}">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        <button type="submit" href="/home/deleteNewAccount" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </button>
                                    </div>
                                </div>
                            </form>
                        @endif

                        <!-- in both cases, they have the option to continue creating new account -->
                        <br>
                        <a href="/home/welcome/">Continue with new account</a>

                    </div><!--//form-box-->
                </div>

            </div><!--//container-->
        </div><!--//section-inner-->
    </section>
@endsection

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>LinkBrandr: Grow your brand each time you share a link</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="https://file.myfontastic.com/BQ5rqoUxsfQGHC35jWa5Ub/icons.css">
    <!-- Google fonts - Open Sans-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800">
    <!-- owl carousel-->
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/css/style.blue.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="/public/css/custom-from-theme.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/images/favicon.ico" />
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

    <!-- Live chat -->
    <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="b74ccecc-15e2-41fe-b28c-6bd58c575f79";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</head>
<body>
<!-- navbar-->
<header class="header">
    <nav class="navbar navbar-expand-lg fixed-top">
        <a href="/" class="navbar-brand">
            <img src="/public/images/link-brandr-logo.png" class="logo"/>
        </a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><span></span><span></span><span></span></button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto align-items-start align-items-lg-center">
                <li class="nav-item"><a href="/#how-it-works" class="nav-link link-scroll">How it Works</a></li>
                <li class="nav-item"><a href="/#features" class="nav-link link-scroll">Features</a></li>
                <li class="nav-item"><a href="/#pricing" class="nav-link link-scroll">Pricing</a></li>
                @if (Auth::guest() && Auth::guard('web')->guest())
                    <!-- only show Login button if user is not logged in -->
                    <li class="nav-item"><a href="/login" class="nav-link link-scroll">Log In</a></li>
                @else
                    <!-- otherwise, link should say Dashboard -->
                    <li class="nav-item"><a href="/login" class="nav-link link-scroll">Dashboard</a></li>
                @endif
            </ul>

            <!-- only show free trial button in nav if user isn't logged in -->
            @if (Auth::guest() && Auth::guard('web')->guest())
            <div class="navbar-text">
                <!-- Button trigger modal--><a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary navbar-btn btn-shadow btn-gradient">Free Trial</a>
            </div>
            @endif
        </div>
    </nav>
</header>
<!-- Modal-->
<div id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title">Start Your Free Trial Today</h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="/register" id="signupform">
                    {{ csrf_field() }}
                        <div class="facebook-login text-center">
                            <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                            <div class="divider">
                                <span class="or-text" style="margin-bottom:10px;margin-top:10px;">OR</span>
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('FirstName') ? ' has-error' : '' }}">
                            <input id="firstName" type="text" class="form-control" name="firstName" value="{{ old('firstName') }}" required placeholder="First Name">

                            @if ($errors->has('FirstName'))
                                <span class="help-block">
                                        <strong>{{ $errors->first('FirstName') }}</strong>
                                    </span>
                            @endif
                        </div>
                        <div class="form-group{{ $errors->has('LastName') ? ' has-error' : '' }}">
                            <input id="lastName" type="text" class="form-control" name="lastName" value="{{ old('lastName') }}" required placeholder="Last Name">

                            @if ($errors->has('LastName'))
                                <span class="help-block">
                                        <strong>{{ $errors->first('LastName') }}</strong>
                                    </span>
                            @endif
                        </div>

                        <div class="form-group{{ $errors->has('Username') ? ' has-error' : '' }}">
                            <input id="username" type="email" class="form-control" name="username" value="{{ old('username') }}" required placeholder="Email Address">

                            @if ($errors->has('Username'))
                                <span class="help-block">
                                        <strong>{{ $errors->first('Username') }}</strong>
                                    </span>
                            @endif
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <div class="input-group">
                                <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                            </div>
                            @if ($errors->has('password'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary form-control">
                                Register
                            </button>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>

@yield('content')

<footer class="main-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <a href="/" class="brand">
                    <img src="/public/images/link-brandr-logo.png" class="logo"/>
                </a>
                <ul class="social-icons list-inline">
                    <li class="list-inline-item"><a href="https://www.facebook.com/linkbrandr" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="https://twitter.com/LinkBrandr" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <ul class="links list-unstyled">
                    <li> <a href="/privacy">Privacy</a></li>
                    <li> <a href="/terms">Terms of Service</a></li>
                    <li> <a href="/contact">Contact</a></li>
                </ul>
            </div>
            <div class="col-lg-6 col-md-6">
                <h5>Newsletter</h5>
                <!-- Begin MailChimp Signup Form -->
                <div id="mc_embed_signup">
                    <form action="//linkbrandr.us16.list-manage.com/subscribe/post?u=530e1a71bd5a296f546a90bd6&amp;id=fc2bf8edfc" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                        <div id="mc_embed_signup_scroll">
                            <p>Be the first to learn about our latest product updates</p>
                            <input type="email" value="" name="EMAIL" class="email form-control" id="mce-EMAIL" placeholder="email address" required>
                            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                            <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_530e1a71bd5a296f546a90bd6_fc2bf8edfc" tabindex="-1" value="" class="form-control"></div>
                            <div class="clear">
                                <input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button btn btn-primary"></div>
                        </div>
                    </form>
                </div>
                <!--End mc_embed_signup-->
            </div>
        </div>
    </div>
    <div class="copyrights">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <p>&copy; 2017 LinkBrandr.com. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Javascript files-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"> </script>
<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="/public/js/front.js"></script>
<!-- Google Analytics: -->
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-102275980-1', 'auto');
    ga('send', 'pageview');
</script>

<!-- Drip -->
<script type="text/javascript">
    var _dcq = _dcq || [];
    var _dcs = _dcs || {};
    _dcs.account = '3425290';
    (function() {
        var dc = document.createElement('script');
        dc.type = 'text/javascript'; dc.async = true;
        dc.src = '//tag.getdrip.com/3425290.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(dc, s);
    })();
</script>
<!-- End Drip -->

<!-- Sumo -->
<script async>(function(s,u,m,o,j,v){j=u.createElement(m);v=u.getElementsByTagName(m)[0];j.async=1;j.src=o;j.dataset.sumoSiteId='055d79ad25f283cef9729b749cb58a52b48a7fddb25ff54d1b1d5e53c45d4770';v.parentNode.insertBefore(j,v)})(window,document,'script','//load.sumo.com/');</script>

</body>
</html>

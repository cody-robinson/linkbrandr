<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <?php
    // this will set the link in fb link share preview to the shared url
    // header("Link: $sharedLink rel='canonical'");
    ?>

    <meta property="og:type" content="website" />

    @if($image)
        <meta property="og:image" content="{!! $image !!}" />
    @endif

    <meta property="og:url" content="{!! url('/link') !!}/{{ $slug }}" />

    @if($title)
        <meta property="og:title" content="{!! $title !!}" />
    @endif

    <meta property="fb:app_id" content="337140466720768" />

    @if($description)
        <meta property="og:description" content="{!! $description !!}" />
    @endif

    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="shortcut icon" href="{!! $favicon !!}"/>
    <title>{!! $title !!}</title>

    <!-- styles -->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Raleway:400,400i,500,700,900|Ubuntu:300i,400,500" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/public/css/public-view-styles.css">


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- libraries -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/public/js/backstretch.min.js"></script>



</head>
<body>

@yield('content')

</body>
</html>

@extends('www.layouts.dashboard')

@section('content')

    <!-- styles needed for the live brandr bar preview -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Raleway:400,400i,500,700,900|Ubuntu:300i,400,500" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/public/css/public-view-styles.css">

    <section id="edit-brand-section" class="section form-section">

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            {!! form_open($form,['enctype'=>'multipart/form-data']) !!}
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="center-title">
                                        <h2>Let's build your BrandrBar & Redirect Page</h2>

                                        <h4>Step one &mdash; BrandrBar</h4>
                                        <div class="underline"></div>
                                    </div>

                                    <h4>Edit profile details</h4>
                                </div>
                            </div>
                            <div class="row">
                                <!-- left col of form -->
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        {!! form_element($form['BusinessName']) !!}
                                    </div>

                                    <div class="form-group">
                                        {!! form_element($form['BusinessDescription']) !!}
                                    </div>

                                    <div class="form-group">
                                        {!! form_element($form['Headline']) !!}
                                    </div>

                                    <div class="form-group">
                                        {!! form_element($form['ButtonText']) !!}
                                    </div>

                                    <div class="form-group">
                                        {!! form_element($form['ProfileURL'],['widget'=>['placeholder'=>'ex. www.linkbrandr.com']]) !!}
                                    </div>
                                </div>

                                <!-- right col of form -->
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Image Type
                                            <i class="fa fa-question-circle"></i>
                                            <span class="info smaller" style="display: none;">Selecting headshot will place a round crop around your Profile Image</span>
                                        </label><br>
                                        {!! form_element($form['ImageType']) !!}
                                    </div>

                                    <div class="form-group">
                                        <div id="image-orientation" style="display: none;">
                                            <label>Image Orientation
                                                <i class="fa fa-question-circle"></i>
                                                <span class="info smaller" style="display: none;">Select the orientation of your image for best cropping results</span>
                                            </label><br>
                                            {!! form_element($form['ImageOrientation']) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Profile Image
                                            <i class="fa fa-question-circle"></i>
                                            <span class="info smaller" style="display: none;">For best results, select an image with subject centred in frame</span>
                                        </label><br>
                                        <input type="file" name="ProfileImage" id="ProfileImage" />
                                        <br>
                                        <input type="submit" value="Update Preview" class="btn btn-primary" id="update-profile-image" name="update-profile-image"/>
                                        @if(file_exists('public/uploads/profile-images/'.$UserProfileID.".".$ProfileImageExt))
                                            <a href="/branding/delete-profile-image/{!! $UserProfileID !!}" id="delete-profile-image" class="btn btn-primary" onclick="return confirm('Are you sure you want to delete this profile image?');">Delete Image</a>
                                        @endif

                                        @if(file_exists('public/uploads/profile-images/'.$UserProfileID.".".$ProfileImageExt))
                                            <div id="ProfileImagePreview" class="@if($UserImageType == 'Headshot') with-crop @else no-crop @endif @if($UserImageOrientation == 'landscape')landscape @elseif ($UserImageOrientation == 'portrait')portrait @endif">
                                                <img src="{{ asset('public/uploads/profile-images/'.$UserProfileID.".".$ProfileImageExt) }}?avoidCache={!! $LastModified !!}">
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="clearfix"></div>
                            <br>

                            <hr>
                            <div class="row">
                                <div class="col-lg-6 form-group">
                                    <h4>Select your theme</h4>
                                    {!! form_element($form['Theme'], ['widget' => ['readonly' => 'true']]) !!}
                                </div>

                                <div class="col-lg-6 form-group">
                                    <h4>Select your color scheme</h4>
                                    {!! form_element($form['SchemeName'], ['widget' => ['readonly' => 'true']]) !!}
                                </div>
                            </div>

                            <!-- beginning of dynamic live preview-->

                            <!-- don't remove color div, used by JS to populate colors for preview-->
                            <div id="color"></div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <br>
                                        <h4>Preview</h4>
                                        <div id="BrandrBarPreview">
                                            <div class="brandr-bar-live-preview">
                                                <table class="brandr-bar" style="background-color: black;">
                                                    <tbody>
                                                    <tr>
                                                        <td class="branding" style="width: 20%;">
                                                            <table>
                                                                <tbody>
                                                                <tr>
                                                                    <td class="profile-image-container">
                                                                        @if(file_exists('public/uploads/profile-images/'.$UserProfileID.".".$ProfileImageExt))
                                                                            <div class="image-cropper @if($UserImageType == 'Headshot') with-crop @else no-crop @endif @if($UserImageOrientation == 'landscape')landscape @elseif ($UserImageOrientation == 'portrait')portrait @endif">
                                                                                <img src="{{ asset('public/uploads/profile-images/'.$UserProfileID.".".$ProfileImageExt) }}?avoidCache={!! $LastModified !!}" />
                                                                            </div>
                                                                        @else
                                                                            <div class="space"></div>
                                                                        @endif
                                                                    </td>

                                                                    <td class="client-details">
                                                                        <h1 class="name">Business Name</h1>
                                                                        <h2 class="title">Business Description</h2>
                                                                        <i class="fa fa-caret-right"></i>
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>

                                                        <td class="tagline" style="width: 60%;">
                                                            <p>Headline goes here!</p>
                                                        </td>

                                                        <td class="contact-button" style="width: 20%;">
                                                            <a class="btn btn-default get-in-touch" target="_blank">Button Text</a>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <!-- end of live preview-->

                            <div class="clearfix"></div>

                            <div class="center-title">
                                <br><br><br>
                                <h4>Step two &mdash; Redirect Page</h4>
                                <div class="underline"></div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <h4>Select background image</h4>
                                    {!! form_element($form['SplashTempName']) !!}
                                </div>

                                <div class="col-sm-6 form-group">
                                    {!! form_element($form['BackgroundImage'], ['widget' => ['readonly' => 'true']]) !!}

                                    <input type="submit" value="Preview your Redirect Page" class="btn btn-primary btn-rounded" id="see-preview" name="see-preview" formtarget="_blank"/>
                                </div>
                                <div class="col-sm-6 form-group">
                                    <p>Background Image Preview</p>
                                    <div id="BackgroundPreview">
                                        <img src="" >
                                    </div>
                                </div>

                            </div>

                            <hr>

                            <div class="row">
                                <div class="col-sm-12">
                                    <input type="submit" value="Save & create a new link" class="btn btn-primary btn-rounded save" />
                                </div>
                            </div>

                            <input type="hidden" value="{!! $UserEmail !!}" name="primaryEmail" id="primaryEmail">
                        {!! form_close($form) !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Send info to Drip when profile is initially created -->
    <script>
        $('#edit-brand-section form').submit(function(){
            var pathname = window.location.href;
            var btn = $(document.activeElement);

            // only send info if NewProfile param in URL and button used to submit wasn't see preview btn
            if (pathname.indexOf("NewProfile") >= 0 && $(btn[0]).attr('id') != 'see-preview'){
                event.preventDefault();

                var email = $('#primaryEmail').val();

                _dcq.push(["identify", {
                    email: email,
                    tags: ["Set up profile page"]
                }]);

                // avoid endless loop timeout by using [0]
                $(this)[0].submit();
            }
        });
    </script>

    <script src="/public/js/are-you-sure.js"></script>
    <script src="/public/js/edit-branding.js"></script>

@endsection
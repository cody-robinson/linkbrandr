var colorSchemes = {};

// With a custom message
$('form').areYouSure();

function getColors(value){

	var schemeID;

	if(value == undefined){
		schemeID = $('select[name=SchemeName] option:selected').val();
	}
	else{
		schemeID = value;
	}

	if(schemeID != undefined){
		$.ajax({
			url:"/reporter/color-schemes/"+schemeID,
			cache:false

		}).done(function(data){
			var content = '<p>Color Preview</p><ul>';

			$(data).each(function(index,value){
				var color = JSON.parse(value.Colors);
				$(color).each(function(i,v){
					content += '<li style="background-color: '+v+';"></li>'
				});
				content += "</ul>";
			});

			//populate color preview
			$('#color').html(content);

			//populate new color selection in live brandr bar preview
			var brandrBarPreview = '.brandr-bar-live-preview table.brandr-bar';
			var backgroundColor = $('#color li:first-of-type').css('backgroundColor');
			var buttonColor = $('#color li:last-of-type').css('backgroundColor');

			if($(brandrBarPreview).hasClass('theme-one')){
				$(brandrBarPreview +'.theme-one .contact-button a').css('background-color', buttonColor);
				$(brandrBarPreview +'.theme-one .client-details h1').css('color', buttonColor);
				$(brandrBarPreview +' .branding table').css('background', 'none');
			} else {
				$(brandrBarPreview +' .branding table').css('background-color', buttonColor);
				$(brandrBarPreview +' .client-details i').css('color', buttonColor);
				$(brandrBarPreview +' .client-details h1').css('color', 'white');
				$(brandrBarPreview +' .contact-button a').css('background', 'none');
				$(brandrBarPreview +' .contact-button a').css('color', 'white');
				$(brandrBarPreview +'.theme-two .contact-button a').css('border-color', buttonColor);
			}

			$(brandrBarPreview).css('background-color', backgroundColor);
		});
	}
}

function getIframes(value){

	var iframeID;

	if(value == undefined){
		iframeID = $('#theme').val();
	}
	else{
		iframeID = value;
	}

	//populating brandr bar theme options
	$.ajax({
		url: "/reporter/iframe-templates/"+iframeID,
		cache:false
	}).done(function(data){
		if(data[0]){
			var TemplateName = data[0].CSSClassName;
			var brandrBarPreview = '.brandr-bar-live-preview table.brandr-bar';
			$(brandrBarPreview).removeClass('theme-one theme-two theme-three');
			$(brandrBarPreview).addClass(TemplateName);
			var buttonColor = $("#color ul li:last-of-type").css('background-color');

			//if switching to theme one, need to add button background color
			if(TemplateName == 'theme-one') {
				$(brandrBarPreview +'.theme-one .contact-button a').css('background-color', buttonColor);
				$(brandrBarPreview +'.theme-one .branding table').css('background-color', 'transparent');
				$(brandrBarPreview +'.theme-one .client-details h1').css('color', buttonColor);
			}

			//if switching to theme two, need to add client details background and border color
			else if(TemplateName == 'theme-two') {
				$(brandrBarPreview +'.theme-two .contact-button a').css('border-color', buttonColor);
				$(brandrBarPreview +'.theme-two .branding table').css('background-color', buttonColor);
				$(brandrBarPreview +'.theme-two .client-details h1').css('color', 'white');
				$(brandrBarPreview +'.theme-two .client-details i').css('color', buttonColor);
			}

			//if switching to theme three, need to add client details background and border color
			else if(TemplateName == 'theme-three') {
				$(brandrBarPreview +'.theme-three .branding table').css('background-color', buttonColor);
				$(brandrBarPreview +'.theme-three .client-details h1').css('color', 'white');
			}
		}
	});
}

window.onload = function(){
	getColors();
	getIframes();
	getBackgroundImage();

	$('#scheme-name').change(function(){
		getColors(this.value);
	});

	document.getElementById('theme').addEventListener('change',function(){
		getIframes(this.value);
	});

	//apply crop if profile image is set to headshot
	var imageType = $("input[name=ImageType]:checked").val();
	var ProfileImageDiv = $("#ProfileImage");
	var brandrBarPreview = '.brandr-bar-live-preview table.brandr-bar';

	//show image orientation selection
	if(imageType == "Headshot") {
		$("#image-orientation").show();
	}

	if(imageType == 'Headshot' && $(ProfileImageDiv).children().length > 0) {
		$(ProfileImageDiv).removeClass("no-crop");
		$(ProfileImageDiv).addClass("with-crop");
		$(brandrBarPreview + ' .image-cropper').addClass("with-crop");
		$(brandrBarPreview + ' .image-cropper').removeClass("no-crop");

		//show image orientation options
		$("#image-orientation").show();
	} else if (imageType == "Logo" && $(ProfileImageDiv).children().length > 0) {
		$(ProfileImageDiv).removeClass("with-crop");
		$(ProfileImageDiv).addClass("no-crop");
		$(brandrBarPreview + ' .image-cropper').addClass("no-crop");
		$(brandrBarPreview + ' .image-cropper').removeClass("with-crop");
	}

	//brandr bar preview populate existing user values
	var businessName = $("#business-name").val();
	var businessDescription = $("#business-description").val();
	var headline = $("#headline").val();
	var buttonText = $("#button-text").val();

	$(brandrBarPreview + ' .client-details h1').text(businessName);
	$(brandrBarPreview + ' .client-details h2').text(businessDescription);
	$(brandrBarPreview + ' .tagline p').text(headline);
	$(brandrBarPreview + ' .contact-button a').text(buttonText);

	if(buttonText == '') {
		$( '.brandr-bar-live-preview table.brandr-bar .contact-button a').hide();
	}

	if(businessName == '' && businessDescription == ''){
		$('.brandr-bar .branding table td.client-details').addClass('empty');
	}

	if(imageType == 'Logo' && $(ProfileImageDiv).children().length > 0){
		$('td.client-details').addClass('hide-mobile');
	} else {
		$('td.client-details').removeClass('hide-mobile');
	}
};

$('input[name=ImageType]').on('change', function() {
	var profileImage = $("#ProfileImagePreview");
	var brandrBarPreview = '.brandr-bar-live-preview table.brandr-bar';

	//show image orientation selection
	if(this.value == "Headshot") {
		$("#image-orientation").show();
		//update brandr bar live preview
		$(brandrBarPreview +' .branding .image-cropper').removeClass('no-crop');
		$(brandrBarPreview +' .branding .image-cropper').addClass('with-crop');
	} else {
		$("#image-orientation").hide();
		//update brandr bar live preview
		$(brandrBarPreview +' .branding .image-cropper').removeClass('with-crop');
		$(brandrBarPreview +' .branding .image-cropper').addClass('no-crop');

	}

	//if there is an image preview, add/remove cropping accordingly
	if(this.value == "Headshot" && $(profileImage).children().length > 0) {
		$(profileImage).removeClass("no-crop");
		$(profileImage).addClass("with-crop");
		$(brandrBarPreview + ' .image-cropper').addClass("with-crop");
		$(brandrBarPreview + ' .image-cropper').removeClass("no-crop");

		$("#image-orientation").show();
	} else if (this.value == "Logo" && $(profileImage).children().length > 0) {
		$(profileImage).removeClass("with-crop");
		$(profileImage).addClass("no-crop");
		$(brandrBarPreview + ' .image-cropper').addClass("no-crop");
		$(brandrBarPreview + ' .image-cropper').removeClass("with-crop");

		$("#image-orientation").hide();
	}

	if(this.value == 'Headshot'){
		$('td.client-details').removeClass('hide-mobile');
	} else if (this.value == 'Logo' && $("#business-name").val() != '') {
		$('td.client-details').addClass('hide-mobile');
	}
});

//apply image orientation to image preview and brandr bar preview
$('input[name=ImageOrientation]').on('change', function() {
	var orientation = $("input[name=ImageOrientation]:checked").val();
	var profileImage = $("#ProfileImagePreview");
	var brandrBarPreview = '.brandr-bar-live-preview table.brandr-bar';

	if(orientation == "portrait") {
		profileImage.addClass("portrait");
		profileImage.removeClass("landscape");
		$(brandrBarPreview + ' .image-cropper').addClass("portrait");
		$(brandrBarPreview + ' .image-cropper').removeClass("landscape");

	} else if (orientation == "landscape") {
		profileImage.addClass("landscape");
		profileImage.removeClass("portrait");
		$(brandrBarPreview + ' .image-cropper').addClass("landscape");
		$(brandrBarPreview + ' .image-cropper').removeClass("portrait");
	}

});

$("#ProfileImage").on('change', function() {
	//handle profile image in brandr bar preview when a user without an existing image uploads a profile image
	var imageType = $('#image-type').val();
	var crop;

	if (imageType == 'Logo'){
		crop = 'no-crop'
	} else if (imageType == 'Headshot') {
		crop = 'with-crop';
	}
	var imageOrientation = $('input[name=ImageOrientation]:checked').val();

	if($('#ProfileImage').val() != '') {
		$('.profile-image-container').html('<div class="image-cropper ' + crop + ' ' + imageOrientation + '" ><img src="/public/images/placeholder-image.png"></div>')
	}
});

//populate fields in brandr bar live preview
$( "#business-name" ).keyup(function() {
	var businessName = $('#business-name').val();
	$( '.brandr-bar-live-preview table.brandr-bar .client-details h1').text(businessName);
});

$( "#business-description" ).keyup(function() {
	var businessDescription = $('#business-description').val();
	$( '.brandr-bar-live-preview table.brandr-bar .client-details h2').text(businessDescription);
});

$( "#headline" ).keyup(function() {
	var headline = $('#headline').val();
	$( '.brandr-bar-live-preview table.brandr-bar .tagline p').text(headline);
});

$( "#button-text" ).keyup(function() {
	var buttonText = $('#button-text').val();
	$( '.brandr-bar-live-preview table.brandr-bar .contact-button a').text(buttonText);

	if(buttonText == ''){
		$( '.brandr-bar-live-preview table.brandr-bar .contact-button a').hide();
	} else {
		$( '.brandr-bar-live-preview table.brandr-bar .contact-button a').show();
	}
});


$("select[name=BackgroundImage]").on('change', function() {
	getBackgroundImage();

});

function getBackgroundImage(){
	var backgroundImage = $('select[name=BackgroundImage] option:selected').val();
	$('#BackgroundPreview img').attr('src', '/public/images/splash_backgrounds/background-' + backgroundImage + '.jpg');
}

// show info when hovering over question icons
$('#edit-brand-section i.fa-question-circle').hover(function(e){
	$(e.currentTarget).next('span.info').show();
});

$('#edit-brand-section i.fa-question-circle').mouseout(function(e){
	$(e.currentTarget).next('span.info').hide();
});
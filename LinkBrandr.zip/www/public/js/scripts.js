// make first link the active preview
$("document").ready(function(){
	$(".listing-item:first").addClass("active");
	$('.listing-item.active .link-meta').show();
	$("article .item:first").addClass("active");

//	reloadPreview(url);
});

// workaround for annoying issue with href in template, need to stop makeActiveLink function
$('.listing-item .delete-btn').click(function(event){
	event.preventDefault();
	event.stopImmediatePropagation();

	if(confirm('Are you sure you want to delete this link?')){
		window.location.href = $(this).attr('href');
	}
});

function makeActiveLink(activeLink){

	//make current tab inactive
	$(".listing-item.active").each(function(){
		$(this).removeClass("active");
	});
	$('.listing-item .link-meta').each(function(){
		$(this).hide();
	});

	var meta = $(activeLink).find('.link-meta');
	$(meta).show();

	//highlight new active link listing and show details
	$(activeLink).addClass('active');
}


$('.shared-link-update-btn').on('click',function(){

	var id = $(this).attr('data-id');
	var slug = $('#slug-'+id).val();

	var shareType = $('[name="ShareType"][data-id="'+id+'"][checked="checked"]').val();

	$.ajax({
		url:"/share-link/quick-update/"+schemeID,

		cache:false

	}).done(function(data){
		var content = '<ul style="width:300px; border:1px solid #000; height:200px;padding:0">';

		$(data).each(function(index,value){
			var color = JSON.parse(value.Colors);
			$(color).each(function(i,v){
				content += '<li style="width:50%; height:200px; margin:0;padding:0; float:left; display:inline-block; background-color: '+v+'; "></li>'
			});
			content += "</ul>";
		});

		$('#color').html(content);
	});
});


$('.share-type-btn').on('click',function(){
	var name = $(this).attr('name');
	var id = name.substr(name.indexOf('-')+1);
	var value = $(this).val();
	var url = $('#slug-copy-'+id).attr('data-clipboard-text');

	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
	//var CSRF_TOKEN = '{{ csrf_token() }}';

	if(value == "iframe" || value == "splash" || value == "both"){
		$.ajax({
			type: 'POST',
			url:'/share-link/share-type-update',
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN,
			},
			cache:false,
			data:{ID:id,ShareType:value, _token: CSRF_TOKEN},
			success: function(response) {
				if(response.result !=true){
					alert("Couldn't update share type, try again later.");
				}
				reloadPreview(url);
			}
		});
	}

});


function showSlugInput(slug){
	// get link ID
	var link = $(slug).parent();
	var saveButton = $(link).find(".save-slug-btn");
	var linkID = $(saveButton).attr("ID");

	// hide current slug
	$("#fullurl-" + linkID + " " + "span#link-slug-" + linkID).hide();

	//show slug input and save btn
	$("#shareslug-" + linkID).show();
}


$('.save-slug-btn').on('click',function(){
	var id = $(this).attr('id');
	var targetID = '#shareslug-'+id;
	var slug = $(targetID).val();
	var copyButtonValue = $('#slug-copy-'+id).attr('data-clipboard-text');
	copyButtonValue = copyButtonValue.substr(0,copyButtonValue.lastIndexOf("/"));

	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

	$.ajax({
		type:'POST',
		url:'/share-link/share-slug-update',
		data:{ID:id, Slug:slug, _token: CSRF_TOKEN},
		cache:false,
		headers: {
			'X-CSRF-TOKEN': CSRF_TOKEN
		},
		success: function(response){
			if(response.result !=true){
				alert("Couldn't update slug, try again later.");
			}
			else{
				//update full url, preview btn and copy to clipboard data attribute
				$('#slug-copy-'+id).attr('data-clipboard-text',copyButtonValue+"/"+slug);
				$('#fullurl-'+id).attr('data-url', copyButtonValue+'/'+slug);
				$('#full-url-link-wrapper-'+id).attr('href', copyButtonValue+'/'+slug);
				$("#preview-link-"+id).attr('href', copyButtonValue+'/'+slug);
				$('span#link-slug-' + id).text(slug);

				$('#side_tab_'+id+' .share a.fb').attr('href', 'http://www.facebook.com/share.php?u='+copyButtonValue+'/'+slug);
				$('#side_tab_'+id+' .share a.tw').attr('href', 'https://twitter.com/share?url='+copyButtonValue+'/'+slug);
				$('#side_tab_'+id+' .share a.li').attr('href', 'http://www.linkedin.com/shareArticle?mini=true&url='+copyButtonValue+'/'+slug);

				//hide input and save button
				$('#shareslug-'+id).hide();
				$('#'+id).hide();

				//show new slug
				$('span#link-slug-' + id).show();

				//just in case link had already been copied, reset
				$(".copy-url").each(function(){
					$(this).text("Copy short-link");
				});
			}
		}
	});
});


$('.slug-url-input').on('keyup',function(){
	var slug = $(this).val();
	var id = $(this).attr('id');
	var idNumeric = id.substr(id.indexOf('-')+1);
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');


	$.ajax({
		type   : 'GET',
		url    : '/share-link/validate-slug',
		data   : {slug:slug,_token: CSRF_TOKEN},
		dataType: "JSON",
		cache  : false,
		headers: {
			'X-CSRF-TOKEN': CSRF_TOKEN
		},
		success: function(response){
			if(response.result === true){
				$("#"+id).css("border","2px solid #a4e291");
				$("#"+id).css("background-color","#a4e291");
				$('#error-'+id).html('');
				$('#'+idNumeric).show();
				$('#save-slug-btn').show();
			}
			else{
				$("#"+id).css("border","2px solid #FF6653");
				$("#"+id).css("background-color","#FF6653");
				$('#error-'+id).html('*Unavailable');
				$('#'+idNumeric).hide();
			}

		}
	});
});

tabControl();

/*
 We also apply the switch when a viewport change is detected on the fly
 (e.g. when you resize the browser window or flip your device from
 portrait mode to landscape). We set a timer with a small delay to run
 it only once when the resizing ends. It's not perfect, but it's better
 than have it running constantly during the action of resizing.
 */
var resizeTimer;
$(window).on('resize', function(e) {
	clearTimeout(resizeTimer);
	resizeTimer = setTimeout(function() {
		tabControl();
	}, 250);
});

/*
 The function below is responsible for switching the tabs when clicked.
 It switches both the tabs and the accordion buttons even if
 only the one or the other can be visible on a screen. We prefer
 that in order to have a consistent selection in case the viewport
 changes (e.g. when you esize the browser window or flip your
 device from portrait mode to landscape).
 */
function tabControl() {
	var tabs = $('.tabbed-content').find('.tabs');
	if(tabs.is(':visible')) {
		tabs.find('a').on('click', function(event) {
			event.preventDefault();
			var target = $(this).attr('href'),
				tabs = $(this).parents('.tabs'),
				buttons = tabs.find('a'),
				item = tabs.parents('.tabbed-content').find('.item');
			buttons.removeClass('active');
			item.removeClass('active');
			$(this).addClass('active');
			$(target).addClass('active');
		});
	} else {
		$('.item').on('click', function() {
			var container = $(this).parents('.tabbed-content'),
				currId = $(this).attr('id'),
				items = container.find('.item');
			container.find('.tabs a').removeClass('active');
			items.removeClass('active');
			$(this).addClass('active');
			container.find('.tabs a[href$="#'+ currId +'"]').addClass('active');
		});
	}
}

<?php
/**
 * Created by PhpStorm.
 * User: jessica
 * Date: 2017-08-14
 * Time: 12:31 PM
 */

namespace App\Tests;

use App\Http\Controllers\www\ShareLinkController;
use Grav\Tests\GravTestCase;

class ShareLinkControllerTest extends GravTestCase
{
    /**
     * @test
     */
    public function TestIsXFrameBlocked(){
        $Controller = new ShareLinkController();
        
        $URL = 'www.amazon.com';
        $results = $Controller->isXFrameBlocked($URL);
        
        $this->asserttrue($results);
    }
}

<?php $__env->startSection('body-content'); ?>
    <div class="tabs-wrapper">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-home" data-toggle="tab">General</a></li>
            <?php if($grantForm): ?>
            <li><a href="#tab-grants" data-toggle="tab">Grants</a></li>
            <?php endif; ?>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade in active" id="tab-home">
                <?php echo form_open($form); ?>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <?php echo form_element($form['Label']); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.roles.home')); ?>'"/>
                        <button type="submit" class="btn btn-default">Save Role</button>
                    </div>
                </div>
                <?php echo form_close($form); ?>

            </div>
            <?php if($grantForm): ?>
                <div class="tab-pane fade in" id="tab-grants">
                    <?php echo form_open($grantForm); ?>

                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <?php $__currentLoopData = $grantFormLookup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Application=>$ApplicationElements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <label><?php echo e($Application); ?></label>
                                <?php $__currentLoopData = $ApplicationElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$FormElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>

                                        <?php echo form_element($grantForm[$FormElement['ElementID']]); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <!--<div class="col-md-9 col-sm-12">
                            <p>This could be some info about User Management Grants.</p>
                        </div>-->
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.roles.home')); ?>'"/>
                            <button type="submit" class="btn btn-default">Save Grants</button>
                        </div>
                    </div>
                    <?php echo form_close($grantForm); ?>


                </div>
            <?php endif; ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
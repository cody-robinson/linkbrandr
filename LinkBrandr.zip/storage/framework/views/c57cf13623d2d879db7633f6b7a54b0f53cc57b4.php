<?php $__env->startSection('header-body'); ?>
    <form method="GET" action="/lib2/usermanagement/roles/adminRoleDetails">
        <input type="submit" class="btn btn-default" value="Add Admin Role">
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
        <table id="table-example" class="table table-striped data-table" role="grid">
            <thead>
            <tr role="row">
                <th></th>
                <th>Role</th>
                <th>Options</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $RolesInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$RoleInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr role="row">
                    <td><?php echo e($Key+1); ?></td>
                    <td><a href="/lib2/usermanagement/roles/adminRoleDetails/<?php echo e($RoleInfo->ID); ?>"><?php echo e($RoleInfo->Role); ?></a></td>
                    <td>
                        <a href="/lib2/usermanagement/roles/deleteAdminRole/<?php echo e($RoleInfo->ID); ?>" onclick="return confirm('Are you sure you want to delete this role?');" class="table-link danger">
                            <span class="fa-stack">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
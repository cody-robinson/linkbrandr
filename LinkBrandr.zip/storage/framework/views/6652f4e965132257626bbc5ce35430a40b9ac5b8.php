<?php $__env->startSection('header-body'); ?>
    <?php if($AllowAdminUsersAdd): ?>
    <form method="GET" action="/lib2/usermanagement/admin/adminUserDetails">
        <input type="submit" class="btn btn-default" value="Add Admin User">
    </form>
    <?php endif; ?>
    
        
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
            <table id="admin-user-listing" class="table table-striped data-table" role="grid">
                <thead>
                    <tr role="row">
                        <th></th>
                        <th>Username</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $AdminUsersInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$UserInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Key+1); ?></td>
                        <td><?php if($AllowAdminUsersAdd): ?><a href="adminUserDetails/<?php echo e($UserInfo->ID); ?>"><?php endif; ?><?php echo e($UserInfo->Username); ?><?php if($AllowAdminUsersAdd): ?></a><?php endif; ?></td>
                        <td><?php echo e($UserInfo->FirstName); ?></td>
                        <td><?php echo e($UserInfo->LastName); ?></td>
                        <td><?php echo e($UserInfo->PrimaryEmail); ?></td>
                        <td><?php echo e($UserInfo->PrimaryPhone); ?></td>
                        <td>
                            <?php if($AllowAdminUsersAdd): ?>
                            <a href="/lib2/usermanagement/admin/resetAdminUserPassword/<?php echo e($UserInfo->ID); ?>" class="table-link">
                            <span class="fa-stack">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-key fa-stack-1x fa-inverse"></i>
                            </span>
                            </a>
                            <?php endif; ?>
                            <?php if($AllowAdminUsersDelete): ?>
                            <a href="/lib2/usermanagement/admin/deleteAdminUser/<?php echo e($UserInfo->ID); ?>" onclick="return confirm('Are you sure you want to delete this user?');" class="table-link danger">
                            <span class="fa-stack">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
                            </span>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
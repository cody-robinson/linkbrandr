<?php $__env->startSection('styles'); ?>
    <style>
        html {
            overflow-y: scroll;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1>Form Definition Generator</h1>
    </div>

    <div class="row">
        <div class="col-md-12">

            <h2>Options</h2>

            <div>
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#1" data-toggle="tab">Generate from a Table</a>
                    </li>
                    <li><a href="#2" data-toggle="tab">Generate Custom Form</a>
                    </li>
                </ul>

                <div class="tab-content ">
                    <div class="tab-pane active" id="1">

                        <div id="table-gen-form">
                            <h3>Generate from a Table</h3>

                            <p><span style="color: orangered;">Warning: </span>In some cases this functionality may interpret lookup tables as sibling tables. See <a href="https://gravit-e.atlassian.net/wiki/display/Lib2/Collection+Field+Type#CollectionFieldType-LookupTableNamingConventions">lookup table naming conventions to learn more.</a></span>
                            <hr/>

                            <?php echo form_open($tableForm); ?>


                            <div class="form-group">
                                <?php echo form_element($tableForm['TableName']); ?>

                            </div>

                            <hr/>

                            <div class="row">
                                <div class="form-group col-md-2">
                                    <input id="generate" type="submit" value="Generate" class="form-control btn btn-default">
                                </div>
                            </div>

                            <?php echo form_close($tableForm); ?>

                        </div>

                    </div>
                    <div class="tab-pane" id="2">

                        <div id="config-gen-form">
                            <h3>Generate Custom Form</h3>

                            <hr/>

                            <?php echo form_open($configForm); ?>


                            <div class="row">
                                <div class="form-group col-md-12">
                                    <div class="form-group">
                                        <?php echo form_element($configForm['ClassName']); ?>

                                    </div>

                                    <div class="form-group">
                                        <?php echo form_element($configForm['Subdirectory']); ?>

                                    </div>

                                    <?php echo form_element($configForm['ClassPath'], ["widget" => ["readonly" => true]]); ?>

                                </div>
                            </div>

                            <hr/>

                            <div class="row">
                                <div class="col-xs-4">
                                    <b>Identifier</b>
                                    <p>A <em>PascalCase</em> name for the field.</p>
                                </div>

                                <div class="col-xs-4">
                                    <b>Field Type</b>
                                    <p>The fields' underlying data type. <em>This should be congruent with the Field Element Type.</em></p>
                                </div>

                                <div class="col-xs-4">
                                    <b>Field Element Type</b>
                                    <p>The way the element is rendered to html. <a href="../examples/form/elements">See this page for examples.</a></p>
                                </div>
                            </div>

                            <div id="field-rows">
                                <div id='first-row' class="field-row form-group">
                                    <div class="row">
                                        <div class="col-xs-4">
                                            <?php echo form_element_widget($configForm['FieldIdentifier'], ['class' => 'identifier form-control']); ?>

                                        </div>

                                        <div class="col-xs-4">
                                            <?php echo form_element_widget($configForm['FieldType'], ['class' => 'field-type form-control']); ?>

                                        </div>

                                        <div class="col-xs-3">
                                            <?php echo form_element_widget($configForm['FieldElementType'], ['class' => 'element-type form-control']); ?>

                                        </div>
                                        <div class="col-xs-1">
                                            <a class="btn btn-default" onclick="removeFieldRow(this)">Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-12">
                                    <a class="btn btn-default" id="new-field">Add Field</a>
                                </div>
                            </div>

                            <hr/>

                            <div class="row">
                                <div class="form-group col-md-2">
                                    <input id="generate" type="submit" value="Generate" class="form-control btn btn-default">
                                </div>
                            </div>

                            <?php echo form_close($configForm); ?>


                        </div>
                    </div>
                </div>
            </div>

            <h2>Output</h2>

            <hr/>

            <div id="console-output-container">
                <p>Nothing yet.</p>
            </div>

            <hr/>

        </div>
    </div>

    <script>

        $(document).ready(function() {

            //### config Form

            var configForm      = $('#config-gen-form');
            var fieldRows       = $('#field-rows');
            var outputContainer = $('#console-output-container');

            var classNameElem = $('#class-name');
            var classPathElem = $('#class-path');
            var subdirElem    = $('#subdirectory-label');

            classNameElem.change(calculateClassPath);
            classNameElem.on('input', calculateClassPath);

            subdirElem.change(calculateClassPath);
            subdirElem.on('input', calculateClassPath);

            function calculateClassPath () {

                var className = classNameElem.val();
                var folder    = subdirElem.val();
                var classPath = ''

                if (className.match(/FormDefinition/)) {
                    className = className.replace('FormDefinition', '');
                }

                if (folder.length > 0) {
                    classPath += folder + '/';
                }

                if (className.length > 0) {
                    classPath += className;
                }

                if (classPath.match(/Controller$/) !== true) {
                    classPath += "FormDefinition";
                }

                classPath += '.php';

                classPathElem.val('<?php echo e($basePath); ?>' + classPath);
            }

            configForm.submit(function() {
                if (!confirm('Ok to start generating?')) {
                    return false;
                }

                var elems = configForm.find('.identifier');

                for (var i = 0; i < elems.length; i++) {
                    var elem = $(elems[i]);
                    if (elem.val() == false) {
                        alert('Field Identifier is missing.');
                        return false;
                    }
                }

                generateFromConfig();

                return false;
            });

            $('#new-field').click(addNewFieldRow);

            function addNewFieldRow () {
                var lastRow = getLastFieldRow();
                var newRow  = $(lastRow).clone();
                newRow.find('input').val('').removeAttr('selected');
                fieldRows.append(newRow);
            }

            function getLastFieldRow () {
                var rows = fieldRows.find('.field-row');
                return rows[rows.length - 1];
            }

            function generateFromConfig () {
                var generateButton         = configForm.find('#generate');
                var oldGenerateButtonValue = generateButton.val();
                generateButton.attr("disabled", true);
                generateButton.val('Generating...');

                $.ajax({
                    url : '<?php echo e(route('devtools.gen.form.generate-config')); ?>',
                    data: getFormDataForConfigGeneration()
                }).done(function(data) {
                    outputContainer.empty();
                    outputContainer.html(data);
                    generateButton.removeAttr("disabled");
                    generateButton.val(oldGenerateButtonValue);
                }).fail(function() {
                    generateButton.removeAttr("disabled");
                    generateButton.val(oldGenerateButtonValue);
                });
            }

            function getFormDataForConfigGeneration () {
                var elems = $('.field-row');

                var jsonData = {
                    className: classNameElem.val(),
                    subDir: subdirElem.val(),
                    classPath: classPathElem.val(),
                    Rows: []
                };

                for (var i = 0; i < elems.length; i++) {
                    var elem        = $(elems[i]);
                    var identifier  = elem.find('.identifier').val();
                    var fieldType   = elem.find('.field-type').val();
                    var elementType = elem.find('.element-type').val();

                    jsonData.Rows.push({
                        Identifier : identifier,
                        FieldType  : fieldType,
                        ElementType: elementType
                    });
                }

                return jsonData;
            }

            //### table form

            var tableForm = $('#table-gen-form');

            tableForm.submit(function() {
                if (!confirm('Ok to start generating?')) {
                    return false;
                }

                generateFromTable();

                return false;
            });

            function generateFromTable () {
                var generateButton = tableForm.find('#generate');

                var oldGenerateButtonValue = generateButton.val();

                generateButton.attr("disabled", true);
                generateButton.val('Generating...');

                $.ajax({
                    url : '<?php echo e(route('devtools.gen.form.generate-table')); ?>',
                    data: getFormDataForTableGeneratrion()
                }).done(function(data) {
                    outputContainer.empty();
                    outputContainer.html(data);

                    generateButton.removeAttr("disabled");
                    generateButton.val(oldGenerateButtonValue);
                }).fail(function() {
                    generateButton.removeAttr("disabled");
                    generateButton.val(oldGenerateButtonValue);
                });
            }

            function getFormDataForTableGeneratrion () {
                return {
                    'TableName': $('#table-name-label').val(),
                };
            }

            calculateClassPath();

        });

        function removeFieldRow (elem) {

            var rootFieldRow = $(elem).parent().parent().parent();

            if (rootFieldRow.parent().children().length < 2) {
                return;
            }

            rootFieldRow.remove();
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
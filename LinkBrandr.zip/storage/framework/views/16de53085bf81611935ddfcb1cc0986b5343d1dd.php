<?php $__env->startSection('body-content'); ?>

    <div class="tabs-wrapper">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-home" data-toggle="tab">General</a></li>
            <?php if($grantForm): ?>
                <li><a href="#tab-grants" data-toggle="tab">Grants</a></li>
            <?php endif; ?>
            <?php if($roleForm): ?>
                <li><a href="#tab-roles" data-toggle="tab">Roles</a></li>
            <?php endif; ?>
            <?php if($preferencesForm): ?>
                <li><a href="#tab-preferences" data-toggle="tab">Preferences</a></li>
            <?php endif; ?>
            
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade in active" id="tab-home">
                <?php echo form_open($form); ?>

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['Username']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['FirstName']); ?>

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['LastName']); ?>


                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                 <?php echo form_element($form['PrimaryEmail']); ?>

                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['PrimaryPhone']); ?>

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['MobilePhone']); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['Title']); ?>

                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="form-group">
                                <?php echo form_element($form['Credentials']); ?>

                            </div>
                        </div>
                    </div>
                
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.admin.home')); ?>'"/>
                            <button type="submit" class="btn btn-default">Save User</button>
                        </div>
                    </div>
                <?php echo form_close($form); ?>

            </div>
            <?php if($grantForm): ?>
            <div class="tab-pane fade in" id="tab-grants">
                <?php echo form_open($grantForm); ?>

                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <?php $__currentLoopData = $grantFormLookup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Application=>$ApplicationElements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <label><?php echo e($Application); ?></label>
                                <?php $__currentLoopData = $ApplicationElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$FormElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        
                                     <?php echo form_element($grantForm[$FormElement['ElementID']]); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <!--<div class="col-md-9 col-sm-12">
                            <p>This could be some info about User Management Grants.</p>
                        </div>-->
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.admin.home')); ?>'"/>
                            <button type="submit" class="btn btn-default">Save Grants</button>
                        </div>
                    </div>
                <?php echo form_close($grantForm); ?>


            </div>
            <?php endif; ?>

            <?php if($roleForm): ?>
            <div class="tab-pane fade in" id="tab-roles">
                <?php echo form_open($roleForm); ?>

                
                    <?php $__currentLoopData = $roleFormLookup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$roleFormElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-md-3">
                                <?php echo form_element($roleForm[$roleFormElement['ElementID']]); ?>

                            </div>
                            <div class="col-md-9">
                                <!-- This could be added as extra info for the Roles -->
                                <!--<p>Administrators have access to all client data.</p>-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">
                        <div class="col-lg-12">
                            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.admin.home')); ?>'"/>
                            <button type="submit" class="btn btn-default">Save Roles</button>
                        </div>
                    </div>
             
                <?php echo form_close($roleForm); ?>


            </div>
            <?php endif; ?>
            <?php if($preferencesForm): ?>
                <div class="tab-pane fade in" id="tab-preferences">
                    <?php echo form_open($preferencesForm); ?>


                    <?php $__currentLoopData = $roleFormLookup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$roleFormElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-md-3">
                                <?php echo form_element($preferencesForm[$roleFormElement['ElementID']]); ?>

                            </div>
                            <div class="col-md-9">
                                <!-- This could be added as extra info for the Roles -->
                                <!--<p>Administrators have access to all client data.</p>-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                    <?php echo form_close($roleForm); ?>


                </div>
            <?php endif; ?>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
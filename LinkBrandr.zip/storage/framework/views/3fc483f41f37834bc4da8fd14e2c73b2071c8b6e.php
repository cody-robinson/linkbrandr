<?php if($renderOpeningTag): ?>
    <?php echo Form::open($options); ?>

<?php endif; ?>

<?php if($renderFields): ?>
    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $field->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($renderClosingTag): ?>
    <?php echo Form::close(); ?>

<?php endif; ?>

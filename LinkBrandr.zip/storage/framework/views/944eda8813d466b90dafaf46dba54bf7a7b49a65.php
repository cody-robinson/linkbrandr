<?php echo e($breadcrumb->preRenderSetup()); ?>


<li class="<?php if($loop->last): ?>active <?php endif; ?>" <?php echo e($breadcrumb->getListItemAttributeString()); ?>>
    <a href="<?php if($loop->last): ?># <?php else: ?><?php echo e($breadcrumb->getHref()); ?><?php endif; ?>" <?php echo e($breadcrumb->getAnchorAttributeString()); ?>><?php echo e($breadcrumb->getLabel()); ?></a>
</li>

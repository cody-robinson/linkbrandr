<!-- Main Content -->
<?php $__env->startSection('content'); ?>

    <section id="forgot-password" class="section form-section">
        <div class="space-50"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-sm-push-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h1>Reset Password</h1>
                        </div>
                        <div class="panel-body">
                            <br>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>

                            <form role="form" method="POST" action="<?php echo e(url('/password/email')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label for="name" class="control-label">11 Account Email</label><br>
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong>Please enter your account email.</strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-envelope"></i> Send Password Reset Link
                                    </button>
                                    <a href="/login" class="btn btn-primary">Back to Login</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
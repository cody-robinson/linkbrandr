<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato:100,300,400,700|Open+Sans:400,600,700,300">

    <!-- Styles -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/common/admin/style/lib2theme/libs/font-awesome.css"/>

    <?php if(isset($Lib2OverridingStyles) && $Lib2OverridingStyles): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e($Lib2OverridingStyles); ?>"/>
    <?php endif; ?>

    <?php if(isset($Favicon) && $Favicon): ?>
        <link rel="shortcut icon" href="<?php echo e($Favicon); ?>"/>
    <?php endif; ?>

    <?php echo $__env->yieldContent('styles'); ?>

<!-- Stylesheets included once -->
    <?php $__currentLoopData = $includedStylesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedStylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $includedStylesheet; ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- General Scripts -->
    <script
            src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>

    <script
            src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"
            integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
            crossorigin="anonymous"></script>

    <script src="/common/admin/scripts/lib2theme/jquery.nanoscroller.min.js"></script>

    <!-- Theme Scripts -->
    <script src="/common/admin/scripts/lib2theme/scripts.js"></script>

    <!-- App scripts -->
    <?php echo $__env->yieldContent('scripts'); ?>

<!-- Scripts included once -->
    <?php $__currentLoopData = $includedScripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedScript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo $includedScript; ?>"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</head>
<body>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>


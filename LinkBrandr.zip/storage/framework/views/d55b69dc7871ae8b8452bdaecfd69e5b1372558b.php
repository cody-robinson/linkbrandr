<?php $__env->startSection('content'); ?>

<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function toggleControllerType()
    {
        var type = jQuery('input.controller_type:checked').val();

        resetClassPaths();
    }

    function resetClassPaths()
    {
        setTimeout(calculateClassPath, 0);
    }

    function calculateClassPath()
    {
        var className = jQuery('input#ClassName').val();

        var classPath = '';

        if (className.length > 0) {
            classPath += className + '.php';
        }

        jQuery('input#ClassPath').val(jQuery('input#BasePath').val() + classPath);
    }

    function validate()
    {
        var className = jQuery('input#ClassName').val();

        if (!className) {
            alert('No class name');
            return false;
        }

        if (className == 'Controller') {
            alert('No class name');
            return false;
        }

        return true;
    }

    function preview()
    {
        if (!validate()) {
            return false;
        }

        jQuery.ajax({
            url: "<?php echo e(route('devtools.gen.service.preview')); ?>",
            type: "POST",
            data: jQuery('form#ServiceForm').serialize(),
        }).done(function(html) {
                jQuery('div#output').html( html );
            });
    }

    function generate()
    {
        if (!validate()) {
            return false;
        }

        jQuery.ajax({
            url: "<?php echo e(route('devtools.gen.service.generate')); ?>",
            type: "POST",
            data: jQuery('form#ServiceForm').serialize(),
        }).done(function(html) {
                jQuery('div#output').html( html );
            });

    }

</script>

<form method="get" name="ServiceForm" id="ServiceForm">

<h1>Service Generator</h1>

Class Name: <input type=text id=ClassName name=ClassName value="ExampleService" size="50" onKeyUp="resetClassPaths();" onBlur="resetClassPaths();"><br><br>

<input type=hidden id=BasePath name=BasePath value="<?php echo e($basePath); ?>" readonly=""><br>
File Path: <input type=text id=ClassPath name=ClassPath value="" size="100" readonly=""><br>

    <div>
        <h2>Dependencies</h2>

        <table>
            <tr>
                <th></th>
                <th>Name</th>
                <th>Type</th>
            </tr>
            <tr>
                <td>1.</td>
                <td><input type=text id=Dependency1Name name=Dependency1Name value="" size="50"></td>
                <td><input type=text id=Dependency1Type name=Dependency1Type value="" size="50"></td>
            </tr>
            <tr>
                <td>2.</td>
                <td><input type=text id=Dependency2Name name=Dependency2Name value="" size="50"></td>
                <td><input type=text id=Dependency2Type name=Dependency2Type value="" size="50"></td>
                <td></td>
            </tr>
            <tr>
                <td>3.</td>
                <td><input type=text id=Dependency3Name name=Dependency3Name value="" size="50"></td>
                <td><input type=text id=Dependency3Type name=Dependency3Type value="" size="50"></td>
                <td></td>
            </tr>
        </table>

    </div>

    <div>
        <h2>DTOs</h2>

        DTO #1<input type=text id=DTO1 name=DTO1 value="" size="50"><br/>
        <!--DTO #2<input type=text id=DTO2 name=DTO2 value="" size="50"><br/>-->

    </div>

    <div>
        <h2>Methods</h2>

        <table>
            <tr>
                <th></th>
                <th>Name</th>
                <th>Accepts / Return</th>
            </tr>
            <tr>
                <td>1.</td>
                <td><input type=text id=Method1Name name=Method1Name value="" size="50"></td>
                <td><input type="radio" name="Method1ParamReturn" value="None"> None/Default <input type="radio" name="Method1ParamReturn" value="AcceptDTO"> Accept DTO#1 <input type="radio" name="Method1ParamReturn" value="ReturnDTO"> Return DTO#1 </td>
            </tr>
            <tr>
                <td>2.</td>
                <td><input type=text id=Method2Name name=Method2Name value="" size="50"></td>
                <td><input type="radio" name="Method2ParamReturn" value="None"> None/Default <input type="radio" name="Method2ParamReturn" value="AcceptDTO"> Accept DTO#1 <input type="radio" name="Method2ParamReturn" value="ReturnDTO"> Return DTO#1 </td>

            </tr>
            <tr>
                <td>3.</td>
                <td><input type=text id=Method3Name name=Method3Name value="" size="50"></td>
                <td><input type="radio" name="Method3ParamReturn" value="None"> None/Default <input type="radio" name="Method3ParamReturn" value="AcceptDTO"> Accept DTO#1 <input type="radio" name="Method3ParamReturn" value="ReturnDTO"> Return DTO#1 </td>
            </tr>
        </table>

    </div>

    <input type=button value="Preview" onclick="preview();">
    <input type=button value="Generate"  onclick="generate();">

</form>

<div id="output">

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <section id="register-section" class="form-section section">
        <div class="section-inner">
            <div class="container text-center">
                <div class="space-50"></div>
                <h2 class="counter-desc">Sign Up</h2>
                <br>
                <div class="form-wrapper">
                    <div class="form-box">
                        <form class="form-horizontal" role="form" method="POST" action="">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="form-group col-sm-12">
                                    <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                                </div>
                                <div class="form-group col-sm-12">
                                    <div class="divider">
                                        <span class="or-text">OR</span>
                                    </div><!--//divider-->
                                </div>
                                <div class="col-sm-3"></div>
                                <div class="form-group<?php echo e($errors->has('FirstName') ? ' has-error' : ''); ?> col-sm-6 col-xs-12">
                                    <input id="firstName" type="text" class="form-control" name="firstName" value="<?php echo e(old('firstName')); ?>" required placeholder="First Name">

                                    <?php if($errors->has('FirstName')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('FirstName')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group<?php echo e($errors->has('LastName') ? ' has-error' : ''); ?> col-sm-6 col-xs-12">
                                    <input id="lastName" type="text" class="form-control" name="lastName" value="<?php echo e(old('lastName')); ?>" required placeholder="Last Name">

                                    <?php if($errors->has('LastName')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('LastName')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group<?php echo e($errors->has('Username') ? ' has-error' : ''); ?> col-sm-6 col-xs-12">
                                    <input id="username" type="email" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required placeholder="Email Address">

                                    <?php if($errors->has('Username')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> col-sm-6 col-xs-12">
                                    <input id="password" type="password" class="form-control" name="password" required placeholder="Password">

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group col-sm-6 col-xs-12">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group col-sm-6 col-xs-12">
                                    <button type="submit" class="btn btn-primary">
                                        Register
                                    </button>
                                </div>
                                <div class="col-sm-3"></div>

                                <div class="col-sm-3"></div>
                                <div class="form-group col-sm-6 col-xs-12">
                                    <label>Already have an account?</label><br>
                                    <a href="/login" class="btn btn-primary"><i class="fa fa-btn fa-sign-in"></i> Log in</a>
                                </div>
                                <div class="col-sm-3"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('www.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
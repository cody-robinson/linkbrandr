<?php $__env->startSection('content'); ?>
    <h1>Layouts</h1>

    <h2>Same Form : Different Layouts</h2>

    <div id="exTab2" class="container">
        <ul class="nav nav-tabs">
            <li class="active">
                <a href="#1" data-toggle="tab">No Layout</a>
            </li>
            <li>
                <a href="#2" data-toggle="tab">Basic Layout</a>
            </li>
            <li>
                <a href="#3" data-toggle="tab">Split Layout</a>
            </li>
        </ul>

        <div class="tab-content ">
            <div class="tab-pane active" id="1">
                <h3>No Layout</h3>

                <pre>{!! form($form) !!}</pre>

                <hr>

                <div>
                    <?php echo form($form); ?>

                </div>
            </div>
            <div class="tab-pane" id="2">
                <h3>Basic Layout / Table Style Layout</h3>
                <pre>@include('formLayouts::tabular.basic', [$form])</pre>

                <hr>

                <div>
                    <?php echo e(form_reset($form)); ?>

                    <?php echo $__env->make('formLayouts::tabular.basic', [$form], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <div class="tab-pane" id="3">
                <h3>Split Layout</h3>
                <pre>@include('formLayouts::tabular.split', [$form, 'split' => 'BootstrapRadioCollection'])</pre>

                <hr>

                <div>
                    <?php echo e(form_reset($form)); ?>

                    <?php echo $__env->make('formLayouts::tabular.split', [$form, 'split' => 'BootstrapRadioCollection'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
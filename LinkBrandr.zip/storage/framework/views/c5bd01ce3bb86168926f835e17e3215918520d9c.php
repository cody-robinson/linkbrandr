<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
        <table id="table-example" class="table table-striped data-table" type="grid">
            <thead>
            <tr type="row">
                <th></th>
                <th>Type</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $UserTypesInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$TypeInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr type="row">
                    <td><?php echo e($Key+1); ?></td>
                    <td><a href="/lib2/usermanagement/types/userTypeDetails/<?php echo e($TypeInfo->ID); ?>"><?php echo e($TypeInfo->UserType); ?></a></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>

<?php if($renderWidget): ?>
    <div <?php echo $field->toAttrString($widgetAttributes); ?>>
        <?php $__currentLoopData = $field->getCombinedCollection(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="multi-checkbox-child">
                <?php echo Form::checkbox($field->getName() . '[]', $tuple['key'], in_array($tuple['key'], $field->getValue()), ['id' => '']); ?>

                <?php echo Form::label($field->getName(), $tuple['value']); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php if($renderErrors): ?>
    <?php if($errors->first($field->getName())): ?>
        <div id="<?php echo e($field->getId()); ?>-error" class="field-error">
            <?php echo e($errors->first($field->getName())); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

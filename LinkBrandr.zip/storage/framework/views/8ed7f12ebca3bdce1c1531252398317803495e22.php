<?php $__env->startSection('content'); ?>

    <!-- if button isn't set, make whole bar a link -->
    <?php if(!empty($user->ProfileURL)): ?>
        <a href="<?php echo $user->ProfileURL; ?>" class="brandr-wrapper" target="_blank">
    <?php endif; ?>

    <!-- theme changes by adding class theme-one, theme-two, or theme-three -->
    <table class="brandr-bar <?php echo $CSSClassName; ?>" style="background-color: <?php echo $BackgroundColor; ?>">
        <tbody>
        <tr>
            <td class="branding" style="width: 20%;">
                <table style="<?php if($CSSClassName != 'theme-one'): ?> background-color: <?php echo $ButtonColor; ?> <?php endif; ?>">
                    <tbody>
                    <tr>
                        <td>
                            <?php if(!empty($user->ProfileImage)): ?>
                                <div class="image-cropper <?php if($user->ImageType == 'Headshot'): ?>with-crop <?php elseif($user->ImageType == 'Logo'): ?>no-crop <?php endif; ?> <?php if($user->ImageOrientation == 'landscape'): ?>landscape <?php elseif($user->ImageOrientation == 'portrait'): ?>portrait <?php endif; ?>">
                                    <img src="<?php echo url('/public/uploads/profile-images/'.$user->ID.".".pathinfo($user->ProfileImage, PATHINFO_EXTENSION)); ?>?avoidCache=<?php echo $user->LastModified; ?>"/>
                                </div>
                            <?php else: ?>
                                <div class="space"></div>
                            <?php endif; ?>
                        </td>

                        <td class="client-details <?php if(!empty($user->ProfileImage) && $user->ImageType == 'Logo'): ?> hide-mobile <?php endif; ?>" style="<?php if(empty($user->BusinessName) && empty($user->BusinessDescription)): ?> display: none; <?php endif; ?>">
                            <h1 class="name" <?php if($CSSClassName == 'theme-one'): ?> style="color: <?php echo $ButtonColor; ?>" <?php endif; ?>><?php echo $user->BusinessName; ?></h1>
                            <h2 class="title"><?php if(!empty($user->BusinessDescription)): ?><?php echo $user->BusinessDescription; ?><?php endif; ?></h2>
                            <i class="fa fa-caret-right" style="<?php if($CSSClassName == 'theme-two'): ?> color: <?php echo $ButtonColor; ?> <?php endif; ?>"></i>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>

            <td class="tagline" style="width: 60%;">
                <?php if(!empty($user->Headline)): ?>
                    <p><?php echo $user->Headline; ?></p>
                <?php endif; ?>
            </td>

            <td class="contact-button" style="width: 20%;">
                <?php if(!empty($user->ButtonText) && !empty($user->ProfileURL)): ?>
                    <a href="<?php echo $user->ProfileURL; ?>" class="btn btn-default get-in-touch" style="<?php if($CSSClassName == 'theme-one'): ?> background-color: <?php echo $ButtonColor; ?>; <?php endif; ?> <?php if($CSSClassName == 'theme-two'): ?> border-color: <?php echo $ButtonColor; ?>; <?php endif; ?>" target="_blank"><?php echo $user->ButtonText; ?></a>
                <?php endif; ?>
            </td>

        </tr>
        </tbody>
    </table>
    <div class="spacer"></div>

    <?php if(!empty($user->ProfileURL)): ?>
        </a>
    <?php endif; ?>

    <div class="iframe-wrapper">
        <iframe frameborder="0" class="iframe" src="" id="sharedLinkIframe" data-url="<?php echo $sharedLink; ?>"></iframe>
    </div>

<script>
	function setIframeSrc() {
		var iframe = document.getElementById('sharedLinkIframe');
		var s = iframe.getAttribute('data-url');

		if ( -1 == navigator.userAgent.indexOf("MSIE") ) {
			iframe.src = s;
		}
		else {
			iframe.location = s;
		}
	}
	window.onload = function(){
        setIframeSrc();
        checkDeviceType();

        // only want to apply overflow hidden to html of iframe page
        $('html').css("overflow", "hidden");
	};

    function checkDeviceType(){

        var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
        if (iOS) {
            $("#sharedLinkIframe").attr('scrolling', 'no');
        } else {
            $("#sharedLinkIframe").attr('scrolling', 'yes');
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.publicViewapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo e(UI::includeScript(common_path('scripts/form/field-element.js'))); ?>


<?php echo e(UI::includeStylesheet(common_path('styles/form/fields/switch.css'))); ?>


<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>

<?php if($renderWidget): ?>
    <div class="onoffswitch" onclick="FieldElement.Switch.toggleSwitch(document.getElementById('<?php echo e($field->getId()); ?>'));">
        <input type="checkbox" id="<?php echo e($field->getId()); ?>" name="<?php echo e($field->getName()); ?>" class="onoffswitch-checkbox" value="<?php echo e($field->getName()); ?>" <?php if($field->getValue()): ?> checked='checked' <?php endif; ?>>
        <label class="onoffswitch-label" for="<?php echo e($field->getName()); ?>">
            <div class="onoffswitch-inner"></div>
            <div class="onoffswitch-switch"></div>
        </label>
    </div>
<?php endif; ?>

<?php if($renderErrors): ?>
    <?php if($errors->first($field->getName())): ?>
        <div id="<?php echo e($field->getId()); ?>-error" class="field-error">
            <?php echo e($errors->first($field->getName())); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

<?php echo '<'; ?>?php

namespace Grav\Models\<?php echo e($Prefix); ?>;

use Grav\Database\Eloquent\GModel;

<?php echo $MagicPropertiesComment; ?>


class <?php echo e(str_singular($Suffix)); ?> extends GModel
{
	protected $table = '<?php echo e($TableName); ?>';

<?php if($HasTimestamps === false): ?>
	public $timestamps = false;
<?php endif; ?>

<?php $__currentLoopData = $BelongsToRelationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo $Relationship->GenerateMethod(); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $HasRelationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo $Relationship->GenerateMethod(); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $BelongsToManyRelationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo $Relationship->GenerateMethod(); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($GenerateDates && count($DateColumns)): ?>
	public function getDates()
	{
		return array_merge(parent::getDates(), ['<?php echo implode("', '", $DateColumns); ?>']);
	}
<?php endif; ?>

<?php if($GenerateToString): ?>
	public function __toString()
	{
		return $this-><?php echo e(str_singular($Suffix)); ?>;
	}
<?php endif; ?>

	<?php echo $CustomCodeOpenTag; ?><?php echo $CustomCode; ?><?php echo $CustomCodeCloseTag; ?>


}

<?php $__env->startSection('content'); ?>
    <h1>Lib2 Devtools</h1>

    <h2>Examples</h2>
    <ul>
        <li><a href="devtools/examples/form">Form Examples</a></li>
        <li><a href="devtools/examples/form">Controller Examples</a></li>
    </ul>

    <h2>Generators</h2>
    <ul>
        <li><a href="devtools/generators/gmodel">GModel Generator</a></li>
        <li><a href="devtools/generators/form">Form Generator</a></li>
        <li><a href="devtools/generators/controller">Controller Generator</a></li>
        <li><a href="devtools/generators/service">Service Generator</a></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <h1>Form Examples</h1>
    <ul>
        <li><a href="form/layouts">Form Layouts</a></li>
        <li><a href="form/elements">Form Elements</a></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
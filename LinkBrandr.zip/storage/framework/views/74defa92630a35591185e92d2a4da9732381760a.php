<?php echo e(UI::includeScript('https://code.jquery.com/ui/1.12.1/jquery-ui.js')); ?>

<?php echo e(UI::includeStylesheet('https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css')); ?>

<?php echo e(UI::includeScript(common_path('scripts/form/field-element.js'))); ?>


<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>

<?php if($renderWidget): ?>
    <?php echo Form::hidden($field->getValueName(), $field->getValue(), ['id' => $field->getValueId()]); ?>

    <?php echo Form::text($field->getLabelName(), $field->getLabelValue(), ['id' => $field->getLabelId(), 'class' => 'form-control']); ?>

    <script>
        $(document).ready(function() {
            FieldElement.autoComplete(
                document.getElementById('<?php echo e($field->getLabelId()); ?>'),
                {
                    <?php if($field->getDataSourceType() == 'json'): ?>
                    source: [<?php echo $field->getSource(); ?>],
                    <?php elseif($field->getDataSourceType() == 'ajax'): ?>
                    source: function( request, response ) {
                        $.ajax({
                            url: '<?php echo $field->getAjaxUrl(); ?>',
                            dataType: "jsonp",
                            data: {
                                q: request.term
                            },
                            success: function( data ) {
                                response( data );
                            }
                        });
                    },
                    minLength: 2,
                    delay: 150,
                    <?php endif; ?>
                    select: function(event, ui) {
                        event.preventDefault();
                        $('#<?php echo $field->getLabelId(); ?>').val(ui.item.label);
                        $('#<?php echo $field->getValueId(); ?>').val(ui.item.value);
                    },
                    focus: function(event, ui) {
                        event.preventDefault();
                        $('#<?php echo $field->getLabelId(); ?>').val(ui.item.label);
                        $('#<?php echo $field->getValueId(); ?>').val(ui.item.value);
                    }
                }
            );
        });
    </script>
<?php endif; ?>

<?php if($renderErrors): ?>
    <?php if($errors->first($field->getName())): ?>
        <div id="<?php echo e($field->getId()); ?>-error" class="field-error">
            <?php echo e($errors->first($field->getName())); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

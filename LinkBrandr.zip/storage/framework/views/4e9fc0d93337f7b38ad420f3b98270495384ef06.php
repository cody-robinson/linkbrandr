<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>LinkBrandr: Grow your brand each time you share a link</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="https://file.myfontastic.com/BQ5rqoUxsfQGHC35jWa5Ub/icons.css">
    <!-- Google fonts - Open Sans-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800">
    <!-- owl carousel-->
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/css/style.blue.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="/public/css/custom-from-theme.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/images/favicon.ico" />
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

    <!-- Live chat -->
    <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="b74ccecc-15e2-41fe-b28c-6bd58c575f79";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</head>
<body>

<!-- rather than extending main layout template,
including header here so smooth scroll will work on index page -->

<!-- navbar-->
<header class="header">
    <nav class="navbar navbar-expand-lg fixed-top">
        <a href="/" class="navbar-brand">
            <img src="/public/images/link-brandr-logo.png" class="logo"/>
        </a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><span></span><span></span><span></span></button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto align-items-start align-items-lg-center">
                <li class="nav-item"><a href="#how-it-works" class="nav-link link-scroll">How it Works</a></li>
                <li class="nav-item"><a href="#features" class="nav-link link-scroll">Features</a></li>
                <li class="nav-item"><a href="#pricing" class="nav-link link-scroll">Pricing</a></li>
            <?php if(Auth::guest() && Auth::guard('web')->guest()): ?>
                <!-- only show Login button if user is not logged in -->
                    <li class="nav-item"><a href="/login" class="nav-link link-scroll">Log In</a></li>
            <?php else: ?>
                <!-- otherwise, link should say Dashboard -->
                    <li class="nav-item"><a href="/login" class="nav-link link-scroll">Dashboard</a></li>
                <?php endif; ?>
            </ul>

            <!-- only show free trial button in nav if user isn't logged in -->
            <?php if(Auth::guest() && Auth::guard('web')->guest()): ?>
                <div class="navbar-text">
                    <!-- Button trigger modal--><a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary navbar-btn btn-shadow btn-gradient">Free Trial</a>
                </div>
            <?php endif; ?>
        </div>
    </nav>
</header>
<!-- Modal-->
<div id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade">
    <div role="document" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="exampleModalLabel" class="modal-title">Start Your Free Trial Today</h5>
                <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="/register" id="signupform">
                    <?php echo e(csrf_field()); ?>

                    <div class="facebook-login text-center">
                        <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                        <div class="divider">
                            <span class="or-text" style="margin-bottom:10px;margin-top:10px;">OR</span>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('FirstName') ? ' has-error' : ''); ?>">
                        <input id="firstName" type="text" class="form-control" name="firstName" value="<?php echo e(old('firstName')); ?>" required placeholder="First Name">

                        <?php if($errors->has('FirstName')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('FirstName')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('LastName') ? ' has-error' : ''); ?>">
                        <input id="lastName" type="text" class="form-control" name="lastName" value="<?php echo e(old('lastName')); ?>" required placeholder="Last Name">

                        <?php if($errors->has('LastName')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('LastName')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group<?php echo e($errors->has('Username') ? ' has-error' : ''); ?>">
                        <input id="username" type="email" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required placeholder="Email Address">

                        <?php if($errors->has('Username')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('Username')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <div class="input-group">
                            <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                        </div>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <div class="input-group">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary form-control">
                            Register
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <!-- Modal-->
    <div id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade">
        <div role="document" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel" class="modal-title">Start Your Free Trial Today</h5>
                    <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
                    <form role="form" method="POST" action="/register" id="signupform" >
                        <input type="hidden" name="_token" value="NliKcoVRRnQa59KrHbtS0qDk0ofcYk0dyXGlNGy5">
                        <div class="facebook-login text-center">
                            <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                            <div class="divider">
                                <span class="or-text" style="margin-bottom:10px;margin-top:10px;">OR</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <input id="firstName" type="text" class="form-control" name="firstName" value="" required placeholder="First Name">
                        </div>
                        <div class="form-group">
                            <input id="lastName" type="text" class="form-control signup-input" name="lastName" value="" required placeholder="Last Name">
                        </div>
                        <div class="form-group">
                            <input id="username" type="email" class="form-control signup-input" name="username" value="" required placeholder="Email Address">
                        </div>
                        <div class="form-group">
                            <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                        </div>
                        <div class="form-group">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="submit btn btn-primary btn-shadow btn-gradient">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <section id="hero" class="hero hero-home bg-gray" style="padding-top:150px;padding-bottom:150px;">
        <div class="container">
            <div class="row d-flex">
                <div class="col-lg-6 text order-2 order-lg-1">
                    <h1>Grow your brand each time you share a link</h1>
                    <p class="hero-text">Stop wasting your valuable traffic. Every link shared through LinkBrandr helps you grow your brand.</p>
                    <div class="CTA"><a href="#how-it-works" class="btn btn-primary btn-shadow btn-gradient link-scroll">Discover More</a><a href="#"  data-toggle="modal" data-target="#exampleModal"  class="btn btn-outline-primary">Start Free Trial</a></div>
                </div>
                <div class="col-lg-6 order-1 order-lg-2"><img src="/public/img/main-test-3.png" alt="..." class="img-fluid main"></div>
            </div>
        </div>
    </section>
    <section id="how-it-works" class="browser">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="h3 mb-5">How it works</h2>
                    <div class="browser-mockup">
                        <div id="nav-tabContent" class="tab-content">
                            <div id="nav-first" role="tabpanel" aria-labelledby="nav-first-tab" class="tab-pane fade show active"><img src="/public/img/stepone.png" alt="..." class="img-fluid"></div>
                            <div id="nav-second" role="tabpanel" aria-labelledby="nav-second-tab" class="tab-pane fade"><img src="/public/img/steptwo.png" alt="..." class="img-fluid"></div>
                            <div id="nav-third" role="tabpanel" aria-labelledby="nav-third-tab" class="tab-pane fade"><img src="/public/img/stepthree.png" alt="..." class="img-fluid"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="myTab" role="tablist" class="nav nav-tabs">
                <div class="row">
                    <div class="col-md-4"><a id="nav-first-tab" data-toggle="tab" href="#nav-first" role="tab" aria-controls="nav-first" aria-expanded="true" class="nav-item nav-link active"> <span class="number">1</span>Generate a LinkBrandr link for any content you want to share with your followers in just a few seconds.</a></div>
                    <div class="col-md-4"><a id="nav-second-tab" data-toggle="tab" href="#nav-second" role="tab" aria-controls="nav-second" class="nav-item nav-link"> <span class="number">2</span>Share your LinkBrandr link on your social media accounts, email newsletters or anywhere else you have followers.</a></div>
                    <div class="col-md-4"><a id="nav-third-tab" data-toggle="tab" href="#nav-third" role="tab" aria-controls="nav-third" class="nav-item nav-link"> <span class="number">3</span>Anyone that clicks on your link will be reminded of your brand & urged to take action thanks to the LinkBrandr banner or redirect page!</a></div>
                </div>
            </div>
        </div>
    </section>
    <section id="about-us" class="about-us bg-gray">
        <div class="container">
            <h2>Share content without wasting traffic</h2>
            <div class="row">
                <p class="lead col-lg-10">Every time you share a link you drive traffic away from your website or social media accounts. Even worse, if your content is shared by others then people don’t know who initially shared the valuable content they’re now consuming! With LinkBrandr there’s finally a way to share great content without driving people away.</p>
            </div><a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary btn-shadow btn-gradient">Start free trial</a>
        </div>
    </section>
    <section id="features" class="features">
        <div class="container">
            <div class="row d-flex align-items-center" style="margin-bottom:125px;">
                <div class="text col-lg-6 order-2 order-lg-1">
                    <h4>Option 1: Customizable Banner</h4>
                    <p>LinkBrandr gives you the option to have a banner appear at the top of each page you share using a LinkBrandr link. You can customize the content with your business name, a custom message, and even a call to action. You can even style it to make sure it fits with your brand identity.</p><a href="#"  data-toggle="modal" data-target="#exampleModal" class="btn btn-primary btn-shadow btn-gradient">Start free trial</a>
                </div>
                <div class="image col-lg-6 order-1 order-lg-2"><img src="/public/img/banner-old.png" alt="..." class="img-fluid"></div>
            </div>
            <div class="row d-flex align-items-center" style="margin-bottom:125px;">
                <div class="image col-lg-6"><img src="/public/img/redirect-frame.png" alt="..." class="img-fluid"></div>
                <div class="text col-lg-6">
                    <h4>Option 2: Custom Redirect Page</h4>
                    <p>If you choose this option then a custom redirect page will appear each time anyone clicks on your LinkBrandr link. For a few seconds you’ll have their full attention and an opportunity to display your brand, your custom message, and a call to action!</p><a href="#"  data-toggle="modal" data-target="#exampleModal"  class="btn btn-primary btn-shadow btn-gradient">Start free trial</a>
                </div>
            </div>
            <div class="row d-flex align-items-center" style="margin-bottom:0px;">
                <div class="text col-lg-6 order-2 order-lg-1">
                    <h4>Option 3: Best of both worlds</h4>
                    <p>Looking for the ultimate way to grow your brand? Combine the LinkBrandr banner and redirect page and enjoy twice the brand exposure!</p><a href="#"  data-toggle="modal" data-target="#exampleModal"  class="btn btn-primary btn-shadow btn-gradient">Start free trial</a>
                </div>
                <div class="image col-lg-6 order-1 order-lg-2"><img src="/public/img/browser-examples.png" alt="..." class="img-fluid"></div>
            </div>
        </div>
    </section>
    <section id="extra-features" class="extra-features bg-primary" style="padding-bottom:50px;">
        <div class="container text-center">
            <header>
                <h2>Made with Love</h2>
                <div class="row">
                    <p class="lead col-lg-8 mx-auto">We're a small company dedicated to providing the best possible experience.</p>
                </div>
            </header>
            <div class="grid row">
                <div class="item col-lg-4 col-md-6">
                    <div class="icon"> <i class="icon-speedometer"></i></div>
                    <h3 class="h5">Fast & Easy Setup</h3>
                    <p>Easy set up in seconds with no technical knowledge required. Sign in with one click and post directly to Facebook, Twitter, and LinkedIn from our easy-to-manage dashboard.</p>
                </div>
                <div class="item col-lg-4 col-md-6">
                    <div class="icon"> <i class="icon-smartphone"></i></div>
                    <h3 class="h5">Works on all devices & browsers</h3>
                    <p>Optimized for all devices. No matter how your followers click on your links - on their desktop, laptop, tablet, or phone - you can rely on LinkBrandr to grow your brand awareness.</p>
                </div>
                <div class="item col-lg-4 col-md-6">
                    <div class="icon"> <i class="icon-customer-service"></i></div>
                    <h3 class="h5">World class customer service</h3>
                    <p>We're here to help you succeed. Real people are waiting to assist you and can be reached through email, website chat, and our help forums.</p>
                </div>
            </div>
        </div>
    </section>
    <section id="pricing" class="pricing" style="padding-top:75px;padding-bottom:75px;">
        <div class="container text-center">
            <h2>Simple, easy to understand pricing.</h2>

            <div class="row d-md-flex mt-4 text-center" style="min-width:400px;">

                <div class="col-sm-3 mt-4">
                </div>
                <div class="col-sm-6 mt-4">
                    <div class="card card-outline-primary" id="pricing-block">
                        <div class="card-block">
                            <h5 class="card-title pt-4 text-orange">Start your risk free trial now, no credit card required.</h5>

                            <div class="btn-group" id-"toggle" data-toggle="buttons" style="margin-top:15px;margin-bottom:15px;">
                            <label class="btn btn-primary active" id="toggle-monthly">
                                <input type="radio" name="options" id="option1" autocomplete="off" checked> Monthly
                            </label>
                            <label class="btn btn-primary" id="toggle-annual">
                                <input type="radio" name="options" id="option2" autocomplete="off"> Annual
                            </label>
                        </div>

                        <div class="row">
                            <div class="col-sm-12" id="monthly-price">
                                <h3 class="card-title text-primary pt-4">$7.99 / month</h3>
                                <p class="card-text text-muted pb-3 border-bottom">Pay as you go!</p>
                            </div>
                            <div class="col-sm-12 is-hidden" id="annual-price">
                                <h3 class="card-title text-primary pt-4">$79.99 / year</h3>
                                <p class="card-text text-muted pb-3 border-bottom">2 months for free!</p>
                            </div>
                        </div>
                        <ul class="list-unstyled pricing-list">
                            <li>Easy to use <b>dashboard</b></li>
                            <li>Link shortening & <b>customization</b></li>
                            <li>LinkBrandr <b>Bar & Redirection Page</b></li>
                            <li><b>Exponential reach</b> on shares and retweets</li>
                            <li><b>Call to action</b> on every page</li>
                        </ul>
                        <a href="#"  data-toggle="modal" data-target="#exampleModal"  class="btn btn-primary btn-shadow btn-gradient" style="margin-bottom:25px;">Start Free Trial Now</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 mt-4">
            </div>
        </div>
    </section>
    <section id="signup-section" class="form-section section bg-gray">
        <div class="section-inner">
            <div class="container text-center">
                <div class="counter-container">
                </div><!--//counter-container-->
                <div class="form-wrapper">
                    <h2 class="form-title signup-title">Start Your Free Trial Today</h2>
                    <div class="form-box text-center" style="max-width:400px;margin-left:auto;margin-right:auto;">
                        <form role="form" method="POST" action="/register" id="signupform">
                            <?php echo e(csrf_field()); ?>

                            <div class="facebook-login text-center">
                                <a href="/login/facebook" class="btn btn-primary facebook"><i class="fa fa-facebook-official"></i> Login With Facebook </a>
                                <div class="divider">
                                    <span class="or-text" style="margin-bottom:10px;margin-top:10px;">OR</span>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('FirstName') ? ' has-error' : ''); ?>">
                                <input id="firstName" type="text" class="form-control" name="firstName" value="<?php echo e(old('firstName')); ?>" required placeholder="First Name">

                                <?php if($errors->has('FirstName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('FirstName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('LastName') ? ' has-error' : ''); ?>">
                                <input id="lastName" type="text" class="form-control" name="lastName" value="<?php echo e(old('lastName')); ?>" required placeholder="Last Name">

                                <?php if($errors->has('LastName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('LastName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('Username') ? ' has-error' : ''); ?>">
                                <input id="username" type="email" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required placeholder="Email Address">

                                <?php if($errors->has('Username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <div class="input-group">
                                    <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                                </div>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary form-control">
                                    Register
                                </button>
                            </div>
                        </form>
                    </div><!--//form-box-->
                </div><!--//form-wrapper-->

            </div><!--//container-->
        </div><!--//section-inner-->
    </section>

    <div id="scrollTop">
        <div class="d-flex align-items-center justify-content-end"><i class="fa fa-long-arrow-up"></i>To Top</div>
    </div>

<footer class="main-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <a href="#hero" class="brand link-scroll">
                    <img src="/public/images/link-brandr-logo.png" class="logo"/>
                </a>
                <ul class="social-icons list-inline">
                    <li class="list-inline-item"><a href="https://www.facebook.com/linkbrandr" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="https://twitter.com/LinkBrandr" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <ul class="links list-unstyled">
                    <li> <a href="/privacy">Privacy</a></li>
                    <li> <a href="/terms">Terms of Service</a></li>
                    <li> <a href="/contact">Contact</a></li>
                </ul>
            </div>
            <div class="col-lg-6 col-md-6">
                <h5>Newsletter</h5>
                <!-- Begin MailChimp Signup Form -->
                <div id="mc_embed_signup">
                    <form action="//linkbrandr.us16.list-manage.com/subscribe/post?u=530e1a71bd5a296f546a90bd6&amp;id=fc2bf8edfc" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                        <div id="mc_embed_signup_scroll">
                            <p>Be the first to learn about our latest product updates</p>
                            <input type="email" value="" name="EMAIL" class="email form-control" id="mce-EMAIL" placeholder="email address" required>
                            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                            <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_530e1a71bd5a296f546a90bd6_fc2bf8edfc" tabindex="-1" value="" class="form-control"></div>
                            <div class="clear">
                                <input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button btn btn-primary"></div>
                        </div>
                    </form>
                </div>
                <!--End mc_embed_signup-->
            </div>
        </div>
    </div>
    <div class="copyrights">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <p>&copy; 2017 LinkBrandr.com. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Javascript files-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"> </script>
<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="/public/js/front.js"></script>
<!-- Google Analytics: -->
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-102275980-1', 'auto');
    ga('send', 'pageview');
</script>

<!-- Drip -->
<script type="text/javascript">
    var _dcq = _dcq || [];
    var _dcs = _dcs || {};
    _dcs.account = '3425290';
    (function() {
        var dc = document.createElement('script');
        dc.type = 'text/javascript'; dc.async = true;
        dc.src = '//tag.getdrip.com/3425290.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(dc, s);
    })();
</script>
<!-- End Drip -->

</body>
</html>

<?php $__env->startSection('content'); ?>

    <script src='https://js.stripe.com/v2/' type='text/javascript'></script>
    <section id="subscription-details" class="section form-section">
        <div class="container">
            <p>Your account details were successfully updated!</p>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('body-content'); ?>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo Session::get('success'); ?></div>
    <?php endif; ?>
    <?php if(Session::has('failure')): ?>
        <div class="alert alert-danger"><?php echo Session::get('failure'); ?></div>
    <?php endif; ?>

    <?php echo form_open($form); ?>


    <?php echo form_element($form['ID']); ?>


    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['NewPassword']); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['ConfirmPassword']); ?>


            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.users.home')); ?>'"/>
            <button type="submit" class="btn btn-default">Save Password</button>
        </div>
    </div>
    <?php echo form_close($form); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo e($Relationship->phpDocBlock()); ?>

	public function <?php echo e($Relationship->methodName()); ?>()
	{
		return $this->belongsTo('<?php echo e($Relationship->explicitClassName()); ?>', '<?php echo e($Relationship->foreignKey); ?>', '<?php echo e($Relationship->localKey); ?>');
	}
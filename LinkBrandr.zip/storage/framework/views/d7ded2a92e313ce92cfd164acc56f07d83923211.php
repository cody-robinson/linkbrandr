<?php if($item->currentUserIsAuthorized()): ?>

    <?php echo e($item->preRenderSetup()); ?>


    <li <?php echo $item->getListItemAttributeString(); ?>>
        <a <?php echo $item->getAnchorAttributeString(); ?>>
            <i <?php echo $item->getIconAttributeString(); ?>></i>
            <span><?php echo e($item->getLabel()); ?></span>
            <?php if($item->hasItems()): ?><i class="fa fa-angle-right drop-icon"></i><?php endif; ?>
        </a>

        <?php if($item->hasItems()): ?>
            <ul class="submenu" <?php if($item->isOpen()): ?> style="display: block;" <?php endif; ?>>
                <?php $__currentLoopData = $item->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('gravUI::sidebar.sidebar-item', ['item' => $item], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>

<?php endif; ?>

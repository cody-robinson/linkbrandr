<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Welcome to LinkBrandr</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <style>
            h1 {
                margin: 15px 0 0 0;
            }
            p {
                font-size: 20px;
                margin: 0;
            }
            table tbody tr td p {
                text-align: left;
            }
        </style>
    </head>
    <body style="text-align: center; background-color: white;">

        <a href="http://www.linkbrandr.com/login" target="blank" style="display: block; margin: 0 auto;"><img class="logo" src="http://www.linkbrandr.com/public/images/email-logo.png" style="max-width: 500px;"></a>

        <div style="height: 20px; width: 100%;"></div>

        <p class="highlight" style="font-size: 25px;">Welcome to LinkBrandr!</p>

        <div style="height: 15px; width: 100%;"></div>

        <p class="highlight" style="font-size: 25px;">We are excited to have you here and look forward to sharing our platform with you as we grow together!</p>

        <div style="height: 15px; width: 100%;"></div>

        <p>Getting started is easy, just follow these simple steps!</p>

        <div style="height: 25px; width: 100%;"></div>

        <h1 style="font-size: 40px;">The LinkBrandr Checklist:</h1>

        <div style="height: 20px; width: 100%;"></div>

        <table style="width: 390px; display: block; margin: 0 auto;">
            <tbody>
            <tr><td><div class="box"><img src="http://www.linkbrandr.com/public/images/check.png"/></div></td>
                <td><p style="margin-top:5px;">Customize your LinkBrandr profile</p></td>
            </tr>
            <tr>
                <td><div class="box"><img src="http://www.linkbrandr.com/public/images/box.png"/></div></td>
                <td><p style="margin-top:5px;">Generate your first branded short-link</p></td>
            </tr>
            <tr>
                <td><div class="box"><img src="http://www.linkbrandr.com/public/images/box.png"/></div></td>
                <td><p style="margin-top:5px;">Share with your network</p></td>
            </tr>
            <tr>
                <td><div class="box"><img src="http://www.linkbrandr.com/public/images/box.png"/></div></td>
                <td><p style="margin-top:5px;">Engage your followers!</p></td>
            </tr>
            </tbody>
        </table>

        <div style="clear: both"></div>
        <div style="height: 35px; width: 100%;"></div>

        <a href="http://www.linkbrandr.com/login" style="font-size: 30px; color: red; background-color: black; padding: 15px 30px; text-decoration: none; display: block; margin: 0 auto; width: 250px;" target="blank">Create a link now</a>

        <div style="height: 30px; width: 100%;"></div>

        <div class="social" style="width: 200px; display: block; margin: 0 auto">
            <a href="http://www.facebook.com/linkbrandr" class="social" target="blank"><img src="http://www.linkbrandr.com/public/images/facebook.png" width="60"></a>
            <a href="http://www.instagram.com/linkbrandr" class="social" target="blank"><img src="http://www.linkbrandr.com/public/images/instagram.png" width="60"></a>
            <a href="http://www.twitter.com/LinkBrandr" class="social" target="blank"><img src="http://www.linkbrandr.com/public/images/twitter.png" width="60"></a>
        </div>

    </body>
</html>


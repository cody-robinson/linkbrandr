<div class="error-container">
<?php $__env->startSection('content'); ?>
        <section id="error" class="section">
            <div class="display-table">
                <div class="verticle-middle">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="misc-box text-center">
                                    <i class="ion-bug error-sign"></i>
                                    <h3>Oops! Page Not Found.</h3>
                                    <p class="margin-b-0">
                                        The page you're looking for is not found, Please try later or back to <a href="/share-link/listing">Home</a>.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('www.layouts.basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
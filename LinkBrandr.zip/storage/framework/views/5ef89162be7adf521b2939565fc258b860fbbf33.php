<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link rel="shortcut icon" href="/public/images/favicon.ico" />
    <title>Link Brandr</title>

    <!-- plugins -->
    <link href="/public/css/plugins/bundle.css" rel="stylesheet">
    <!--main css file-->
    <link href="/public/css/style.css" rel="stylesheet">
    <link href="/public/css/custom.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<body id="app-layout">
<div id="preloader">
    <div id="preloader-inner"></div>
</div><!--/preloader-->

<nav class="navbar navbar-toggleable-md navbar-light fixed-top  navbar-transparent clearfix">
    <div class="container">
        <!-- Collapsed Hamburger -->
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#app-navbar-collapse" aria-controls="app-navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Branding Image -->

        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="/public/images/brandr_logo.png" alt="Link Brandr">
        </a>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto scroll-to">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/share-link/listing')); ?>">Home</a></li>
                <!-- Authentication Links -->

                <?php if(Auth::guest() && Auth::guard('web')->guest()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <!--<li><a href="<?php echo e(url('/register')); ?>">Register</a></li>-->
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="/branding/edit-profile">Edit Profile</a></li>
                    <li class="nav-item dropdown ">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php if(Auth::user() && Auth::user()->Username): ?>
                                <?php echo e(Auth::user()->PPLPerson()->first()->PrimaryEmail); ?>

                            <?php else: ?>
                                <?php echo e(Auth::guard('web')->user()->PPLPerson()->first()->PrimaryEmail); ?>

                            <?php endif; ?>
                                <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <?php if(!is_numeric(Auth::guard('web')->user()->Username)): ?><li><a href="<?php echo e(url('/password/change')); ?>"><i class="fa fa-key" aria-hidden="true"></i> Change
                                    Password</a></li><?php endif; ?>
                            <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<?php echo $__env->yieldContent('content'); ?>

<!-- jQuery plugins-->
<script src="/public/js/plugins/plugins.js"></script>
<script src="/public/js/template-custom.js" type="text/javascript"></script>
<script src="/public/js/scripts.js" type="text/javascript"></script>
</body>
</html>

<?php echo form_open($form, ['class' => 'form-horizontal']); ?>


<?php while($formField = form_next($form)): ?>

    <?php if($formField->isHidden()): ?>
        <?php echo form_element_widget($formField); ?>

    <?php else: ?>
        <div class="form-group">
            <div class="col-sm-1">
                <?php echo form_element_label($formField, ['class' => 'control-label']); ?>

            </div>
            <div class="col-sm-10">
                <?php echo form_element_widget($formField); ?><br>
                <span style="color: red;"><?php echo form_element_errors($formField); ?></span>
            </div>
        </div>
    <?php endif; ?>

<?php endwhile; ?>

<?php if(isset($submitButton) || isset($editButton) || isset($cancelButton) || isset($deleteButton)): ?>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <?php if(isset($submitButton) && $submitButton): ?>
                <input type="submit" class="btn btn-primary">
            <?php endif; ?>

            <?php if(isset($editButton) && $editButton): ?>
                <a class="btn btn-primary" href="<?php echo e($editButton); ?>">Edit</a>
            <?php endif; ?>

            <?php if(isset($cancelButton) && $cancelButton): ?>
                <a class="btn btn-default" href="<?php echo e($cancelButton); ?>">Cancel</a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php echo form_close($form); ?>


<?php if(isset($deleteButton) && $deleteButton): ?>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <?php echo Form::open(['url' => $deleteButton, 'method' => 'DELETE', 'onsubmit' => "return confirm('Do you really want to delete this item?');"]); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php endif; ?>

<?php $__env->startSection('body-content'); ?>
    <?php echo form_open($form); ?>

    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <?php if($userID && !$AllowPublicUsersUsernameEdit): ?>
                    <?php echo form_element_widget($form['Username'], ['disabled' => 'disabled']); ?>

                <?php else: ?>
                    <?php echo form_element($form['Username'] ); ?>

                <?php endif; ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['FirstName']); ?>

            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['LastName']); ?>


            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['PrimaryEmail']); ?>

            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <?php echo form_element($form['PrimaryPhone']); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <input type="button" class="btn btn-default" value="Cancel" onclick="window.location='<?php echo e(route('usermgmt.users.home')); ?>'"/>
            <button type="submit" class="btn btn-default">Save User</button>
        </div>
    </div>
    <?php echo form_close($form); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
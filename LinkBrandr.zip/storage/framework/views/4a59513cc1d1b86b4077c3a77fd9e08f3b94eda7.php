<?php $__env->startSection('content'); ?>
    <section id="subscription-expired" class="section form-section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel">
                        <div class="panel-heading">
                            <h1>Subscription</h1>
                            <h2>Client Dashboard / Subscription Details</h2>
                        </div>
                    </div>
                    <br>
                    <div class="panel panel-default">
                        <div class="panel-heading"></div>

                        <div class="panel-body">
                            <div class="alert alert-danger">
                                <i class="fa fa-warning fa-fw fa-lg"></i>
                                <strong>Attention!</strong> Your account has expired. Please enter payment details below to continue using LinkBrandr.
                            </div>

                            <form action="/Subscription/makePayment" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <script
                                        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                        data-key="pk_test_WsVCwcnP3fAma15mUP0dxf9R"
                                        
                                        data-name="LinkBrandr"
                                        data-description="Monthly Payment"
                                        data-amount="3000"
                                        data-label="Add payment details">
                                </script>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('styles'); ?>
<style>
    html {
        overflow-y: scroll;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1>GModel Generator</h1>
    </div>

    <div class="row">
        <div class="col-md-8">
            <?php echo form_open($form); ?>


            <h2>Options</h2>

            <hr/>

            <div class="form-group">
                <?php echo form_element($form['PartialMatch']); ?>

                <p>If checked, the generator will match any table that starts with the provided table name</em>.</p>
            </div>
            <div class="form-group">
                <?php echo form_element($form['TableName']); ?>

            </div>

            <hr/>

            <p>These options are used less frequently. <em style="color: red">Be wary of their effects.</em></p>
            <div>
                <div class="form-group">
                    <?php echo form_element($form['Lib2']); ?>

                    <p>If checked, the context of the generator will switch from the <em>app</em> to
                        <em>lib2.</em> Only defined lib tables are available for generation.</p>
                </div>

                <div class="form-group">
                    <?php echo form_element($form['All']); ?>

                    <p>Generate <em>All</em> of the tables in the database</p>
                </div>

            </div>

            <hr/>

            <div class="row">
                <div class="form-group col-md-3">
                    <input id="generate" type="submit" value="Generate" class="form-control btn btn-default">
                </div>
            </div>

            <?php echo form_close($form); ?>


            <h2>Output</h2>

            <hr/>

            <div id="console-output-container">
                <p>Nothing yet.</p>
            </div>

            <hr/>

        </div>

        <div class="col-md-4">
            <h2>Tables to be GModels</h2>
            <p>The following tables will be generated into GModels</p>

            <hr/>

            <ul id="table-list"></ul>
        </div>
    </div>

    <script>

        $(document).ready(function() {
            $('#all').change(function() {
                if (this.checked) {
                    $("#table-name").attr("disabled", true);
                    $("#partial-match").attr("disabled", true);
                } else {
                    $("#table-name").removeAttr("disabled");
                    $("#partial-match").removeAttr("disabled");
                }
            });

            $('#partial-match').change(function() {
                if (this.checked) {
                    $("#table-name").autocomplete("option", "disabled", true);
                } else {
                    $("#table-name").autocomplete("option", "disabled", false);
                }
            });

            $('#lib2').change(function() {
                if (this.checked) {
                    $("#table-name").autocomplete("option", "disabled", true);
                } else {
                    $("#table-name").autocomplete("option", "disabled", false);
                }
            });

            $('form input').change(populateTableList);
            $('#table-name').on('input', populateTableList);
            $('#table-name').on('autocompleteclose', populateTableList);

            $('form').submit(function() {
                if (!confirm('Ok to start generating?')) {
                    return false;
                }

                generate();

                return false;
            });

            populateTableList();
        });

        function generate () {
            var outputContainer        = $('#console-output-container');
            var generateButton         = $('#generate');
            var oldGenerateButtonValue = generateButton.val();

            generateButton.attr("disabled", true);
            generateButton.val('Generating...');

            $.ajax({
                url : '<?php echo e(route('devtools.gen.gmodel.generate')); ?>',
                data: getFormData()
            }).done(function(data) {
                outputContainer.empty();
                outputContainer.html(data);

                generateButton.removeAttr("disabled");
                generateButton.val(oldGenerateButtonValue);
            });
        }

        function getFormData () {
            return {
                'Lib2'        : $('#lib2').is(":checked"),
                'All'         : $('#all').is(":checked"),
                'PartialMatch': $('#partial-match').is(":checked"),
                'TableName'   : $('#table-name-label').val(),
            };
        }
        function populateTableList () {
            $.ajax({
                url : '<?php echo e(route('devtools.gen.gmodel.tables')); ?>',
                data: getFormData()
            }).done(function(data) {
                var tableNames = JSON.parse(data);

                if (!tableNames) {
                    return;
                }

                $("#table-list").empty();

                for (var i = 0; i < tableNames.length; i++) {
                    $("#table-list").append('<li>' + tableNames[i] + '</li>');
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
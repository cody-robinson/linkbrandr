	<?php echo e($Relationship->phpDocBlock()); ?>

	public function <?php echo e($Relationship->methodName()); ?>()
	{
		return $this->hasMany('<?php echo e($Relationship->explicitClassName()); ?>', '<?php echo e($Relationship->foreignKey); ?>', '<?php echo e($Relationship->localKey); ?>');
	}
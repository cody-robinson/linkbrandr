
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>LinkBrandr: Grow your brand each time you share a link</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/public/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="https://file.myfontastic.com/BQ5rqoUxsfQGHC35jWa5Ub/icons.css">
    <!-- Google fonts - Open Sans-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800">
    <!-- owl carousel-->
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="/public/vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="/public/css/style.blue.css" id="theme-stylesheet">
    <!-- Custom stylesheet - from theme-->
    <link rel="stylesheet" href="/public/css/custom-from-theme.css">
    <!--LB Custom Styles -->
    <link href="/public/css/custom.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="shortcut icon" href="/public/images/favicon.ico" />
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

    <!-- Live chat -->
    <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="b74ccecc-15e2-41fe-b28c-6bd58c575f79";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</head>
<body id="app-layout">
<!-- navbar-->
<header class="header">
    <nav class="navbar navbar-expand-lg fixed-top">
        <a href="/" class="navbar-brand">
            <img src="/public/images/link-brandr-logo.png" class="logo"/>
        </a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><span></span><span></span><span></span></button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto align-items-start align-items-lg-center">
                <!-- Authentication Links -->
                <?php if(Auth::guest() && Auth::guard('web')->guest()): ?>
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="/share-link/listing">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/branding/edit-profile">Edit Profile</a></li>
                    <li class="nav-item dropdown ">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php if(Auth::user() && Auth::user()->Username): ?>
                                <?php echo e(Auth::user()->PPLPerson()->first()->PrimaryEmail); ?>

                            <?php elseif(Auth::guard('web')->user()->PPLPerson()->first()->PrimaryEmail): ?>
                                <?php echo e(Auth::guard('web')->user()->PPLPerson()->first()->PrimaryEmail); ?>

                            <?php else: ?>
                                <!-- fallback if a FB user denied permissions and we don't have their email -->
                                Options
                            <?php endif; ?>
                            <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <?php if(!is_numeric(Auth::guard('web')->user()->Username)): ?><li class="dropdown-item"><a href="<?php echo e(url('/password/change')); ?>"><i class="fa fa-key" aria-hidden="true"></i> Change
                                    Password</a></li><?php endif; ?>
                            <li class="dropdown-item"><a href="/subscription/"><i class="fa fa-btn fa-credit-card"></i> Subscription</a></li>
                            <li class="dropdown-item"><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i> Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>

<?php echo $__env->yieldContent('content'); ?>

<!-- Javascript files-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"> </script>
<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/public/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/public/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="/public/js/front.js"></script>

<script src="/public/js/scripts.js" type="text/javascript"></script>
<!-- Google Analytics: -->
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-102275980-1', 'auto');
    ga('send', 'pageview');
</script>

<!-- Drip -->
<script type="text/javascript">
    var _dcq = _dcq || [];
    var _dcs = _dcs || {};
    _dcs.account = '3425290';
    (function() {
        var dc = document.createElement('script');
        dc.type = 'text/javascript'; dc.async = true;
        dc.src = '//tag.getdrip.com/3425290.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(dc, s);
    })();
</script>
<!-- End Drip -->

</body>
</html>


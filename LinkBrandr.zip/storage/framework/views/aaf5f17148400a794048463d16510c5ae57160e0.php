<?php $__env->startSection('header-body'); ?>
    <form method="GET" action="/lib2/usermanagement/users/userDetails">
        <input type="submit" class="btn btn-default" value="Add Public User">
    </form>
    <!--<input type="submit" class="btn btn-default" value="Export List">-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title', 'User Listing'); ?>

<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
        <table id='user-listing' class="table table-striped data-table">
            <thead>
                <tr>
                    <th></th>
                    <th>Username</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>User Types</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $UsersInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$UserInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($Key+1); ?></td>
                    <td><a href="userDetails/<?php echo e($UserInfo->ID); ?>"><?php echo e($UserInfo->Username); ?></a></td>
                    <td><?php echo e($UserInfo->FirstName); ?></td>
                    <td><?php echo e($UserInfo->LastName); ?></td>
                    <td><?php echo e($UserInfo->PrimaryEmail); ?></td>
                    <td><?php echo e($UserInfo->PrimaryPhone); ?></td>
                    <td>
                        <?php if(is_array($UserInfo->UserTypes)): ?>
                            <?php $__currentLoopData = $UserInfo->UserTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($value); ?><?php if(!$loop->last): ?>,<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="/lib2/usermanagement/users/resetUserPassword/<?php echo e($UserInfo->ID); ?>" class="table-link">
                            <span class="fa-stack">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-key fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>
                        <a href="/lib2/usermanagement/users/deleteUser/<?php echo e($UserInfo->ID); ?>" onclick="return confirm('Are you sure you want to delete this user?');" class="table-link danger">
                            <span class="fa-stack">
                            <i class="fa fa-square fa-stack-2x"></i>
                            <i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
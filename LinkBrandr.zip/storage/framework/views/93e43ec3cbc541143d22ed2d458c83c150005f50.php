<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />


    <title><?php echo e($header->getTitle()); ?></title>

    <!-- google fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato:100,300,400,700|Open+Sans:400,600,700,300">

    <!-- css libraries -->
    <link rel="stylesheet" href="/common/lib2/styles/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="/common/lib2/styles/datepicker.css"/>

    <!-- theme styles -->
    <link rel="stylesheet" type="text/css" href="/common/lib2/styles/compiled/theme_styles.css"/>
    <link rel="stylesheet" type="text/css" href="/common/lib2/styles/compiled/custom_styles.css"/>

    <!-- data tables - custom link includes relevant extensions -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs/dt-1.10.16/af-2.2.2/b-1.5.1/fh-3.1.3/r-2.2.1/datatables.min.css"/>

    <?php if(isset($Lib2OverridingStyles) && $Lib2OverridingStyles): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e($Lib2OverridingStyles); ?>"/>
    <?php endif; ?>

    <?php if(isset($Favicon) && $Favicon): ?>
        <link rel="shortcut icon" href="<?php echo e($Favicon); ?>"/>
    <?php endif; ?>

    <!-- Stylesheets included once, included automatically as needed by Lib2 -->
    <?php $__currentLoopData = $includedStylesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedStylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $includedStylesheet; ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Project Specific Includes-->
    <?php $__currentLoopData = $includedProjectStylesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedProjectStylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $includedProjectStylesheet; ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- javascript libraries -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="/common/lib2/scripts/jquery-ui.custom.min.js"></script>
    <script src="/common/lib2/scripts/jquery.nanoscroller.min.js"></script>

    <!-- bootstrap scripts -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="/common/lib2/scripts/bootstrap-datepicker.js"></script>

    <!-- app scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- Scripts included once, included automatically as needed by Lib2 -->
    <?php $__currentLoopData = $includedScripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedScript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo $includedScript; ?>"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</head>
<body class="<?php if(isset($themeCssClass)): ?><?php echo e($themeCssClass); ?><?php else: ?> theme-whbl <?php endif; ?> pace-done">
<div id="theme-wrapper">

    <header class="navbar" id="header-navbar">
        <div class="container">
            <div class="clearfix">

                <div class="navbar-left">
                    <a href="/">
                        <h3 class="header-title">
                            <?php echo e($navbar->getTitle()); ?>

                        </h3>
                    </a>
                </div>

                <button class="navbar-toggle" data-target=".navbar-ex1-collapse" data-toggle="collapse" type="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="fa fa-bars" aria-hidden="true"></span>
                </button>

                <div class="nav-no-collapse pull-right" id="header-nav">
                    <ul class="nav navbar-nav pull-right">

                        <?php $__currentLoopData = $navbar->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('gravUI::navbar.navbar-item', ['item' => $item], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </header>

    <div id="page-wrapper" class="container">
        <div class="row">
            <div id="nav-col">
                <section id="col-left" class="col-left-nano">
                    <div id="col-left-inner" class="col-left-nano-content">
                        <div id="user-left-box" class="clearfix hidden-sm hidden-xs">
                            <img src="<?php echo e($clientLogo); ?>" />
                        </div>
                        <div class="collapse navbar-collapse navbar-ex1-collapse" id="sidebar-nav">
                            <ul class="nav nav-pills nav-stacked">
                                <?php $__currentLoopData = $sidebar->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('gravUI::sidebar.sidebar-item', ['item' => $item], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </section>
                <div id="nav-col-submenu"></div>
            </div>

            <div id="content-wrapper" class="full-screen-remove-sidebar">
                <div class="row">
                    <div class="col-lg-12">

                        <div class="row">
                            <div class="col-lg-12">
                                <div id="content-header" class="clearfix">
                                    <div class="row">
                                        <div class="col-lg-8 col-md-8 col-sm-10 col-xs-10">

                                            <h1><?php echo e($header->getTitle()); ?></h1>

                                            <?php if($recordTitle): ?>
                                                <h2><?php echo e($recordTitle); ?></h2>
                                            <?php endif; ?>

                                            <ol class="breadcrumb">
                                                <?php $__currentLoopData = $breadcrumbs->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo $__env->make('gravUI::breadcrumbs.breadcrumb', ['breadcrumb' => $breadcrumb], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ol>
                                        </div>
                                        <div class="col-xs-2 col-sm-2 col-md-4 col-lg-4">
                                            <div class="icon-box pull-right" style="display: none">
                                                <a onclick="DisableFullScreen()" class="btn pull-left">
                                                    <i class="fa fa-expand"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if(View::hasSection('notification')): ?>
                            <?php echo $__env->yieldContent('notification'); ?>
                        <?php endif; ?>

                        <?php if(View::hasSection('header-title') || View::hasSection('header-body')): ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="main-box header-container">
                                        <div class="main-box-header clearfix">
                                            <h2><?php echo $__env->yieldContent('header-title'); ?></h2>
                                        </div>
                                        <div class="main-box-body clearfix">
                                            <?php echo $__env->yieldContent('header-body'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(View::hasSection('body-title') || View::hasSection('body-content')): ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="main-box body-container">
                                        <div class="main-box-header clearfix">
                                            <h2><?php echo $__env->yieldContent('body-title'); ?></h2>
                                        </div>
                                        <div class="main-box-body clearfix">
                                            <?php echo $__env->yieldContent('body-content'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo $__env->yieldContent('body-content-custom'); ?>

                    </div>
                </div>

                <footer id="footer-bar" class="row">
                    <p id="footer-copyright" class="col-xs-12"></p>
                </footer>

            </div> <!-- end of content wrapper -->
        </div>
    </div> <!-- end of page wrapper -->
</div> <!-- end of theme wrapper -->

<!-- theme scripts -->
<script src="/common/lib2/scripts/scripts.js"></script>
<!-- data tables - custom script includes relevant extensions -->
<script type="text/javascript" src="https://cdn.datatables.net/v/bs/dt-1.10.16/af-2.2.2/b-1.5.1/fh-3.1.3/r-2.2.1/datatables.min.js"></script>

<!-- Project specific scripts included using AdminUI Service -->
<?php $__currentLoopData = $includedProjectScripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedProjectScript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo $includedProjectScript; ?>"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function setListingContHeight() {
        var elementHeights = $('.listing_cont').map(function() {
            return $(this).height();
        }).get();

        var maxHeight = Math.max.apply(null, elementHeights);

        $('.listing_cont').height(maxHeight);
    }

    setListingContHeight();

    $(window).resize(function(){
        setListingContHeight();
    });

    $(document).ready(function() {
        // check for data tables
        var DataTable = $('.data-table');
        // instantiate all data tables
        if(DataTable.length > 0){
            $(DataTable).DataTable( {
                "iDisplayLength": 50,
                "bLengthChange": true,
                "searching": true,
                "aaSorting": []
            } );
        }
    } );
</script>

</body>
</html>


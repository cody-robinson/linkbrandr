<?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
//<?php echo $note; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
$field = new <?php echo e($fieldType); ?>('<?php echo e($fieldIdentifier); ?>'<?php if($fieldLegibleIdentifier): ?>, '<?php echo e($fieldLegibleIdentifier); ?>'<?php endif; ?>);
<?php if($table): ?>$field->getDbMapping()->setTableName('<?php echo e($table); ?>');
<?php endif; ?>
<?php if($column): ?>$field->getDbMapping()->setColumnName('<?php echo e($column); ?>');
<?php endif; ?>
<?php if($isCollection): ?>$field->getDbMapping()->autoLookup(<?php echo $lookupTableName ? "'$lookupTableName', " : (($lookupTableKeyColumn || $lookupTableValueColumn) ? 'null, ' : ''); ?><?php echo $lookupTableKeyColumn ?  "'$lookupTableKeyColumn', " : ($lookupTableValueColumn ? 'null, ' : ''); ?><?php echo $lookupTableValueColumn ? "'$lookupTableValueColumn'" : ''; ?>);
<?php endif; ?>
<?php if($elementType): ?>$field->element(<?php echo e($elementType); ?>::class);
<?php endif; ?>
$this->add($field<?php echo e($mundane ? ', true' : ''); ?>);

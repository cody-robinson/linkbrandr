<?php $__env->startSection('content'); ?>

<input type="hidden" value="<?php echo $user->LBRBackgroundImages_ID; ?>" id="backgroundImage" />
<?php if(isset($redirectToBrandr)): ?><input type="hidden" value="<?php echo $redirectToBrandr; ?>" id="redirectToBrandr" /><?php endif; ?>

<div class="splash-page">
    <div class="row">
        <div class="col-lg-4 col-lg-push-8 col-md-5 col-md-push-7 col-sm-12">
            <div class="countdown">
                <span>Article Loading in</span>
                <span class="larger">3</span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
            <div class="splash-client-details">
                <?php if(!empty($user->ProfileImage)): ?>
                    <div class="image-cropper <?php if($user->ImageType == 'Headshot'): ?>with-crop <?php elseif($user->ImageType == 'Logo'): ?>no-crop <?php endif; ?> <?php if($user->ImageOrientation == 'landscape'): ?>landscape <?php elseif($user->ImageOrientation == 'portrait'): ?>portrait <?php endif; ?>"><img src="<?php echo url('/public/uploads/profile-images/'.$user->ID.".".pathinfo($user->ProfileImage, PATHINFO_EXTENSION)); ?>?avoidCache=<?php echo $user->LastModified; ?>"></div>
                <?php endif; ?>
                <div class="name"><?php echo $user->BusinessName; ?></div>
                <div class="title"><?php echo $user->BusinessDescription; ?></div>
            </div>
        </div>
        <div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
            <div class="splash-tagline">
                <p><?php echo $user->Headline; ?></p>
            </div>

            <?php if(!empty($user->ButtonText) && !empty($user->ProfileURL)): ?>
                <div class="splash-button">
                    <a href="<?php echo $user->ProfileURL; ?>" target="_blank" style="background-color: <?php echo $ButtonColor; ?>"><?php echo $user->ButtonText; ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>

	$(document).ready(function(){
        //find out if we're in preview by checking iFrame parent url
        var pathname = (window.location != window.parent.location)
                ? document.referrer
                : document.location.href;

        var previewPath = "/share-link/listing";
        var previewPathPascal = "/ShareLink/listing";
        var previewPathCapitalize = "/Sharelink/listing";
        var previewPathLowerCase = "/sharelink/listing";
        var splashPreview = "/link/splash-preview";

        var match = pathname.indexOf(previewPath);
        var matchPascal = pathname.indexOf(previewPathPascal);
        var matchCapitalize = pathname.indexOf(previewPathCapitalize);
        var matchLowerCase = pathname.indexOf(previewPathLowerCase);
        var matchSplashPreview = pathname.indexOf(splashPreview);

        // start at 4 to get the full 3,2,1 countdown
		var counter = 4;
		var interval = setInterval(function() {
			counter--;
			$("div.countdown span.larger").text(counter);

			if (counter == 0) {

				clearInterval(interval);
                var shareTypeBoth = $('#redirectToBrandr').val();

                //not a match, therefore not in preview
                if(match == -1 && matchPascal == -1 && matchCapitalize == -1 && matchLowerCase == -1 && matchSplashPreview == -1){

                    //if redirecting to brandr
                    if(shareTypeBoth == 'true'){
                        window.location.replace("/link/<?php echo $slug; ?>?showBrandr=true");
                    } else {
                        // Redirect to share link
                        window.location.replace("<?php echo $sharedLink; ?>");
                    }
                //in preview with sharetype both
                } else if (shareTypeBoth == 'true'){
                    var url = window.location.href;
                    url += "?showBrandr=true";
                    window.location.href = url;
                }

			}
		}, 1000);

        var backgroundImage = $("#backgroundImage").val();

        if(backgroundImage != ""){
            $.backstretch("/public/images/splash_backgrounds/background-" + backgroundImage + ".jpg");
        } else {
            $.backstretch("/public/images/background.jpg");
        }
	});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.publicViewapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo e(UI::includeScript('https://code.jquery.com/ui/1.12.1/jquery-ui.js')); ?>

<?php echo e(UI::includeStylesheet('https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css')); ?>

<?php echo e(UI::includeScript(common_path('scripts/form/field-element.js'))); ?>



<?php $__env->startSection('body-content-custom'); ?>

    <div class="main-box clearfix">
        <div class="main-box-header">
            <h2><?php echo $PageHeading; ?></h2>
            <?php if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail): ?>
                <p>This user signed up with Facebook.</p>
            <?php elseif(is_numeric($UserInfo->Username) && !$UserInfo->Person->PrimaryEmail): ?>
                <p>This user signed up with Facebook and withheld access to some of their information, including their email.</p>
            <?php endif; ?>
        </div>
        <div class="main-box-body">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <?php if($UserInfo->UserProfile): ?>
                    <th>Location</th>
                    <th>Birthday</th>
                    <th>Gender</th>
                    <?php endif; ?>
                    <th>Username</th>
                    <th>Business Name</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($UserInfo->Person->FirstName); ?></td>
                        <td><?php echo e($UserInfo->Person->LastName); ?></td>
                        <?php if($UserInfo->UserProfile): ?>
                        <td><?php echo e($UserInfo->UserProfile->Location); ?></td>
                        <td><?php echo e($UserInfo->UserProfile->Birthday); ?></td>
                        <td><?php echo e($UserInfo->UserProfile->Gender); ?></td>
                        <?php endif; ?>
                        <td><?php if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail): ?> <?php echo e($UserInfo->Person->PrimaryEmail); ?> <?php else: ?><?php echo e($UserInfo->Username); ?><?php endif; ?></td>
                        <td><?php if($UserInfo->UserProfile): ?><?php echo e($UserInfo->UserProfile->BusinessName); ?> <?php else: ?> No Profile Created <?php endif; ?></td>
                    </tr>
                </tbody>
            </table>

        <div class="main-box-header">
            <h2>Subscription Info</h2>
        </div>

            <p><strong>Subscription Status: </strong>
                <?php if($UserInfo->UserProfile): ?>
                    <?php if($UserInfo->UserProfile->IsPaidSubscription==1): ?> <strong class="text-success">Paid</strong>
                    <?php else: ?> <strong class="text-danger">Trial</strong>
                    <?php endif; ?>
                    and
                    <?php if(strtotime($UserInfo->UserProfile->AccountExpiryDate) < time() ): ?> <strong class="text-danger">Expired</strong>
                    <?php else: ?> <strong class="text-success">Active</strong>
                    <?php endif; ?>
                <?php else: ?>
                    No Profile Created
                <?php endif; ?>
            </p>
            <p><strong>Subscription Expiry Date: </strong>
                <?php if($UserInfo->UserProfile): ?> <?php echo e(date("M d, Y",strtotime($UserInfo->UserProfile->AccountExpiryDate))); ?>

                <?php else: ?>
                    No Profile Created
                <?php endif; ?>
            </p>

            <?php if($UserInfo->UserProfile): ?> <p class="form-inline"><strong>Reset Expiry Date to: </strong><input type="text" id="subscriptionDatePicker" class="form-control" style="width:200px; display:inline-block"> <input type="button" class="btn btn-default" value="Update" id="expiryUpdateButton" /></p> <?php endif; ?>

        <div class="main-box-header">
            <h2>Links This User Shared</h2>
        </div>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th>URL</th>
                    <th>Share Type</th>
                    <th>Slug</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $UserInfo->SharedLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Links): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Links->Link); ?></td>
                        <td><?php echo e($Links->ShareType); ?></td>
                        <td><?php echo e($Links->Slug); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if($UserInfo->UserProfile): ?>
    <script>


	$('#subscriptionDatePicker').datepicker({
		dateFormat: 'yy-mm-dd'
	});
	$('#subscriptionDatePicker').datepicker('setDate',new Date('<?php echo e($UserInfo->UserProfile->AccountExpiryDate); ?>'));

	$('#expiryUpdateButton').on('click',function(){
        var newDate = $('#subscriptionDatePicker').val();
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:"/users/expiry-update/<?php echo e($UserInfo->UserProfile->ID); ?>",
            data:{date:newDate,  _token: CSRF_TOKEN},
			type: 'POST',
            dataType:"JSON",
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN,
			},
			cache:false,
			success: function(response) {
                if(response.result != false){
                	window.location.reload();
                }
                else{
                	console.log(response);
                }
			}
        });
    });
    </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('body-content'); ?>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th><span>Username</span></th>
                    <th><span>Last Logged In</span></th>
                    <th class="text-center"><span>Logins (30 Days)</span></th>
                    <th class="text-center"><span>Failures (30 Days)</span></th>
                    <th class="text-center"><span>Logins (180 Days)</span></th>
                    <th class="text-center"><span>Failures (180 Days)</span></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Ali</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">5</td>
                    <td class="text-center">0</td>
                </tr>
                <tr>
                    <td>Derek</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">10</td>
                    <td class="text-center">0</td>
                </tr>
                <tr>
                    <td>Glen</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                </tr>
                <tr>
                    <td>Jessica</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">4</td>
                </tr>
                <tr>
                    <td>Jordan</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                </tr>
                <tr>
                    <td>Kat</td>
                    <td>2016-07-25 13:28:14</td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">3</td>
                    <td class="text-center">0</td>
                </tr>
                </tbody>
                <tfoot>
                <tr>
                    <td></td>
                    <td></td>
                    <td class="text-center">0</td>
                    <td class="text-center">0</td>
                    <td class="text-center">18</td>
                    <td class="text-center">4</td>
                </tr>
                </tfoot>
            </table>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
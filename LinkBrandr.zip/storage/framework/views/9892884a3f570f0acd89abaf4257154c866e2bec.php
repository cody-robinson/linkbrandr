<?php if($renderWidget): ?>
    <?php echo Form::hidden($field->getName(), $field->getValue(), $widgetAttributes); ?>

<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <section id="payment-success-section" class="section form-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel text-center">
                        <div class="panel-heading">
                            <h1 class="text-center">Payment Successful!</h1>
                        </div>

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12 panel">
                                    <div class="panel-body">
                                        <p>You are now subscribed to LinkBrandr.</p>

                                        <br>
                                        <a href="/share-link/listing" class="btn btn-primary">Go to Dashboard</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="drip-registration-details">
            <input type="hidden" id="email" name="email" value="<?php echo $email; ?>">
            <input type="hidden" id="subType" name="subType" value="<?php echo $subType; ?>">
            <input type="hidden" id="stripeID" name="stripeID" value="<?php echo $stripeID; ?>">
        </div>
    </section>

    <!-- Send info to Drip after registration was successful
    (we know that because they were redirect here.) -->
    <script>

        $(document).ready(function(){
            var email = $('.drip-registration-details #email').val();
            var subType = $('.drip-registration-details #subType').val();
            var stripeID = $('.drip-registration-details #stripeID').val();
            var tags = [];

            if(subType == "Annual"){
                subType = "Annual Subscription"
            } else if(subType == "Monthly"){
                subType = "Monthly Subscription";
            }

            tags.push(subType);

            _dcq.push(["identify", {
                email: email,
                stripe_customer_id: stripeID,
                tags: tags
            }]);
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
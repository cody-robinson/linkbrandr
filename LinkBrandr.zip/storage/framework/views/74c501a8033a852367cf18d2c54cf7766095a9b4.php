<?php echo e(UI::includeScript(common_path('scripts/form/field-element.js'))); ?>

<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>
<?php if($renderWidget): ?>
    <div id="<?php echo e($field->getId()); ?>" class="location" style="border: 1px solid lightgray; padding: 10px;">
        <fieldset class="row">

            <div class="row col-sm-12">
                <!-- country select -->
                <div class="control-group col-sm-6">
                    <label class="control-label">Country</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getCountryElement(), ['class' => 'input-xlarge form-control', 'autocomplete' => 'country']); ?>

                        <?php echo form_element_errors($field->getCountryElement()); ?>

                        <p class="help-block"></p>
                    </div>
                </div>

                <!-- region select-->
                <div class="control-group col-sm-6">
                    <label class="control-label">State / Province</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getRegionElement(), ['class' => 'input-xlarge form-control', 'autocomplete' => 'address-level1']); ?>

                        <?php echo form_element_errors($field->getRegionElement()); ?>

                        <p class="help-block"></p>
                    </div>
                </div>
            </div>

            <div class="row col-sm-12">
                <!-- city input-->
                <div class="control-group col-sm-6">
                    <label class="control-label">City / Town</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getLocalityElement(), ['class' => 'input-xlarge form-control', 'placeholder' => 'City', 'autocomplete' => 'address-level2']); ?>

                        <?php echo form_element_errors($field->getLocalityElement()); ?>

                        <p class="help-block"></p>
                    </div>
                </div>

                <!-- postal-code input-->
                <div class="control-group col-sm-6">
                    <label class="control-label">Zip / Postal Code</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getPostalCodeElement(), ['class' => 'input-xlarge form-control', 'placeholder' => 'Zip or Postal Code', 'autocomplete' => 'postal-code']); ?>

                        <?php echo form_element_errors($field->getPostalCodeElement()); ?>

                        <p class="help-block"></p>
                    </div>
                </div>
            </div>

            <div class="row col-sm-12">
                <!-- address-line1 input-->
                <div class="control-group col-sm-6">
                    <label class="control-label">Address Line 1</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getAddressLineOneElement(), ['class' => 'input-xlarge form-control', 'placeholder' => 'Address Line 1', 'autocomplete' => 'address-line1']); ?>

                        <?php echo form_element_errors($field->getAddressLineOneElement()); ?>

                        <p class="help-block">Street Address, Company Name, c/o, etc.</p>
                    </div>
                </div>

                <!-- address-line2 input-->
                <div class="control-group col-sm-6">
                    <label class="control-label">Address Line 2</label>
                    <div class="controls">
                        <?php echo form_element_widget($field->getAddressLineTwoElement(), ['class' => 'input-xlarge form-control', 'placeholder' => 'Address Line 2', 'autocomplete' => 'address-line2']); ?>

                        <?php echo form_element_errors($field->getAddressLineTwoElement()); ?>

                        <p class="help-block">Apartment, Suite, Unit, Building, Floor, etc.</p>
                    </div>
                </div>
            </div>

        </fieldset>

        <script>
            $(document).ready(function() {
                var countryElem = $('#<?php echo e($field->getCountryElement()->getId()); ?>');
                var regionElem  = $('#<?php echo e($field->getRegionElement()->getId()); ?>');

                countryElem.change(function() {
                    FieldElement.Location.filterRegions(regionElem, countryElem.val());
                });

                FieldElement.Location.filterRegions(regionElem, countryElem.val());
            });

        </script>
    </div>


<?php endif; ?>

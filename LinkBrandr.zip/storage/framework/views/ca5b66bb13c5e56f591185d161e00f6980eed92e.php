<?php $__env->startSection('header-body'); ?>
    <?php echo form_open($form); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo form_element($form['Username']); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                   <?php echo form_element($form['Path']); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo form_element($form['SearchPath']); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo form_element($form['StartDate'],['widget'=>['class'=>'form-control bootstrap-datepicker']]); ?>

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <?php echo form_element($form['EndDate'],['widget'=>['class'=>'form-control bootstrap-datepicker']]); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo form_element($form['SearchRequest']); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                        <?php echo form_element($form['HideRequestData']); ?>


                        <?php echo form_element($form['HideSessionID']); ?>


                        <?php echo form_element($form['HideCommonCookies']); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <input type="button" class="btn btn-default" value="Reset" onclick="window.location='<?php echo e(route('usermgmt.admin.adminAuditLog')); ?>'"/>
                <button type="submit" class="btn btn-default">Search</button>
            </div>
        </div>
    <?php echo form_close($form); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
        <div id="table-example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
            <div class="dataTables_length" id="table-example_length">
                <label>Show <select name="table-example_length" aria-controls="table-example" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label>
            </div>

            <div class="clearfix"></div>
            <table id="table-example" class="table table-hover table-striped dataTable no-footer" role="grid">
                <thead>
                <tr role="row">
                    <th></th>
                    <th width="200">Timestamp</th>
                    <th>User</th>
                    <th>Path</th>
                    <?php if(!$HideRequestData): ?>
                    <th>Data</th>
                    <?php endif; ?>
                </thead>
                <tbody>
                <?php $__currentLoopData = $AdminUsersAuditLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$AuditLogInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row">
                        <td><?php echo e($Key+1); ?></td>
                        <td class="sorting_1"><?php echo e($AuditLogInfo->Timestamp); ?></td>
                        <td><?php echo e($AuditLogInfo->User); ?></td>
                        <td><?php echo e($AuditLogInfo->Path); ?></td>
                        <?php if(!$HideRequestData): ?>
                        <td><?php echo e($AuditLogInfo->Data); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('body-content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div id="login-box">
                <div id="login-box-holder">
                    <div class="row">
                        <div class="col-xs-12">
                            <header id="login-header">
                                <div id="login-logo">
                                    <img src="<?php if($clientLogo): ?> <?php echo e($clientLogo); ?> <?php else: ?> /common/lib2/images/gravitelogo.png <?php endif; ?>" />
                                </div>
                            </header>
                            <div id="login-box-inner">
                                <div id="message">
                                    <p>Enter your username and password to access the administration console.</p>
                                    <p>All attempts at unauthorized access are logged.</p>
                                </div>
                                <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                        <label for="email" class="control-label">Username</label>

                                        <div class="input-group">
                                            <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                        <label for="password" class="control-label">Password</label>

                                        <div class="input-group">
                                            <input id="password" type="password" class="form-control" name="password">

                                            <?php if($errors->has('password')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div id="remember-me-wrapper">
                                        <div class="row">
                                            <div class="col-xs-6">
                                                <div class="checkbox-nice">
                                                    <input type="checkbox" id="remember-me">
                                                    <label for="remember-me">
                                                        Remember me
                                                    </label>
                                                </div>
                                            </div>
                                           <!--  <a href="<?php echo e(url('/password/reset')); ?>" id="login-forget-link" class="col-xs-6">
                                                Forgot password?
                                            </a> -->
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-12">
                                            <button type="submit" class="btn btn-primary col-xs-12">Login</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
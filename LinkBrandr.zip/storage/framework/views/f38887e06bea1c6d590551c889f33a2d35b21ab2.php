<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>

<?php if($renderWidget): ?>
    <select name="<?php echo e($field->getName()); ?>[]" <?php echo $field->toAttrString($widgetAttributes); ?>>
        <?php $__currentLoopData = $field->getCombinedCollection(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($tuple['value'])): ?>
                <optgroup label="<?php echo e($tuple['key']); ?>">
                    <?php $__currentLoopData = $tuple['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(in_array($tuple['key'], $field->getValue())): ?> selected="selected" <?php endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
            <?php else: ?>
                <option value="<?php echo e($tuple['key']); ?>" <?php if( (is_array($tuple['key']) && in_array($tuple['key'], $field->getValue())) 
                                    || $tuple['key'] == $field->getValue() 
                                    || (is_array($field->getValue()) && in_array($tuple['key'], $field->getValue()) ) ): ?> selected="selected" <?php endif; ?>><?php echo e($tuple['value']); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php endif; ?>

<?php if($renderErrors): ?>
    <?php if($errors->first($field->getName())): ?>
        <div id="<?php echo e($field->getId()); ?>-error" class="field-error">
            <?php echo e($errors->first($field->getName())); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

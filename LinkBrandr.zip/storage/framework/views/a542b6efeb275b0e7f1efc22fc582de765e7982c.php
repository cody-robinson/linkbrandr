<?php echo e(UI::includeScript(common_path('scripts/form/field-element.js'))); ?>

<?php echo e(UI::includeScript(common_path('scripts/jquery-ui-timepicker-addon.js'))); ?>

<?php echo e(UI::includeStyleSheet(common_path('styles/jquery-ui-timepicker-addon.css'))); ?>


<?php if($renderLabel): ?>
    <?php echo Form::label($field->getName(), $field->getLegibleName(), $labelAttributes); ?>

<?php endif; ?>

<?php if($renderWidget): ?>

    <?php echo Form::text($field->getName(), $field->getTemplateValue(), $widgetAttributes); ?>


    <script>
        $(document).ready(function() {
            FieldElement.dateTimePicker(
                document.getElementById('<?php echo e($field->getId()); ?>'),
                {
                    format: '<?php echo e($field->getFormat()); ?>',
                }
            );
        });
    </script>

<?php endif; ?>

<?php if($renderErrors): ?>
    <?php if($errors->first($field->getName())): ?>
        <div id="<?php echo e($field->getId()); ?>-error" class="field-error">
            <?php echo e($errors->first($field->getName())); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>

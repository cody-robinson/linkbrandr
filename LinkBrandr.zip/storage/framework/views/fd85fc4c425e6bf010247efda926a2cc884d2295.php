<?php $__env->startSection('body-content'); ?>
    <div class="table-responsive">
        <div id="table-example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
            <div class="dataTables_length" id="table-example_length">
                <label>Show <select name="table-example_length" aria-controls="table-example" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label>
            </div>

            <div id="table-example_filter" class="dataTables_filter">
                <label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="table-example"></label>
            </div>
            <div class="clearfix"></div>
            <table id="table-example" class="table table-striped dataTable no-footer" role="grid">
                <thead>
                    <tr role="row">
                        <th width="40"></th>
                        <th tabindex="0" aria-controls="table-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="" style="">Timestamp</th>
                        <th tabindex="0" aria-controls="table-example" rowspan="1" colspan="1" aria-label="" style="">Message</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $AdminUsersAuthLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Key=>$AuthLogInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row">
                        <td><?php echo e($Key+1); ?></td>
                        <td class="sorting_1"><?php echo e($AuthLogInfo->DateAdded); ?></td>
                        <td><?php echo e($AuthLogInfo->Message); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <ul class="pagination pull-right">
                <li class="paginate_button previous disabled" aria-controls="table-example" tabindex="0">
                    <a href="#"><i class="fa fa-chevron-left"></i></a>
                </li>
                <li class="paginate_button active" aria-controls="" tabindex="0"><a href="#">1</a></li>
                <li class="paginate_button next" aria-controls="" tabindex="0">
                    <a href="#"><i class="fa fa-chevron-right"></i></a>
                </li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
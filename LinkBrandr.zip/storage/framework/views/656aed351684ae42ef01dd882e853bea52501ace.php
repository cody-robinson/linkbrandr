<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width">

    <title><?php echo e($header->getTitle()); ?></title>

    <!-- google fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato:100,300,400,700|Open+Sans:400,600,700,300">

    <!-- css libraries -->
    <link rel="stylesheet" href="/common/lib2/styles/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>

    <!-- theme styles -->
    <link rel="stylesheet" type="text/css" href="/common/lib2/styles/compiled/theme_styles.css"/>
    <link rel="stylesheet" type="text/css" href="/common/lib2/styles/compiled/custom_styles.css"/>

    <?php if(isset($Lib2OverridingStyles) && $Lib2OverridingStyles): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e($Lib2OverridingStyles); ?>"/>
    <?php endif; ?>

    <?php if(isset($Favicon) && $Favicon): ?>
        <link rel="shortcut icon" href="<?php echo e($Favicon); ?>"/>
    <?php endif; ?>

    <!-- Stylesheets included once -->
    <?php $__currentLoopData = $includedStylesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedStylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo $includedStylesheet; ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- javascript libraries -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="/common/lib2/scripts/jquery.nanoscroller.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- theme scripts -->
    <script src="/common/lib2/scripts/scripts.js"></script>
    <script src="/common/lib2/scripts/jquery-ui.custom.min.js"></script>

    <!-- app scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- Scripts included once -->
    <?php $__currentLoopData = $includedScripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includedScript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo $includedScript; ?>"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</head>
<body class="<?php if(isset($themeCssClass)): ?><?php echo e($themeCssClass); ?><?php else: ?> theme-whbl <?php endif; ?> pace-done" id="login-page">
<div id="theme-wrapper" class="public">

    <header class="navbar" id="header-navbar">
        <div class="container">
            <div class="clearfix">

                <div class="navbar-left">
                    <a href="/">
                        <h3 class="header-title">
                            <?php echo e($navbar->getTitle()); ?>

                        </h3>
                    </a>
                </div>

            </div>
        </div>
    </header>

    <div id="page-wrapper" class="container">
        <div class="row">

            <div id="content-wrapper" class="full-screen-remove-sidebar">
                <div class="row">
                    <div class="col-lg-12">

                        <?php if(View::hasSection('header-title') || View::hasSection('header-body')): ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="main-box">
                                        <div class="main-box-header clearfix">
                                            <h2><?php echo $__env->yieldContent('header-title'); ?></h2>
                                        </div>
                                        <div class="main-box-body clearfix">
                                            <?php echo $__env->yieldContent('header-body'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(View::hasSection('body-title') || View::hasSection('body-content')): ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="main-box">
                                        <div class="main-box-header clearfix">
                                            <h2><?php echo $__env->yieldContent('body-title'); ?></h2>
                                        </div>
                                        <div class="main-box-body clearfix">
                                            <?php echo $__env->yieldContent('body-content'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo $__env->yieldContent('body-content-custom'); ?>

                    </div>
                </div>

            </div> <!-- end of content wrapper -->
        </div>
    </div> <!-- end of page wrapper -->
</div> <!-- end of theme wrapper -->

</body>
</html>


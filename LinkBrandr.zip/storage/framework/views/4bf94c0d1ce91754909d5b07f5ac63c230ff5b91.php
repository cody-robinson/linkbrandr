<?php echo '<'; ?>?php namespace <?php echo e($namespace); ?>;

use Grav\Http\Forms\Definitions\FormDefinition;

<?php $__currentLoopData = $usingTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usingType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
use <?php echo $usingType; ?>;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $usingElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usingElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
use <?php echo $usingElement; ?>;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

class <?php echo e($className); ?> extends FormDefinition
{
    public function define()
    {
<?php if($primaryKey): ?>
        $this->setPrimaryKey('<?php echo e($primaryKey); ?>');
<?php endif; ?>

<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = preg_split("/((\r?\n)|(\r\n?))/", $field); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $line; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    }
}

<?php $__env->startSection('body-title', 'User Listing'); ?>

<?php $__env->startSection('body-content'); ?>
    <!-- this project rolls it's own user management system
    add some basic styles/scripts to utilize data tables -->
    <style>
        .no-sort:after {
            content: '' !important;
        }
    </style>
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th class="no-sort">Username</th>
                <th class="no-sort">Full Name</th>
                <th class="no-sort">Account Status</th>
                <th class="no-sort">Business Name</th>
                <th class="no-sort">Sign-up Date</th>
                <th class="no-sort"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $UsersInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/users/user-profile/<?php echo e($UserInfo->ID); ?>"><?php if(is_numeric($UserInfo->Username) && $UserInfo->Person->PrimaryEmail): ?> <?php echo e($UserInfo->Person->PrimaryEmail); ?> <?php elseif(is_numeric($UserInfo->Username) && !$UserInfo->Person->PrimaryEmail): ?> <?php echo e($UserInfo->Username); ?> <?php else: ?><?php echo e($UserInfo->Username); ?><?php endif; ?></a></td>
                    <td>
                        <?php echo e($UserInfo->FullName); ?>

                    </td>
                    <td>
                        <?php if($UserInfo->UserProfile): ?>
                            <?php if($UserInfo->UserProfile->IsPaidSubscription==1): ?> <strong class="text-success">Paid</strong>
                            <?php else: ?> <strong class="text-danger">Trial</strong>
                            <?php endif; ?>
                            and
                            <?php if(strtotime($UserInfo->UserProfile->AccountExpiryDate) < time() ): ?> <strong class="text-danger">Expired</strong>
                            <?php else: ?> <strong class="text-success">Active</strong>
                            <?php endif; ?>
                        <?php else: ?>
                            No Profile Created
                        <?php endif; ?>
                    </td>
                    <td><?php if($UserInfo->UserProfile): ?><?php echo e($UserInfo->UserProfile->BusinessName); ?> <?php else: ?> No Profile Created <?php endif; ?></td>
                    <td><?php echo e($UserInfo->SignupDate); ?></td>
                    <td><a href="/users/delete-user/<?php echo e($UserInfo->ID); ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('.table').DataTable( {
                "iDisplayLength": 50,
                "bLengthChange": true,
                searching: false
            } );
        } );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
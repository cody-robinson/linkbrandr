<?php echo e(UI::includeStylesheet(common_path('styles/compiled/theme_styles.css'))); ?>

<?php echo e(UI::includeStylesheet(common_path('styles/compiled/custom_styles.css'))); ?>

<?php echo e(UI::includeStylesheet(common_path('styles/form/example_fields.css'))); ?>


<?php $__env->startSection('content'); ?>

    <?php echo form_open($form); ?>


    <div class="row">

        <div class="col-lg-12">
            <h1>Form Elements</h1>
        </div>

    </div>

    <div class="row">

        <div class="col-lg-6 col-md-6 col-sm-6">
            <h2>Basic Elements</h2>

            <h4>String Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['String']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['PasswordString']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['EmailString']); ?>

            </div>

            <h4>Number Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['Number']); ?>

            </div>

            <h4>Date Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['Date']); ?>

            </div>
            <div class="form-group">
                <?php echo form_element($form['JqueryDate']); ?>

            </div>
            <h4>Date-Time Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['DateTime']); ?>

            </div>
            <div class="form-group">
                <?php echo form_element($form['JqueryDateTime']); ?>

            </div>
            <h4>Select Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['ListCollection']); ?>

            </div>
            <div class="form-group">
                <?php echo form_element($form['MultiValueDropdown']); ?>

            </div>
            <div class="form-group">
                <?php echo form_element($form['MultiValueCheckbox']); ?>

            </div>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6">
            <h2>Other Elements</h2>

            <h4>Boolean Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['Boolean']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['BootstrapBoolean']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['SwitchBoolean']); ?>

            </div>

            <h4>File Field Types</h4>
            <div class="form-group">
                <?php echo form_element($form['AnyFile']); ?>

            </div>
            <div class="form-group">
                <?php echo form_element($form['PhotoFile']); ?>

            </div>
            <h4>Button Field Types</h4>
            <div class="form-group">
                <?php echo form_element($form['Button']); ?>

            </div>

            <h4>Collection Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['AutoCompleteCollection']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['RadioCollection']); ?>

            </div>

            <div class="form-group">
                <?php echo form_element($form['BootstrapRadioCollection']); ?>

            </div>
        </div>

    </div>

    <div class="row">

        <div class="col-lg-12">
            <h4>Location Type Elements</h4>
            <div class="form-group">
                <?php echo form_element($form['Location']); ?>

            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-default">
            </div>
        </div>

        <?php echo form_close($form); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('devtools.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if($item->currentUserIsAuthorized()): ?>
    <?php if(!($item->hasItems() && !$item->hasAuthorizedItems())): ?>
        <?php echo e($item->preRenderSetup()); ?>


        <li <?php echo $item->getListItemAttributeString(); ?>>
            <a <?php echo $item->getAnchorAttributeString(); ?>>
                <i <?php echo $item->getIconAttributeString(); ?>></i>
                <?php echo e($item->getLabel()); ?>

                <?php if($item->hasItems()): ?> <i class="fa fa-caret-down" aria-hidden="true"></i> <?php endif; ?>
            </a>

            <?php if($item->hasAuthorizedItems()): ?>
                <ul class="dropdown-menu dropdown-menu-right">
                    <?php $__currentLoopData = $item->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php echo $__env->make('gravUI::navbar.navbar-item', ['item' => $subItem], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </li>

    <?php endif; ?>
<?php endif; ?>
<?php $__env->startSection('body-content-custom'); ?>

    <div class="row">

        <div class="col-lg-4 col-md-6 col-sm-12 clearfix">
            <div class="main-box">
                <div class="listing_cont" style="height: 184px;">
                    <div class="main-box-header clearfix">
                        <h4>Public User Management</h4>
                    </div>

                    <div class="main-box-body clearfix">
                        <p class="listing">
                            <a href="/lib2/usermanagement/users/userListing">User Listing</a><br>
                            <!--<a href="/lib2/usermanagement/types">User Types</a><br>-->
                            <!--<a href="/lib2/usermanagement/users/userActivityReport">User Activity Report</a><br>-->
                            <a href="/lib2/usermanagement/users/userAuthLog">User Authentication Log</a><br>
                        </p>
                    </div>
                </div>
            </div>
        </div>


        <?php if($AllowAdminUsersAdd || $AllowAdminUsersDelete || $AllowAdminUsersEditRoles || $AllowAdminUsersActivityReports): ?>
        <div class="col-lg-4 col-md-6 col-sm-12 clearfix">
            <div class="main-box">
                <div class="listing_cont" style="height: 184px;">
                    <div class="main-box-header clearfix">
                        <h4>Admin User Management</h4>
                    </div>

                    <div class="main-box-body clearfix">
                        <p class="listing">
                            <?php if($AllowAdminUsersAdd || $AllowAdminUsersDelete): ?>
                                <a href="/lib2/usermanagement/admin/adminUserListing">Admin User Listing</a><br>
                            <?php endif; ?>
                            <?php if($AllowAdminUsersEditRoles): ?>
                                    <a href="/lib2/usermanagement/roles">Admin User Roles</a><br>
                            <?php endif; ?>
                            <?php if($AllowAdminUsersActivityReports): ?>
                                   <!-- <a href="/lib2/usermanagement/admin/adminUserActivityReport">Admin User Activity Report</a><br>-->
                                    <a href="/lib2/usermanagement/admin/adminUserAuthLog">Admin User Authentication Log</a><br>
                            <?php endif; ?>    
                        </p>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
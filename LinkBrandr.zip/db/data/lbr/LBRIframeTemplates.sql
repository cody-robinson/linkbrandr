INSERT INTO LBRIframeTemplates (ID, Name, CSSClassName) VALUES (1, 'Rounded', 'theme-one');
INSERT INTO LBRIframeTemplates (ID, Name, CSSClassName) VALUES (2, 'Executive', 'theme-two');
INSERT INTO LBRIframeTemplates (ID, Name, CSSClassName) VALUES (3, 'Minimal', 'theme-three');
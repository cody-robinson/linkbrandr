INSERT INTO LBRBackgroundImages (ID, Name, ImagePath) VALUES (1, 'Modern Black', 'background-1.jpg');
INSERT INTO LBRBackgroundImages  (ID, Name, ImagePath) VALUES (2, 'Black Chevron', 'background-2.jpg');
INSERT INTO LBRBackgroundImages  (ID, Name, ImagePath) VALUES (3, 'Cityscape', 'background-3.jpg');
INSERT INTO LBRBackgroundImages  (ID, Name, ImagePath) VALUES (4, 'Rustic Wood', 'background-4.jpg');
INSERT INTO LBRBackgroundImages  (ID, Name, ImagePath) VALUES (5, 'Ocean', 'background-5.jpg');
-- -----------------------------------------------------
-- Table `LBRSplashTemplates`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LBRSplashTemplates` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(100) NULL COMMENT '',
  `TemplateFile` VARCHAR(100) NOT NULL COMMENT '',
  PRIMARY KEY (`ID`)  COMMENT '')
ENGINE = InnoDB;

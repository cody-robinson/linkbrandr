-- -----------------------------------------------------
-- Table `LBRBackgroundImages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LBRBackgroundImages` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(100) NULL COMMENT '',
  `ImagePath` VARCHAR(100) NOT NULL COMMENT '',
  PRIMARY KEY (`ID`)  COMMENT '')
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `LBRSharedLinks`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LBRSharedLinks` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `Link` VARCHAR(500) NOT NULL COMMENT '',
  `LBRUserProfiles_ID` INT UNSIGNED NOT NULL COMMENT '',
  `Description` VARCHAR(500) NULL COMMENT '',
  `ShareType` ENUM('splash', 'iframe', 'both') NOT NULL DEFAULT 'iframe',
  `IsIframeSupported` TINYINT(1) NOT NULL COMMENT '',
  `Title` VARCHAR(250) NOT NULL COMMENT '',
  `Image` VARCHAR(250) NOT NULL COMMENT '',
  `Favicon` VARCHAR(250) NULL COMMENT '',
  `Slug` VARCHAR(100) NULL COMMENT '',
  `DateAdded` DATETIME NOT NULL COMMENT '',
  `LastModified` DATETIME NOT NULL COMMENT '',
  `IsActive` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '',
  PRIMARY KEY (`ID`)  COMMENT '',
  INDEX `LBRUserProfiles_LBRSharedLinks_idx` (`LBRUserProfiles_ID` ASC)  COMMENT '')
ENGINE = InnoDB;
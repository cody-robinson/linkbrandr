-- -----------------------------------------------------
-- Table `LBRUserProfiles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LBRUserProfiles` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BusinessName` varchar(255) DEFAULT NULL,
  `BusinessDescription` varchar(255) DEFAULT NULL,
  `Headline` varchar(255) DEFAULT NULL,
  `ButtonText` varchar(255) DEFAULT NULL,
  `USRUsers_ID` int(10) unsigned NOT NULL,
  `LBRSplashTemplates_ID` int(10) unsigned NOT NULL,
  `LBRIframeTemplates_ID` int(10) unsigned NOT NULL,
  `LBRColorSchemes_ID` int(10) unsigned NOT NULL,
  `LastModified` datetime NOT NULL,
  `DateAdded` datetime NOT NULL,
  `ProfileImage` varchar(100) DEFAULT NULL,
  `ImageOrientation` varchar(100) DEFAULT 'landscape',
  `ImageType` varchar(100) DEFAULT NULL,
  `SplashBackgroundImage` varchar(100) DEFAULT NULL,
  `LBRBackgroundImages_ID` int(10) unsigned NOT NULL DEFAULT 1,
  `ProfileURL` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `AccountExpiryDate` DATETIME NOT NULL COMMENT '',
  `Birthday` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Gender` varchar(100) DEFAULT NULL,
  `IsPaidSubscription` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '',
  `StripeCustomerID` varchar(30) default null,
  `IsActive` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`ID`),
  KEY `USRUsers_LBRUserProfiles_idx` (`USRUsers_ID`),
  KEY `LBRColorSchemes_LBRUserProfiles_idx` (`LBRColorSchemes_ID`),
  KEY `LBRUserProfiles_LBRSplashTemplates_idx` (`LBRSplashTemplates_ID`),
  KEY `LBRUserProfiles_LBRIframeTemplates_idx` (`LBRIframeTemplates_ID`)
) ENGINE=InnoDB;

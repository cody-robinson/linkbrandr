CREATE TABLE LBRUserProfileTransactions (
  ID INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  LBRUserProfiles_ID INTEGER UNSIGNED NOT NULL,
  Amount decimal(5,2),
  StripeReply text, 
    LastModified datetime NOT NULL,
  DateAdded datetime NOT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB;
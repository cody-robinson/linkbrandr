
-- -----------------------------------------------------
-- Table `LBRColorSchemes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `LBRColorSchemes` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `SchemeName` VARCHAR(50) NOT NULL COMMENT '',
  `Colors` VARCHAR(255) NOT NULL COMMENT '',
  PRIMARY KEY (`ID`)  COMMENT '')
ENGINE = InnoDB;

ALTER TABLE LBRUserProfiles ADD COLUMN `Location` varchar(100) DEFAULT NULL AFTER `Birthday`;
ALTER TABLE LBRUserProfiles ADD COLUMN `Gender` varchar(100) DEFAULT NULL AFTER `Location`;
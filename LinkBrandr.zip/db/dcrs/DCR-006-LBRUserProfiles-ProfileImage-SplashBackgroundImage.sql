ALTER TABLE `LBRUserProfiles`
ADD COLUMN `ProfileImage` VARCHAR(100) NULL COMMENT '' AFTER `DateAdded`,
ADD COLUMN `SplashBackgroundImage` VARCHAR(100) NULL COMMENT '' AFTER `ProfileImage`;

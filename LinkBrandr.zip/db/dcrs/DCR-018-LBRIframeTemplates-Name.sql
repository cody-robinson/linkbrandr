UPDATE `LBRIframeTemplates` SET `Name`='Rounded' WHERE `ID`='1';
UPDATE `LBRIframeTemplates` SET `Name`='Executive' WHERE `ID`='2';
UPDATE `LBRIframeTemplates` SET `Name`='Minimal' WHERE `ID`='3';
Alter TABLE `USRAdminUsers`
ADD COLUMN  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL;

Alter TABLE `USRUsers`
ADD COLUMN  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL;
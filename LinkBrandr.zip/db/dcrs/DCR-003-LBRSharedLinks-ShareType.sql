# replacing IsIframe and IsSplash with ShareType

ALTER TABLE `LBRSharedLinks`
DROP COLUMN `IsIframe`,
DROP COLUMN `IsSplash`,
ADD COLUMN `ShareType` ENUM('splash', 'iframe') NOT NULL DEFAULT 'iframe' COMMENT '' AFTER `Description`;

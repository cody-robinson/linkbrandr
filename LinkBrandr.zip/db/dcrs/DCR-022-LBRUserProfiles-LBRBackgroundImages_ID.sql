ALTER TABLE `LBRUserProfiles`
ADD COLUMN `LBRBackgroundImages_ID` int(10) unsigned NOT NULL DEFAULT 1 AFTER `SplashBackgroundImage`;
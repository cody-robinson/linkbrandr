ALTER TABLE `LBRUserProfiles`
ADD COLUMN `ImageOrientation` varchar(100) DEFAULT 'landscape' AFTER `ImageType`;
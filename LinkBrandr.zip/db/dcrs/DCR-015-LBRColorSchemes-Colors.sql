UPDATE `LBRColorSchemes` SET `Colors`='["black","#74c000"]' WHERE `ID`='2';
UPDATE `LBRColorSchemes` SET `Colors`='["#ff6328","#ffb07c"]' WHERE `ID`='10';
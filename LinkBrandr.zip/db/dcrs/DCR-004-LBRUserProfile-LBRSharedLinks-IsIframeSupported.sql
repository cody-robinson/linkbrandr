ALTER TABLE `LBRUserProfiles`
DROP COLUMN `IsIframeSupported`;

ALTER TABLE `LBRSharedLinks`
ADD COLUMN `IsIframeSupported` TINYINT(1) NOT NULL COMMENT '' AFTER `ShareType`;

ALTER TABLE `LBRIframeTemplates`
CHANGE COLUMN `TemplateFile` `CSSClassName` VARCHAR(100) NOT NULL DEFAULT '' COMMENT '' ;


UPDATE `LBRIframeTemplates` SET `CSSClassName`='theme-one' WHERE `ID`='1';
UPDATE `LBRIframeTemplates` SET `CSSClassName`='theme-two' WHERE `ID`='2';
UPDATE `LBRIframeTemplates` SET `CSSClassName`='theme-three' WHERE `ID`='3';

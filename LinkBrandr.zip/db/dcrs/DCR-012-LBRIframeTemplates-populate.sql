TRUNCATE TABLE LBRIframeTemplates;

INSERT INTO LBRIframeTemplates (ID, Name, TemplateFile) VALUES (1, 'theme-one', 'PublicSharedLinkIframeView');
INSERT INTO LBRIframeTemplates (ID, Name, TemplateFile) VALUES (2, 'theme-two', 'PublicSharedLinkIframeView');
INSERT INTO LBRIframeTemplates (ID, Name, TemplateFile) VALUES (3, 'theme-three', 'PublicSharedLinkIframeView');
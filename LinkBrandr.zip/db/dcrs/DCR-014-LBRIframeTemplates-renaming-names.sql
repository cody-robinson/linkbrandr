UPDATE `LBRIframeTemplates` SET `Name`='theme-1' WHERE `ID`='1';
UPDATE `LBRIframeTemplates` SET `Name`='theme-2' WHERE `ID`='2';
UPDATE `LBRIframeTemplates` SET `Name`='theme-3' WHERE `ID`='3';

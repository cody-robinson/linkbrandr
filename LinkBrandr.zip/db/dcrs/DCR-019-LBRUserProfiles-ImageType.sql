ALTER TABLE `LBRUserProfiles`
ADD COLUMN `ImageType` varchar(100) DEFAULT NULL AFTER `ProfileImage`;
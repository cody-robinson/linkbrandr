TRUNCATE TABLE LBRColorSchemes;

INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (1, 'Default', '["black","#ff7800"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (2, 'Lime', '["#74c000","white"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (3, 'Gray', '["#484848","#c8b37a"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (4, 'Teal', '["#0199ae","#e28a39"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (5, 'Purple', '["#11091e","#b854d2"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (6, 'Slate', '["#ddd","#818da5"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (7, 'Black', '["black","#c93c06"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (8, 'Blue', '["#96d9ea","#59c4e0"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (9, 'Coral', '["#ff574f","#ffd40c"]');
INSERT INTO LBRColorSchemes (ID, SchemeName, Colors) VALUES (10, 'Orange', '["#ff6328","white"]');


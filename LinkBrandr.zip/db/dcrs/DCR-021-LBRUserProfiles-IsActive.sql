ALTER table `LBRUserProfiles` ADD column `IsActive` BOOL NOT NULL DEFAULT 1;

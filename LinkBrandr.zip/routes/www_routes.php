<?php

//need to force https on public home page, it has registration form
Route::get('/', 'www\PublicController@showPublicIndex')->middleware('forceHttps');

Route::get('/login', '\Grav\Http\Controllers\Auth\AuthPublicController@showLoginForm')->middleware('forceHttps');
Route::get('/register', 'Auth\UserRegisterController@showRegistrationForm')->middleware('forceHttps');

Route::get('/home', function(){
   return redirect()->to('/share-link/listing');
});

//need to figure out the root cause of this problem
Route::get('/favicon.ico', function(){
    return redirect()->to('/share-link/listing');
});

Route::get('/share-link/listing', 'www\ShareLinkController@listing')->middleware('forceHttp');

Route::get('/static-page', function () {
    return view('www.static');
})->middleware('auth.public');

Route::get('login/facebook', 'www\SocialLoginController@redirectToProvider');
Route::get('login/facebook/callback', 'www\SocialLoginController@handleProviderCallback');

Route::get('/link/{slug}', 'www\PublicDisplayLinkController@displayLink')->middleware('forceHttp');

Route::get('/privacy','www\PublicController@displayPrivacyPolicies');
Route::get('/contact','www\PublicController@displayContactForm');
Route::get('/terms','www\PublicController@displayTerms');

Route::get('/home/welcome', 'www\HomeController@showWelcomeScreen');
Route::get('/payment-success', 'www\HomeController@showPaymentSuccessScreen');

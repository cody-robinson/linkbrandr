<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

// admin sub-domain only routes
Route::group(['domain' =>  'admin.'.(\GravDomain::FetchDomainName())], function () {

   // Route::auth();

    Route::get('/register', '\App\Http\Controllers\Auth\AdminRegisterController@showRegistrationForm')->name('registerAdmin');
    Route::post('/register', '\App\Http\Controllers\Auth\AdminRegisterController@register');

    Route::get('/password/change', function() {return view('admin.changePassword'); });
    Route::post('/password/change', '\Grav\Http\Controllers\Auth\AdminUpdatePasswordController@update');

    Route::get('/login', array('as' => 'login', 'uses' => '\Grav\Http\Controllers\Auth\AuthAdminController@showLoginForm'));
    Route::post('/login', array('as' => 'login', 'uses' => '\Grav\Http\Controllers\Auth\AuthAdminController@authenticate'));
    Route::get('/logout', array('as' => 'logout', 'uses' => '\Grav\Http\Controllers\Auth\AuthAdminController@logout'));

    Route::post('password/email', array('as' => 'forgot', 'uses'=>'\Grav\Http\Controllers\Auth\AuthAdminController@forgot'));
    Route::get('password/reset', array('as'=>'getForgot', 'uses'=>'\Grav\Http\Controllers\Auth\ForgotPasswordController@showLinkRequestForm'));
    Route::post('password/reset', array('as'=>'postForgot','uses'=>'\Grav\Http\Controllers\Auth\ResetPasswordController@reset'));
    Route::get('password/reset/{token}', '\Grav\Http\Controllers\Auth\ResetPasswordController@showResetForm')->name('password.reset');



    ##### EXCLUSIVE ROUTES DEFINED HERE, OVERRIDING GENERIC ROUTE CONTROLLER AND AUTHENTICATION
    # ALL GENERIC ROUTES ARE PROTECTED VIA AUTHENTICATION MECHANISM
    include_once 'admin_routes.php';
    ### END OF EXCLUSIVE ROUTES

    Route::group(['middleware' => ['auth.admin'/*, 'log.admin'*/]], function () {
        ### GENERIC ROUTES START
        Route::get('/{controller}/', '\Grav\Http\Controllers\MainController@ControllerDefault');
        Route::get('/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@SimpleCall')->where(['method' => '[a-zA-Z\-]+', 'id' => '\d+' ]);
        Route::get('/{parent}/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@ParentCall')->where([ 'method' => '[a-zA-Z\-]+', 'id'=>'[a-zA-Z0-9\-]+' ]);

        // to cover cases like /voyages/spitsbergen-encounter/experiences, where 'spitsbergen-encounter' used as an id
        Route::get('/{controller}/{id}/{method}/', '\Grav\Http\Controllers\MainController@SimpleCallReverseOrder')->where(['method' => '[a-zA-Z\-]+', 'id' => '[a-zA-Z\-]+' ]);

        Route::post('/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@SimpleCall')->where(['method' => '[a-zA-Z\-]+', 'id' => '\d+' ]);
        Route::post('/{parent}/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@ParentCall')->where([ 'method' => '[a-zA-Z\-]+' ]);
    });
});

// public/www sub-domain only routes
Route::group(['domain' => 'www.'.(\GravDomain::FetchDomainName())], function () {


    //Route::auth();

    Route::get('/password/change', function() {return view('www.changePassword'); });
    Route::post('/password/change', '\Grav\Http\Controllers\Auth\PublicUpdatePasswordController@update');

    Route::get('/login', array('as' => 'publicLogin', 'uses' => '\Grav\Http\Controllers\Auth\AuthPublicController@showLoginForm'));
    Route::post('/login', array('as' => 'publicLogin', 'uses' => '\Grav\Http\Controllers\Auth\AuthPublicController@authenticate'));
    Route::get('/logout', array('as' => 'publicLogout', 'uses' => '\Grav\Http\Controllers\Auth\AuthPublicController@logout'));

    Route::post('password/email', array('as' => 'publicForgot', 'uses'=>'\Grav\Http\Controllers\Auth\AuthPublicController@forgot'));

    Route::get('password/reset', array('as'=>'publicGetForgot', 'uses'=>'\Grav\Http\Controllers\Auth\PublicForgotPasswordController@showLinkRequestForm'));
    Route::post('password/reset', array('as'=>'publicPostForgot','uses'=>'\Grav\Http\Controllers\Auth\ResetPasswordController@resetPublic'));
    Route::get('password/reset/{token}', '\Grav\Http\Controllers\Auth\ResetPasswordController@showResetForm')->name('password.reset');;


    Route::get('/register', '\App\Http\Controllers\Auth\UserRegisterController@showRegistrationForm')->name('registerUser');
    Route::post('/register', '\App\Http\Controllers\Auth\UserRegisterController@register');

    Route::post('/contactFormSubmission', '\App\Http\Controllers\MailController@contactFormSubmission');


    ##### EXCLUSIVE ROUTES DEFINED HERE, OVERRIDING GENERIC ROUTE CONTROLLER AND AUTHENTICATION
    # ALL GENERIC ROUTES ARE PROTECTED VIA AUTHENTICATION MECHANISM
    include_once 'www_routes.php';
    ### END OF EXCLUSIVE ROUTES

    Route::group(['middleware' => 'auth.public'], function () {
        ### GENERIC ROUTES START

        Route::get('/{controller}/', '\Grav\Http\Controllers\MainController@ControllerDefaultPublic');

        Route::get('/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@SimpleCallPublic')->where(['method' => '[a-zA-Z\-]+', 'id' => '\d+' ]);
        Route::get('/{parent}/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@ParentCallPublic')->where([ 'method' => '[a-zA-Z\-]+', 'id'=>'[a-zA-Z0-9\-]+' ]);

        // to cover cases like /voyages/spitsbergen-encounter/experiences, where 'spitsbergen-encounter' used as an id
        Route::get('/{controller}/{id}/{method}/', '\Grav\Http\Controllers\MainController@SimpleCallReverseOrderPublic')->where(['method' => '[a-zA-Z\-]+', 'id' => '[a-zA-Z\-]+' ]);

        Route::post('/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@SimpleCallPublic')->where(['method' => '[a-zA-Z\-]+', 'id' => '\d+' ]);
        Route::post('/{parent}/{controller}/{method}/{id?}', '\Grav\Http\Controllers\MainController@ParentCallPublic')->where([ 'method' => '[a-zA-Z\-]+' ]);
    });
});


#  Routing rule to serve shared links for short domain lbdr.co

Route::group(['domain' => 'lbdr.co'], function () {

    // this routing rule will be picked when the request is http://lbdr.co and redirect to linkbrandr.com
    Route::get('/', function(){
        return redirect()->to('https://www.linkbrandr.com');
    });

    // this routing rule will be picked when there is a request like http://lbdr.co/b1n234s  <- slug
    // it then redirects to the main domain url http://www.25.dev-12.grav/link/b1n234s
    Route::get('/{slug}', function($slug){
        $baseUrl = 'http://www.'.\GravDomain::FetchDomainName();
        return redirect()->to($baseUrl."/link/".$slug);
    });


    /// here is routing rule which picks the same request above, but instead of redirect it just calls the controller & method we wanted to use
    // Route::get('/{slug}', 'www\PublicDisplayLinkController@displayLink');
});
<?php

return [
    ['/static-page','user'],
    ['/home', 'user'],
];
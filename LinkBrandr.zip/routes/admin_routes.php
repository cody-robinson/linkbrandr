<?php

Route::get('/', function () {
    return redirect()->to('/home');
});

Route::get('/users/adminUserListing', 'Admin\UsersController@adminUserListing');
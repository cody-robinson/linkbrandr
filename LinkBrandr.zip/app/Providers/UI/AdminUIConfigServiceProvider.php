<?php

namespace App\Providers\UI;

use App\Services\UI\AdminUIConfigService;
use Grav\UI\AdminUIService;
use Grav\UI\Contracts\IAdminUIConfigService;
use Grav\UI\InterfaceElements\Item;
use Illuminate\Support\ServiceProvider;

class AdminUIConfigServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IAdminUIConfigService::class, AdminUIConfigService::class);
    }
    
}

<?php namespace App\Http\Forms\Definitions\LBR;

use Faker\Provider\File;
use Grav\Http\Forms\Definitions\FormDefinition;

use Grav\Http\Forms\Fields\Elements\HtmlElements\HiddenFieldElement;
use Grav\Http\Forms\Fields\Elements\HtmlElements\RadioButtonFieldElement;
use Grav\Http\Forms\Fields\Types\ButtonFieldType;
use Grav\Http\Forms\Fields\Types\DateFieldType;
use Grav\Http\Forms\Fields\Types\FileFieldType;
use Grav\Http\Forms\Fields\Types\MultiValueFieldType;
use Grav\Http\Forms\Fields\Types\NumberFieldType;
use Grav\Http\Forms\Fields\Types\StringFieldType;
use Grav\Http\Forms\Fields\Types\BooleanFieldType;
use Grav\Http\Forms\Fields\Types\CollectionFieldType;

use Grav\Http\Forms\Fields\Elements\HtmlElements\Contracts\IHiddenFieldElement;
use Illuminate\Support\Str;
use Symfony\Component\DomCrawler\Field\FileFormField;
use Symfony\Component\DomCrawler\Tests\Field\FileFormFieldTest;

class UserProfileFormDefinition extends FormDefinition
{
    public function define()
    {
        $this->setPrimaryKey('LBRUserProfiles.ID');

        $this->from(
            'LBRUserProfiles',
            function () {
                //$this->add(new NumberFieldType('ID'))->element(IHiddenFieldElement::class);

                $this->add(new StringFieldType('BusinessName'));

                $this->add(new StringFieldType('BusinessDescription'));

                $this->add(new StringFieldType('Headline'));

                $this->add(new StringFieldType('ButtonText'));

                $this->add(new StringFieldType('ProfileURL'));

                $field = new CollectionFieldType('ImageType');
                $field->getDbMapping()->autoLookup('LBRUserProfiles', 'ImageType', 'ImageType');
                $field->collection(['Headshot'=>'Headshot', 'Logo'=>'Logo']);
                $field->setElement(RadioButtonFieldElement::class);
                $this->add($field);

                $field = new CollectionFieldType('ImageOrientation');
                $field->getDbMapping()->setColumnName('ImageOrientation');
                $field->collection(['landscape' => 'Landscape',  'portrait' => 'Portrait']);
                $field->setElement(RadioButtonFieldElement::class);
                $this->add($field);

                $field = new CollectionFieldType('SchemeName');
                $field->getDbMapping()->setColumnName('LBRColorSchemes_ID');
                $field->getDbMapping()->autoLookup('LBRColorSchemes','ID','SchemeName');
                $this->add($field);

                $field = new CollectionFieldType('Theme');
                $field->getDbMapping()->setColumnName('LBRIframeTemplates_ID');
                $field->getDbMapping()->autoLookup('LBRIframeTemplates','ID','Name');
                $this->add($field);

                $field = new CollectionFieldType('SplashTempName');
                $field->getDbMapping()->setColumnName('LBRSplashTemplates_ID');
                $field->getDbMapping()->autoLookup('LBRSplashTemplates','ID','SplashTempName');
                $field->setElement(HiddenFieldElement::class);
                $field->setValue(1);
                $this->add($field);

                $field = new CollectionFieldType('BackgroundImage');
                $field->getDbMapping()->setColumnName('LBRBackgroundImages_ID');
                $field->getDbMapping()->autoLookup('LBRBackgroundImages','ID','Name');
                $this->add($field);
            }
        );


    }
}

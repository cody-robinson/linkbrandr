<?php namespace App\Http\Forms\Definitions\LBR;

use Grav\Http\Forms\Definitions\FormDefinition;

use Grav\Http\Forms\Fields\Elements\HtmlElements\HiddenFieldElement;
use Grav\Http\Forms\Fields\Types\NumberFieldType;
use Grav\Http\Forms\Fields\Types\StringFieldType;
use Grav\Http\Forms\Fields\Types\CollectionFieldType;
use Grav\Http\Forms\Fields\Types\BooleanFieldType;

use App\Models\LBR\UserProfile;

use Grav\Http\Forms\Fields\Elements\HtmlElements\Contracts\IHiddenFieldElement;

class ShareLinkFormDefinition extends FormDefinition
{
    public function define()
    {
        $this->setPrimaryKey('LBRSharedLinks.ID');

        $this->from('LBRSharedLinks', function () {
            $field = new NumberFieldType('ID');
            $field->element(IHiddenFieldElement::class);
            $this->add($field);
            
            $field = new StringFieldType('Link');
            $this->add($field);
            
            $field = new CollectionFieldType('ShareType');
            $field->getDbMapping()->autoLookup('LBRSharedLinks', 'ShareType', 'ShareType');
            $field->setCollection(['splash'=>'splash','iframe'=>'iframe']);
            $this->add($field);
            
            $field = new StringFieldType('Description');
            $this->add($field);

            $this->add(new BooleanFieldType('IsIframeSupported'));

            $field = new StringFieldType('Title');
            $this->add($field);

            $field = new StringFieldType('Image');
            $this->add($field);

            $field = new StringFieldType('Favicon');
            $this->add($field);
            
            $field = new StringFieldType('Slug');
            $this->add($field);

            $User = \Auth::guard('web')->user();
            $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->get()->first();

            $field = new NumberFieldType('LBRUserProfiles_ID');
            $field->setValue($Profile->ID);
            $field->element(IHiddenFieldElement::class);
            $this->add($field);
            
        });
        
        $this->from('LBRUserProfiles', function () {
            /*   $field = new NumberFieldType('LBRUserProfiles_ID', 'User Profile ID');

               $field->element(IHiddenFieldElement::class);
                $field->getDbMapping()->setTableName('LBRUserProfiles');
                $field->getDbMapping()->setColumnName('ID');
                $this->add($field);

                $field = new StringFieldType('BusinessName');
                $this->add($field);

                $field = new StringFieldType('BusinessDescription');
                $this->add($field);

                $field = new StringFieldType('Headline');
                $this->add($field);

                $field = new StringFieldType('Subtitle');
                $this->add($field);

                $field = new CollectionFieldType('USRUsers_ID', 'User');
                $field->getDbMapping()->autoLookup();
                $this->add($field);

                $field = new CollectionFieldType('LBRSplashTemplates_ID', 'Splash Template');
                $field->getDbMapping()->autoLookup();
                $this->add($field);

                $field = new CollectionFieldType('LBRIframeTemplates_ID', 'Iframe Template');
                $field->getDbMapping()->autoLookup();
                $this->add($field);

                $field = new CollectionFieldType('LBRColorSchemes_ID', 'Color Scheme');
                $field->getDbMapping()->autoLookup();
                $this->add($field);

                $field = new BooleanFieldType('IsIframeSupported');
                $this->add($field);*/
            
        });
        
    }
}

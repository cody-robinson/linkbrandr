<?php
namespace App\Http\Controllers\Admin;

use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\AdminAuthorization;
use Grav\Http\Forms\Traits\FormBuilder;
use Grav\UI\AdminUIService;

class HomeController extends Controller
{
    use FormBuilder;

    public function index()
    {
        $page_heading = "";
        $html = "<a href='/users/userListing'>Manage User Accounts</a>";

        /**
         * @var $adminUI AdminUIService
         */

        $adminUI = app('admin-ui');
        $adminUI->setPageTitle("Admin Dashboard");
        $adminUI->breadcrumbs()->add('Home');

        return view('admin.home',compact('html','page_heading'));
    }


}
<?php
namespace App\Http\Controllers\Admin;

use App\AL\ServiceDTOs\Users\UserInfo;
use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\AdminAuthorization;
use Grav\Http\Forms\Traits\FormBuilder;
use Grav\UI\AdminUIService;

use App\Models\USR\User;
use App\Models\PPL\Person;
use App\Models\LBR\UserProfile;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    use FormBuilder;

    /**
     * Display all users
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $PageHeading = "User Management";

        /**
         * @var $adminUI AdminUIService
         */
        $adminUI = app('admin-ui');
        $adminUI->setPageTitle("User Management");
        $adminUI->breadcrumbs()->add('Home', '/');
        $adminUI->breadcrumbs()->add('User Management');

        $Html = "User Listing";

        return view('admin.userManagement',compact('Html','PageHeading'));
    }

    public function userListing()
    {
        $PageHeading = "User Management";

        $Html = "User Listing";

        /**
         * @var $adminUI AdminUIService
         */
        $adminUI = app('admin-ui');
        $adminUI->setPageTitle("User Listing");
        $adminUI->breadcrumbs()->add('Home', '/');
        $adminUI->breadcrumbs()->add('User Management', '/users/');
        $adminUI->breadcrumbs()->add('User Listing');

        $UserReporter = \App::make('App\AL\Services\Users\UserReporter');
        $UsersInfo = $UserReporter->fetchUsers();

        return view('admin.userListing',compact('Html','PageHeading', 'UsersInfo'));
    }

    /**
     * Display User profile details
     *
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function userProfile(Request $request, $id)
    {
        $PageHeading = "Profile Details";

        /**
         * @var $adminUI AdminUIService
         */
        $adminUI = app('admin-ui');
        $adminUI->setPageTitle("User Profile");
        $adminUI->breadcrumbs()->add('Home', '/');
        $adminUI->breadcrumbs()->add('User Management', '/users');
        $adminUI->breadcrumbs()->add('User Listing', '/users/userListing');
        $adminUI->breadcrumbs()->add('User Profile');

        $UserReporter = \App::make('App\AL\Services\Users\UserReporter');
        $UserInfo = $UserReporter->fetchSingleUser($id);

        return view('admin.userProfile',compact('PageHeading', 'UserInfo'));
    }


    /**
     * AJAX - Update expiry date
     *
     * @param Request $request
     * @param $UserProfileID
     * @return \Illuminate\Http\JsonResponse
     */

    public function expiryUpdate(Request $request, $UserProfileID)
    {
        if($request->has('date')) {
            if($Profile = UserProfile::find($UserProfileID))
            {
                $newDate = date("Y-m-d", strtotime($request->get('date')));
                $Profile->AccountExpiryDate = $newDate;
                $Profile->update();

                return response()->json(["result"=>$Profile->ID]);
            }
        }

        return response()->json(["result"=>false]);
    }

    public function deleteUser(Request $request, $id){

        if ($user = User::query()->where('ID',"=",$id)->where('IsActive',"=",1)->first()) {
            $user->IsActive = 0;
            $user->Username = "x-" . $user->Username . "-" . $user->ID;
            $user->update();

            $personID = $user->PPLPeople_ID;
            if($person = Person::query()->where('ID',"=",$personID)->where('IsActive',"=",1)->first()){
                $person->IsActive = 0;
                $person->update();
            }

            if($userProfile = UserProfile::query()->where('USRUsers_ID',"=",$user->ID)->first()){
                $userProfile->IsActive = 0;
                $userProfile->update();
            }
        }
        return redirect('/users/userListing');
    }

}
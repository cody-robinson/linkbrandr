<?php

namespace App\Http\Controllers\Admin;

use Grav\Http\Controllers\Auth\AuthAdminController;
use Grav\Http\Controllers\Auth\AdminAuthorization;
use Grav\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class TestController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function index(Request $request, $id=null)
    {
        return "test";
    }



    public function userList()
    {
        $html = '';

        foreach(\Grav\Models\USR\AdminUser::all()->take(5) as $AdminUser) {
            $Person = $AdminUser->PPLPerson;
            $html .= "<h2>Username=$AdminUser->Username</h2><BR>";
            $html .= "$Person->FirstName $Person->LastName<BR>";
        }

        $page_heading = "User List";
        return view('home', compact('html','page_heading'));
    }



    public function employee123()
    {
        $html = "Numerical method called successfully";

        $page_heading = "Page with numeric method";

        return view('home', compact('html','page_heading'));
    }

    public function showPassChange()
    {
        dd('here');

        /*  return view('auth.passwords.change')->with(
              ['token' => $token, 'name' => $request->name]
          );*/
    }
}

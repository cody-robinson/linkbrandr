<?php

namespace App\Http\Controllers\api;

use Grav\Http\Controllers\Controller;
use Redirect;
use Stripe\Stripe;

use Grav\Models\USR\User;
use Grav\Models\PPL\Person;
use App\Models\LBR\UserProfile;
use App\Models\LBR\UserProfileTransaction;

class WebhookController extends Controller
{
    
    public function makePayment(){
        // Set your secret key: remember to change this to your live secret key in production
        // See your keys here: https://dashboard.stripe.com/account/apikeys
        Stripe::setApiKey(env('STRIPE_API_KEY'));
    
        // You can find your endpoint's secret in your webhook settings
        $endpoint_secret = "whsec_SdP5t6IXiEd25w3AmwDMCBOIXGBggSsZ";
    
        $payload = @file_get_contents("php://input");
        $sig_header = $_SERVER["HTTP_STRIPE_SIGNATURE"];
        $event = null;

        try {
            $event = \Stripe\Webhook::constructEvent(
                $payload, $sig_header, $endpoint_secret
            );
        } catch(\UnexpectedValueException $e) {
            // Invalid payload
            http_response_code(400); // PHP 5.4 or greater
            exit();
        } catch(\Stripe\Error\SignatureVerification $e) {
            // Invalid signature
            http_response_code(400); // PHP 5.4 or greater
            exit();
        }
    
    
//        $event = json_decode($payload);
    
    
        // Do something with $event
    
        if($event->type == 'invoice.payment_succeeded'){
            $Invoice = $event->data->object;
    
            $CustomerStripeID = $Invoice->customer;
            if(!$CustomerStripeID){
                //invalid customer
                http_response_code(400); // PHP 5.4 or greater
                exit();
            }
    
            if(app()->InProduction() == true) {
                $Plans = array('plan_DvpRcSoZLcCjhN','plan_DvpQP3KgEJUo2E');
            }
            else{
                $Plans = array('plan_E0MBJ8BTlokFea','plan_E0MBRF6cMdWDOV');
            }
            
            $Lines = $Invoice->lines;
    
            if(is_array($Lines->data)){
                foreach($Lines->data as $LineItem){

                    if($LineItem->type == 'subscription' && $LineItem->plan && isset($LineItem->plan->id)){
                                   
                        $PlanID = $LineItem->plan->id;
                        
                        
                        if(in_array($PlanID,$Plans)){

                            if(isset($LineItem->amount)){
                                $Amount = $LineItem->amount;
                                $Amount = $Amount/100; //Stripe stores it in cents
                            }
                            else{
                                //invalid amount
                                http_response_code(400); // PHP 5.4 or greater
                                exit();
                            }
                           
                            $Profile = UserProfile::query()->where('StripeCustomerID',"=",$CustomerStripeID)->where('IsActive',"=",'1')->get()->first();
                            if($Profile){
                                $transaction = new UserProfileTransaction();
                                $transaction->LBRUserProfiles_ID = $Profile->ID;
                                $transaction->Amount = $Amount;
                                $transaction->StripeReply = $payload;
                                $transaction->save();
    
                                if($PlanID == 'plan_DvpQP3KgEJUo2E' || $PlanID == 'plan_E0MBRF6cMdWDOV')
                                {
                                    $newDate = date("Y-m-d", strtotime($Profile->AccountExpiryDate." +1 month"));
                                    $Profile->AccountExpiryDate = $newDate;
                                }
                                elseif($PlanID=='plan_DvpRcSoZLcCjhN' || $PlanID == 'plan_E0MBJ8BTlokFea'){
                                    $newDate = date("Y-m-d", strtotime($Profile->AccountExpiryDate." +1 year"));
                                    $Profile->AccountExpiryDate = $newDate;
                                }
                                
                                $Profile->IsPaidSubscription = true;
                                $Profile->StripeCustomerID = $CustomerStripeID;
                                $Profile->save();
                            }
                            else{
                                //invalid customer
                                http_response_code(400); // PHP 5.4 or greater
                                exit();
                            }
                        }
                           
                    }
                }
            }
            else{
                //no line items
                http_response_code(400); // PHP 5.4 or greater
                exit();
            }
            
            
        }
        
        
        http_response_code(200); // PHP 5.4 or greater
    }
    
    
}
<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

use App\Http\Requests;
use Grav\Http\Controllers\Controller;

use Grav\Models\PPL\Person;

class MailController extends Controller {

    /**
     * A method which handles contact form submissions
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function contactFormSubmission(Request $request){

        $Name = addslashes($request->Name);
        $Email = addslashes($request->Email);
        $Message = addslashes($request->Message);

        $data = array('Name'=>$Name, 'Email'=>$Email, 'Message'=>$Message);

        Mail::send('emails.contact', $data, function($message) use ($data) {

            if(app()->InProduction() == true){
                $toEmail = 'support@linkbrandr.com';
            } else {
                $toEmail = $_SERVER['DEV_EMAIL'];
            }

            $message->to($toEmail);
            $message->subject('New Contact Form Submission');
            $message->from($data['Email'], $data['Name']);
        });

        return redirect('/contact')->with('message', 'success');
    }







}
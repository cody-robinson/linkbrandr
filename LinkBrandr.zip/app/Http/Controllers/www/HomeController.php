<?php
namespace App\Http\Controllers\www;

use Illuminate\Support\Facades\Storage;
use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;
use Grav\Models\USR\User;
use Grav\Models\PPL\Person;
use App\Models\LBR\UserProfile;
use App\Models\LBR\SharedLink;

class HomeController extends Controller
{

    public function index()
    {
        $page_heading = "User Homepage";
        $html = "Welcome home";
        return view('home',compact('html','page_heading'));
    }

    /**
     * When a user registers we check to see if they have an existing account
     *
     */
    public function checkExistingAccount()
    {

        if(\Auth::guard('web')->check())
        {
            $user = \Auth::guard('web')->user();
            $person = Person::query()->where('ID',"=",$user->PPLPeople_ID)->first();

            if(User::where('Username', '=', $person->PrimaryEmail)->where('IsActive','=',1)->first()) {

                //user registers with fb, email already exists for another account
                $checkUser = User::where('Username', '=', $person->PrimaryEmail)->where('IsActive','=',1)->first();
                $accountType = 'social';

                if ($checkUser) {
                    return $this->existingAccount($person->PrimaryEmail, $accountType);
                }
            }
        }

        return $this->showWelcomeScreen();
    }

    /**
     * When a user registers with their email, we check to see if they already have an account created through FB Login
     *
     */
    public function checkForSocialAccount() {

        if(\Auth::guard('web')->check())
        {
            $user = \Auth::guard('web')->user();
            $person = Person::query()->where('ID',"=",$user->PPLPeople_ID)->first();

            //if another PPLPeople record exists with same primary email but different ID
            if(Person::where('PrimaryEmail', '=', $person->PrimaryEmail)->where('ID', '!=', $person->ID)->where('IsActive','=',1)->first()) {

                $existingPerson = Person::where('PrimaryEmail', '=', $person->PrimaryEmail)->where('ID', '!=', $person->ID)->where('IsActive','=',1)->first();
                $existingUser = User::where('PPLPeople_ID', '=', $existingPerson->ID)->where('IsActive','=',1)->first();
                $accountType = 'email';

                //user registers with email, email already exists for FB login account
                if ($existingUser && is_numeric($existingUser->Username)) {

                    return $this->existingAccount($person->PrimaryEmail, $accountType);
                }
            }
        }

        return $this->showWelcomeScreen();
    }

    /**
     * This is a workaround when a user with an existing FB Login account tries to register with their email.
     * If they choose to login with existing FB account instead of creating a new account, we need to immediately
     * delete the new account that was created in the registration process
     *
     */
    public function deleteNewAccount(){
        if(isset($_REQUEST['userEmail'])) {
            $userEmail = $_REQUEST['userEmail'];

            // find account with email as username and delete
            $user = User::query()->where('Username',"=",$userEmail)->where('IsActive','=',1)->first();
            $user->IsActive = 0;
            $user->Username = "x-" . $user->Username . "-" . $user->ID;
            $user->update();

            $person = Person::query()->where('ID','=',$user->PPLPeople_ID)->where('IsActive','=',1)->first();
            $person->IsActive = 0;
            $person->update();

            // redirect them to fb login
            return redirect('/login/facebook');

        } else {
            return back();
        }
    }

    public function showWelcomeScreen()
    {
        $email = '';
        $firstName = '';
        $lastName = '';

        $user = \Auth::guard('web')->user();
        if($person = Person::query()->where('ID',"=",$user->PPLPeople_ID)->first()){
            $email = $person->PrimaryEmail;
            $firstName = $person->FirstName;
            $lastName = $person->LastName;
        }

        return view('www.welcome', ['email'=>$email, 'firstName'=>$firstName, 'lastName'=>$lastName]);
    }

    public function showPaymentSuccessScreen()
    {
        if(isset($_REQUEST['SubType'])){
            $subType = $_REQUEST['SubType'];
            $email = '';
            $stripeID = '';

            $user = \Auth::guard('web')->user();
            if($person = Person::query()->where('ID',"=",$user->PPLPeople_ID)->first()){

                $email = $person->PrimaryEmail;

                if ($userProfile = UserProfile::query()->where('USRUsers_ID',"=",$user->ID)->where('IsActive','=',1)->first()){

                    $stripeID = $userProfile->StripeCustomerID;

                }
            }

        return view('www.paymentSuccess', ['subType'=>$subType, 'email'=>$email, 'stripeID'=>$stripeID]);

        } else {
            return back();
        }
    }

    /**
     * Displays view to user who is trying to register but has an existing account of the opposite type (email or FB Login)
     *
     */
    public function existingAccount($userEmail, $accountType)
    {
        return view('www.existingAccount', ['userEmail'=>$userEmail, 'accountType'=>$accountType]);
    }

    /*
     * User logs in with FB and has an existing account, chooses to merge accounts. All existing links are
     * moved to new FB Login account before old account is deleted
     *
     * */
    public function mergeAccounts()
    {
        if(isset($_REQUEST['userEmail'])) {
            $userEmail = $_REQUEST['userEmail'];

            // find existing account with same email
            $user = User::query()->where('Username',"=",$userEmail)->where('IsActive','=',1)->first();
            $personID = $user->PPLPeople_ID;
            $userPerson = Person::query()->where('ID',"=",$personID)->where('IsActive','=',1)->first();
            $userProfile = UserProfile::query()->where('USRUsers_ID',"=",$user->ID)->where('IsActive','=',1)->first();

            // find fb account user
            $fbPerson = Person::query()->where('PrimaryEmail',"=",$userEmail)->where('ID',"!=",$user->PPLPeople_ID)->where('IsActive','=',1)->first();
            $fbUser = User::query()->where('PPLPeople_ID',"=",$fbPerson->ID)->where('IsActive','=',1)->first();
            $fbUserProfile = UserProfile::query()->where('USRUsers_ID',"=",$fbUser->ID)->where('IsActive','=',1)->first();

            // if LBRUserProfile exists for old account
            if($userProfile){
                $sharedLinks = SharedLink::query()->where('LBRUserProfiles_ID',"=",$userProfile->ID)->get();

                // transfer all links from old user to new user
                if($sharedLinks){
                    foreach($sharedLinks as $sharedLink){
                        $sharedLink->LBRUserProfiles_ID = $fbUserProfile->ID;
                        $sharedLink->update();
                    }
                }

                // transfer user profile details to new user
                $fbUserProfile->BusinessName = $userProfile->BusinessName;
                $fbUserProfile->BusinessDescription = $userProfile->BusinessDescription;
                $fbUserProfile->Headline = $userProfile->Headline;
                $fbUserProfile->ButtonText = $userProfile->ButtonText;
                $fbUserProfile->LBRSplashTemplates_ID = $userProfile->LBRSplashTemplates_ID;
                $fbUserProfile->LBRIframeTemplates_ID = $userProfile->LBRIframeTemplates_ID;
                $fbUserProfile->LBRColorSchemes_ID = $userProfile->LBRColorSchemes_ID;
                $fbUserProfile->ProfileImage = $userProfile->ProfileImage;
                $fbUserProfile->ImageType = $userProfile->ImageType;
                $fbUserProfile->ImageOrientation = $userProfile->ImageOrientation;
                $fbUserProfile->SplashBackgroundImage = $userProfile->SplashBackgroundImage;
                $fbUserProfile->LBRBackgroundImages_ID = $userProfile->LBRBackgroundImages_ID;
                $fbUserProfile->ProfileURL = $userProfile->ProfileURL;
                $fbUserProfile->AccountExpiryDate = $userProfile->AccountExpiryDate;
                $fbUserProfile->IsPaidSubscription = $userProfile->IsPaidSubscription;
                $fbUserProfile->update();

                // if profile image exists, change name to new user profile id
                // jpg image
                if(file_exists( 'public/uploads/profile-images/'.$userProfile->ID.'.jpg')) {
                    Storage::disk('wwwpublic')->move('profile-images/'.$userProfile->ID.'.jpg', 'profile-images/'.$fbUserProfile->ID.'.jpg');
                }
                // png logo
                if(file_exists( 'public/uploads/profile-images/'.$userProfile->ID.'.png')) {
                    Storage::disk('wwwpublic')->move('profile-images/'.$userProfile->ID.'.png', 'profile-images/'.$fbUserProfile->ID.'.png');
                }

                // delete old LBRUserProfile record
                $userProfile->IsActive = 0;
                $userProfile->update();
            }

            // delete old PPLPeople and USRUser records
            $user->IsActive = 0;
            $user->Username = "x-" . $user->Username . "-" . $user->ID;
            $user->update();

            $userPerson->IsActive = 0;
            $userPerson->update();

            return redirect('share-link/listing');

        } else {
           return back();
        }

    }

}
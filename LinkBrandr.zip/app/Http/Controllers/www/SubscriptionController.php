<?php

namespace App\Http\Controllers\www;

use Grav\Http\Controllers\Controller;
use Redirect;
use Stripe\Stripe;

use Grav\Models\USR\User;
use Grav\Models\PPL\Person;
use App\Models\LBR\UserProfile;
use App\Models\LBR\UserProfileTransaction;

class SubscriptionController extends Controller
{
    
    public function index(){
    
        $DaysToExpire = 0;
        $User = \Auth::guard('web')->user();
        $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->get()->first();
        $Person = Person::query()->where('ID','=',$User->PPLPeople_ID)->where('IsActive','=','1')->first();
        if($Profile){
            $ExpiryDate = $Profile->AccountExpiryDate;
            if($ExpiryDate > date('Y-m-d H:i:s'))
            {
                $DaysDifference = date_diff(date_create($ExpiryDate), date_create(date('Y-m-d H:i:s')));
                $DaysToExpire = $DaysDifference->format('%a');
            } else {
                return redirect()->to('/subscription/expired');
            }
        }
        
        $StripeAPIKey = env('STRIPE_API_PUBLISHABLE_KEY');

        return view('www.subscriptionDetails',['daysToExpire'=>$DaysToExpire,'userEmail'=>$Person->PrimaryEmail,'stripeAPIKey'=>$StripeAPIKey,'isPaidSubscription'=>$Profile->IsPaidSubscription]);
    }

    public function expired(){
        $DaysToExpire = 0;
        $User = \Auth::guard('web')->user();
        $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->first();
        $Person = Person::query()->where('ID','=',$User->PPLPeople_ID)->where('IsActive','=','1')->first();
        if($Profile){
            $ExpiryDate = $Profile->AccountExpiryDate;
            if($ExpiryDate > date('Y-m-d H:i:s'))
            {
                $DaysDifference = date_diff(date_create($ExpiryDate), date_create(date('Y-m-d H:i:s')));
                $DaysToExpire = $DaysDifference->format('%a');
            }
        }
    
        $StripeAPIKey = env('STRIPE_API_PUBLISHABLE_KEY');
    
        return view('www.subscriptionExpired', array('daysToExpire'=>$DaysToExpire,'userEmail'=>$Person->PrimaryEmail,'stripeAPIKey'=>$StripeAPIKey));
    }
    
    
    public function subscribeMonthly(){
        Stripe::setApiKey(env('STRIPE_API_KEY'));
    
        if(app()->InProduction() == true) {
            $PlanID = 'plan_DvpQP3KgEJUo2E';
        }
        else{
            $PlanID = 'plan_E0MBRF6cMdWDOV';
        }
        
        try{
            // Token is created using Stripe.js or Checkout!
            // Get the payment token ID submitted by the form:
            $token = $_POST['stripeToken'];
            
            $customer = \Stripe\Customer::create(array(
                'email' => $_POST['stripeEmail'],
                'source'  => $token
            ));
            
            $subscription = \Stripe\Subscription::create(array(
               'customer' => $customer->id,
               'items' => [['plan'=>$PlanID]]
            ));
        
            $User = \Auth::guard('web')->user();
            $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->get()->first();
            if($Profile){
                $transaction = new UserProfileTransaction();
                $transaction->LBRUserProfiles_ID = $Profile->ID;
                $transaction->Amount = '7.99';
                $transaction->StripeReply = $customer;
                $transaction->save();
                
                $newDate = date("Y-m-d", strtotime($Profile->AccountExpiryDate." +1 month"));
                $Profile->AccountExpiryDate = $newDate;
                $Profile->IsPaidSubscription = true;
                $Profile->StripeCustomerID = $customer->id;
                
                $Profile->save();
            }
        
        
        }
        catch(Exception $e){
            return redirect()->to('/subscription/');
        }
    
        return redirect()->to('/payment-success?SubType=Monthly');
    }
    
    public function subscribeAnnually(){
        Stripe::setApiKey(env('STRIPE_API_KEY'));
    
        if(app()->InProduction() == true) {
            $PlanID = 'plan_DvpRcSoZLcCjhN';
        }
        else{
            $PlanID = 'plan_E0MBJ8BTlokFea';
        }
    
    
        try{
            // Token is created using Stripe.js or Checkout!
            // Get the payment token ID submitted by the form:
            $token = $_POST['stripeToken'];
            
            $customer = \Stripe\Customer::create(array(
                'email' => $_POST['stripeEmail'],
                'source'  => $token
            ));
    
            $subscription = \Stripe\Subscription::create(array(
                'customer' => $customer->id,
                'items' => [['plan'=>$PlanID]]
            ));
        
            $User = \Auth::guard('web')->user();
            $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->get()->first();
            if($Profile){
                $transaction = new UserProfileTransaction();
                $transaction->LBRUserProfiles_ID = $Profile->ID;
                $transaction->Amount = '79.99';
                $transaction->StripeReply = $customer;
                $transaction->save();
            
                $newDate = date("Y-m-d", strtotime($Profile->AccountExpiryDate." +1 year"));
                $Profile->AccountExpiryDate = $newDate;
                $Profile->IsPaidSubscription = true;
                $Profile->StripeCustomerID = $customer->id;
                $Profile->save();
            }
        
        
        }
        catch(Exception $e){
            return redirect()->to('/subscription/');
        }
    
        return redirect()->to('/payment-success?SubType=Annual');
    }

    public function updateCard(){
        Stripe::setApiKey(env('STRIPE_API_KEY'));
    
        if (isset($_POST['stripeToken'])) {
            try{
                // Token is created using Stripe.js or Checkout!
                // Get the payment token ID submitted by the form:
    
                $User = \Auth::guard('web')->user();
                $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->get()->first();
                if($Profile){
                    if($CustomerID = $Profile->StripeCustomerID){
                        $token = $_POST['stripeToken'];
    
                        $customer = \Stripe\Customer::retrieve($CustomerID);
                        $customer->source = $token;
                        $customer->save();

                        $transaction = new UserProfileTransaction();
                        $transaction->LBRUserProfiles_ID = $Profile->ID;
                        $transaction->StripeReply = $customer;
                        $transaction->save();
    
                    }
                }
                
        
            }
            catch(\Stripe\Error\Card $e) {
    
                // Use the variable $error to save any errors
                // To be displayed to the customer later in the page
                $body = $e->getJsonBody();
                $err  = $body['error'];
                $error = $err['message'];
                return redirect()->to('/subscription/');
    
            }

        }

        return redirect()->to('/subscription/updateSuccessful');
    }
    
    public function updateSuccessful(){

        return redirect()->to('/subscription/')->with('message', 'success');
    }

    public function cancelSubscription(){
        Stripe::setApiKey(env('STRIPE_API_KEY'));
    
        try{
            // Token is created using Stripe.js or Checkout!
            // Get the payment token ID submitted by the form:
        
            $User = \Auth::guard('web')->user();
            $Profile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->where('IsActive',"=",'1')->get()->first();
            if($Profile){
                if($CustomerID = $Profile->StripeCustomerID){
                
                    $customer = \Stripe\Customer::retrieve($CustomerID);
                    $subscription = $customer->cancelSubscription();
                
                    $transaction = new UserProfileTransaction();
                    $transaction->LBRUserProfiles_ID = $Profile->ID;
                    $transaction->StripeReply = $subscription;
                    $transaction->save();
                
                }
            }
        
        
        }
        catch(Exception $e){
            return redirect()->to('/subscription/');
        }
    
        return redirect()->to('/subscription/updateSuccessful');
    }

}
<?php
namespace App\Http\Controllers\www;


use Grav\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Redirect;


class ErrorController extends Controller
{
    /**
     * this is used for having custom 404 page with custom 404 URL
     *
     */
    public function notFound()
    {
        abort(404);
    }
}
<?php
namespace App\Http\Controllers\www;

use App\Http\Forms\Definitions\LBR\UserProfileFormDefinition;
use App\Http\Forms\Processors\ProfileFormProcessor;
use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;
use Illuminate\Http\Request;
use Grav\Http\Forms\Traits\FormBuilder;
use Redirect;

use App\Helpers\SubscriptionHelper;

use App\Models\USR\User;
use App\Models\PPL\Person;
use App\Models\LBR\UserProfile;



class BrandingController extends Controller
{

    use FormBuilder;

    protected $elementsDefinition;

    public function __construct()
    {
        # check if user's subscription is "active" or "expired", if expired redirect to it's page.
        # redirect() didn't work here so we used php redirection

        if(SubscriptionHelper::CheckStatus()=="expired"){
            header("location:/subscription/expired");
            exit();
        }

        $this->elementsDefinition = new UserProfileFormDefinition();
    }

    /**
     * A page controller which responds to /branding/ url
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $page_heading = "User Homepage";
        $html = "Welcome home";
        return view('home',compact('html','page_heading'));
    }

    /**
     * A method to display profile edit page. Once a user submit the form it will be sent to /branding/updateProfile page, calling updateProfile() method
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editProfile()
    {
        $page_heading = "Edit Profile";
        $html = "Welcome home";
        $user = \Auth::guard('web')->user();  // get logged in User account, (USRUsers)
        $person = Person::query()->where('ID',"=",$user->PPLPeople_ID)->first();
        $userProfile = UserProfile::query()->where('USRUsers_ID',"=",$user->ID)->first();  // by using USRUsers_ID get UserProfile


        ## this will be triggered if the user doesn't have any profile yet, then we create a new empty profile
        if(is_null($userProfile)){
            $userProfile = $this->createProfile($user);
        }

        $form = $this->buildForm($this->elementsDefinition);
        $form->setRecordId($userProfile->ID);
        $form->populate();

        $form->addOptions(['method'=>'POST']);
        $form->addOptions(['url'=>'branding/updateProfile']);

        return view('www.brandingEdit',['form'=>$form,'page_heading'=>$page_heading, 'UserProfileID'=>$userProfile->ID, 'UserEmail'=>$person->PrimaryEmail, 'ProfileImageExt'=>pathinfo($userProfile->ProfileImage, PATHINFO_EXTENSION),
            'SplashBackgroundImageExt'=>pathinfo($userProfile->SplashBackgroundImage, PATHINFO_EXTENSION), 'UserImageOrientation'=>$userProfile->ImageOrientation, 'UserImageType'=>$userProfile->ImageType,
                                        'LastModified'=>$userProfile->LastModified]);
    }

    /**
     * A method which handles profile edit form update process. If there is any file uploaded it will be also saved.
     * After finishing the process the user will be redirected to /share-link/listing page
     *
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateProfile(Request $request)
    {

        $page_heading = "LinkBrandr";
        $UserID = \Auth::guard('web')->user(); // get logged in User account, (USRUsers)
        $user = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();  // by using USRUsers_ID get UserProfile

        $form = $this->buildForm($this->elementsDefinition);
        $form->setRecordId($user->ID);

        ## if background image file uploaded store this file
        if($request->file('SplashBackgroundImage') && $request->file('SplashBackgroundImage')->getClientOriginalName()){
            $request->file('SplashBackgroundImage')->storeAs('profile-backgrounds/', $user->ID.".".pathinfo($request->file('SplashBackgroundImage')->getClientOriginalName(), PATHINFO_EXTENSION), ['disk'=>'wwwpublic']);
            $bgFilename = $request->file('SplashBackgroundImage')->getClientOriginalName();
        }

        ## if profile image file uploaded store this file
        if($request->file('ProfileImage') && $request->file('ProfileImage')->getClientOriginalName()){
            $request->file('ProfileImage')->storeAs('profile-images/', $user->ID.".".pathinfo($request->file('ProfileImage')->getClientOriginalName(), PATHINFO_EXTENSION), ['disk'=>'wwwpublic']);
            $profileFilename = $request->file('ProfileImage')->getClientOriginalName();
        }
        ## these files are stored in www/public/uploads/profile-backgrounds/ and www/public/uploads/profile-images/ folders. File names will use UserProfile.ID

        ## if the user provided ProfileURL check if it has "http" or "https" in front. If not we add "http://" then store in db.
        if($request->has('ProfileURL') && strlen($request->offsetGet('ProfileURL'))>0){
            $link = $request->offsetGet('ProfileURL');

            if(strpos($link,'http://')!==0 && strpos($link,'https://')!==0)
            {
                $request->offsetSet('ProfileURL', "http://".$link);
            }

        }
        $form->populate($request);

        $form->validate();
        // $form->getValidationRules();

        $id = $form->process(); // this $id is not used anywhere

        ## if files uploaded update related field in LBRUserProfiles table
        if(isset($bgFilename)||isset($profileFilename)){
            if(isset($bgFilename)){
                $user->SplashBackgroundImage = $bgFilename;
            }
            if(isset($profileFilename)){
                $user->ProfileImage = $profileFilename;
            }

            $user->update();  // update user profile record
        }

        if (isset($_POST['update-profile-image']) || isset($_POST['save-changes'])) {
            return redirect()->back();
        } else if (isset($_POST['see-preview'])){
            return redirect()->to('/link/splash-preview');
        }

        return redirect()->to('/share-link/listing');

    }

    /**
     * This method is used to create an empty profile, if the user doesn't have one yet
     *
     * @param $user
     * @return UserProfile
     *
     */
    private function createProfile($user)
    {
        $Profile = new UserProfile();
        $Profile->IsPaidSubscription = 0;
        $Profile->LBRColorSchemes_ID = 1;
        $Profile->ImageType = 'Headshot';
        $Profile->AccountExpiryDate = date("Y-m-d H:i:s",strtotime("+15 days"));    // we used +15 days because if it was +14 the UI was showing "13 days left", probably because of counting hours
        // down
        $Profile->USRUsers_ID = $user->ID;
        $Profile->save();

        return $Profile;
    }

    /**
     * Deletes user's ProfileImage
     */
    public function deleteProfileImage()
    {
        if(\Auth::guard('web')->check())
        {
            $UserID = \Auth::guard('web')->user();
            $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();

            if($UserProfile->ProfileImage != NULL){
                $UserProfile->ProfileImage = NULL;
            }

            $UserProfile->update();

        }

        return redirect()->back();
    }

    /**
     * Deletes user's SplashBackgroundImage
     */
    public function deleteBackgroundImage()
    {
        if(\Auth::guard('web')->check())
        {
            $UserID = \Auth::guard('web')->user();
            $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();

            if($UserProfile->SplashBackgroundImage != NULL){
                $UserProfile->SplashBackgroundImage = NULL;
            }

            $UserProfile->update();

        }

        return redirect()->back();
    }
}
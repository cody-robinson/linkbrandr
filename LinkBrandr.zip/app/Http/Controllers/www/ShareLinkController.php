<?php
namespace App\Http\Controllers\www;

use App\Http\Forms\Definitions\LBR\ShareLinkFormDefinition;
use App\Http\Forms\Processors\ProfileFormProcessor;
use App\Models\USR\User;
use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;
use Illuminate\Http\Request;
use Grav\Http\Forms\Traits\FormBuilder;
use Illuminate\Support\Facades\Redirect;
use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

use App\Helpers\SubscriptionHelper;
use Illuminate\Support\Facades\Auth;

use App\Models\LBR\UserProfile;
use App\Models\LBR\SharedLink;
use App\Models\LBR\IframeTemplate;
use App\Models\LBR\SplashTemplate;
use App\Models\LBR\ColorScheme;


class ShareLinkController extends Controller
{

    use FormBuilder;

    protected $elementsDefinition;
    protected $metas;
    protected $favicon;
    protected $description;

    public function __construct()
    {
        ## checking if Userprofile's subscription is "expired" or "active". If expired redirect to related page.
        ## redirect() didn't work in here, thats why we used php header redirection

        if(SubscriptionHelper::CheckStatus()=="expired"){
            header("location:/subscription/expired");
            exit();
        }
    }

    /**
     * this is for default /share-link page. Since the main page for share-link can be considered as listing
     * we can just call same method called for /share-link/listing in case url is just /share-link. This can prevent
     * an error caused by simply not providing the method name
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        return $this->listing($request);
    }

    /**
     * Display a add a new link form. Once the form is submitted it will send form data to /share-link/storeLink, calling storeLink() method
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function createLink(Request $request)
    {
        $User = \Auth::guard('web')->user();
        $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->first();

        ## If no user profile exist, redirec to edit profile page so the profile will get created and user can fill in profile details.
        ## this is to prevent someone without profile info creating a link and share

        if(is_null($UserProfile)){
            return redirect()->to('/branding/edit-profile');
        }

        $this->elementsDefinition = new ShareLinkFormDefinition();
        $page_heading = "New Link";

        $form = $this->buildForm($this->elementsDefinition);
        $form->addOptions(['method'=>'POST']);  ## here we are tempering form attributes, setting method post and setting <form action="" value
        $form->addOptions(['url'=>'share-link/storeLink']);

        return view('www.ShareLinks.addShareLink',['form'=>$form,'page_heading'=>$page_heading, 'userID'=>$UserProfile->ID]);
    }

    /**
     * Handle create a new link form. Get URL, check the given website, read it's meta title and description values (open graph og: values). Also in this method
     * we check if the given website prevents usage in Iframe or not.
     *
     * @param Request $request
     * @return mixed
     */
    public function storeLink(Request $request)
    {
        $this->elementsDefinition = new ShareLinkFormDefinition();

        $form = $this->buildForm($this->elementsDefinition);
        if($request->isMethod('POST') && $request->has('Link'))
        {
            $form->populate($request);

            $AmpUrl = $request->get('AmpUrl'); // get posted amp url value
            $OriginalUrl = $request->get('Link'); // get posted link value

            // set target url based on whether there was an amp url or not
            if($AmpUrl){
                $TargetURL = $AmpUrl;
            } else {
                $TargetURL = $OriginalUrl;
            }

            # if there is no http or https in front of the url
            if(strpos($TargetURL,"http://")===false && strpos($TargetURL,"https://")===false){
                $TargetURL = "http://".$TargetURL;
                $form['Link']->setValue($TargetURL);
            }

            ## if Iframe usage is prevented then use splash page
            if($this->isXFrameBlocked($TargetURL)){
                $form['ShareType']->setValue('splash');
                $form['IsIframeSupported']->setValue(0);
            }
            else{
                ## if iframe usage is not prevented then default to brandr bar (iframe)
                $form['ShareType']->setValue('iframe');
                $form['IsIframeSupported']->setValue(1);
            }

            ## send website content from crawler, and retrieve Open Graph description and title values.
            $MetaCrawlerContent = $this->grabOG($TargetURL);

            $description = isset($MetaCrawlerContent['description']) ? $MetaCrawlerContent['description'] : '';
            $form['Description']->setValue($description);
    
            $title = isset($MetaCrawlerContent['title']) ? $MetaCrawlerContent['title'] : '';
            $form['Title']->setValue($title);

            $image = isset($MetaCrawlerContent['image']) ? $MetaCrawlerContent['image'] : '';

            // if there was no image tag on the amp url, check original url
            if(!$image){
                $OriginalLinkMetaTags = $this->getOriginalLinkMetaTags($OriginalUrl);
                if($OriginalLinkMetaTags['image']){
                    $image = $OriginalLinkMetaTags['image'];
                }
            }

            $form['Image']->setValue($image);

            $favicon = isset($MetaCrawlerContent['favicon']) ? $MetaCrawlerContent['favicon'] : '';
            $form['Favicon']->setValue($favicon);
    
            $form['Slug']->setValue(str_random(8)); // generate a random string to use as slug

            // make sure link is set as correct target - amp or not
            $form['Link']->setValue($TargetURL);
            $id = $form->process();
        }
        return \Redirect::back();
    }

    /**
     * Soft deletes a link previously shared
     *
     * @param Request $request
     * @param $ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteLink(Request $request, $ID)
    {
        if(\Auth::guard('web')->check())
        {
            $UserID = \Auth::guard('web')->user();
            $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();

            $SharedLink = SharedLink::find($ID);
            if($SharedLink->LBRUserProfiles_ID == $UserProfile->ID){
                $SharedLink->update(['IsActive'=>'0']);
            }
            return redirect()->back();
        }
    }


    /**
     * Displays all previously shared active links by the current user.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function listing(Request $request)
    {
        $page_heading = "Client Dashboard";

        // if user is logged in
        if($UserID = \Auth::guard('web')->user()){
            $user = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();        // get current user's Userprofile

            ## if User doesn't have Userprofile yet, redirect to edit profile page and eventually create a user profile (occurs in that page)
            if(is_null($user)){
                return redirect()->to('/branding/edit-profile');
            }

            $SharedLinkReporter = \App::make('App\AL\Services\SharedLinks\LinksReporter');  // instantiate shared link reporter to use
            $ProfileReporter = \App::make('App\AL\Services\Profile\ProfileReporter');   // instantiate profile reporter to use
            $ProfileInfo = $ProfileReporter->getProfileInfoFromID($user->ID);       // get profile info from profile reporter while searching based on LBRUserprofile.ID

            ### set value to display in "You have ... days remaining in your free trial"
            $DaysToExpire = null;
            $StripeCustomer = false;
            $ExpiryDate = $ProfileInfo->UserProfile->AccountExpiryDate;
            $IsPaidAccount = $ProfileInfo->UserProfile->IsPaidSubscription;
            if($ProfileInfo->UserProfile->StripeCustomerID){
                $StripeCustomer = true;
            }

            if($ExpiryDate > date('Y-m-d H:i:s'))
            {
                $DaysDifference = date_diff(date_create($ExpiryDate), date_create(date('Y-m-d H:i:s')));
                $DaysToExpire = $DaysDifference->format('%a');
                if($DaysToExpire > 30){
                    $DaysToExpire = null;
                }
            } else {
                return redirect()->to('/subscription/expired');
            }

            ## use share link reporter , search links based on current user's Userprofile ID
            $SearchParameter = ['LBRUserProfiles_ID'=>$user->ID];
            $SharedLinksInfo = $SharedLinkReporter->getSharedLinksInfo($SearchParameter);

            $this->elementsDefinition = new ShareLinkFormDefinition();

            $form = $this->buildForm($this->elementsDefinition);
            $form->addOptions(['method'=>'POST']);
            $form->addOptions(['url'=>'share-link/storeLink']);

            $shortUrl = '';
            if(app()->InProduction() == true){
                $shortUrl = 'lbdr.co';
            }

            return view('www.ShareLinks.LinksReporterView',['form'=>$form,'sharedLinks'=>$SharedLinksInfo,'page_heading'=>$page_heading, 'userID'=>$user->ID, 'isPaidAccount'=>$IsPaidAccount, 'isStripeCustomer'=>$StripeCustomer, 'daysToExpire'=>$DaysToExpire, 'shortUrl'=>$shortUrl]);
        } else {
            return redirect('/login');
        }

    }
    
    /**
     * Ajax handler to update share type (iframe|splash\both)
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function shareTypeUpdate(Request $request)
    {
        ## check if user is authenticated
        if(\Auth::guard('web')->check()){

            if($request->has(['ShareType','ID']) && ($request->get('ShareType')=="iframe" || $request->get('ShareType')=="splash" || $request->get('ShareType')=="both"))
            {
                    $UserID = \Auth::guard('web')->user();
                    $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();

                    $SharedLink = SharedLink::find($request->get('ID'));
                    ## in case if user try to set iframe for link which doesn't support iframe , just return false and fail
                    if($SharedLink->IsIframeSupported == 0 && $request->get('ShareType')=="iframe" || $SharedLink->IsIframeSupported == 0 &&$request->get('ShareType')=="both"){
                        return response()->json(['result'=>false]);
                    }
                    ## found the shared link, but lets check if the current user was the author, if yes then we can update
                    if($SharedLink->LBRUserProfiles_ID == $UserProfile->ID){
                        $SharedLink->update(['ShareType'=>$request->get('ShareType')]);
                    }

                return response()->json(["result"=>true]);
            }
        }
    }

    /**
     * Ajax handler to update shared link's slug
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function shareSlugUpdate(Request $request){

        if(\Auth::guard('web')->check()){

            if($request->has(['Slug','ID'])){
                $UserID = \Auth::guard('web')->user();
                $UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$UserID->ID)->first();

                $SharedLink = SharedLink::find($request->get('ID'));
                ## found the shared link, but lets check if the current user was the author, if yes then we can update
                if($SharedLink->LBRUserProfiles_ID == $UserProfile->ID){
                    $SharedLink->update(['Slug'=>$request->get('Slug')]);
                }
                return response()->json(["result"=>true]);
            }
        }
    }

    /**
     * Ajax handler to validate given slug, returns true if this slug does not already exists. false otherwise
     * Usage: this is used in share-link/listing page when we update the slug. There is an ajax call runs after each character entered into text box
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function validateSlug(Request $request)
    {

        if(\Auth::guard('web')->check() && $request->has('slug')){

            $SharedLinkReporter = \App::make('App\AL\Services\SharedLinks\LinksReporter');
            $SearchParameter = ['Slug'=>$request->get('slug')];
            $SharedLinksInfo = $SharedLinkReporter->getSharedLinksInfo($SearchParameter);

            if(count($SharedLinksInfo) == 0) {
                return response()->json(["result"=>true]);
            }
            else{
                return response()->json(["result"=>false]);
            }
        }
    }


    /**
     * A method which utilizes goutte component to search Open Graph title and description meta tags withing page content
     *
     * @param $crawler
     * @return null
     */
    private function grabOG($a_TargetURL)
    {

        ## here we use Goutte component to crawl the given site's content and header information
        $client = new Client();
        $client->setServerParameter('HTTP_USER_AGENT','Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0'); // set request's client agent
        $crawler = $client->request('GET', $a_TargetURL); // send the request, get response into $crawler

        $this->metas = null;
        $this->favicon = null;
        $this->description = null;

        $crawler->filterXPath('//meta[contains(@property, "og:")]')->each(function (Crawler $node, $metas) {
            $this->metas[$node->evaluate('substring-after(@property, "og:")')[0]] = $node->attr('content');
        });

        $crawler->filterXPath('//link[contains(@rel, "icon")]')->each(function (Crawler $node,$favicon) {
            $this->favicon = [$node->evaluate('substring-after(@href, "")')[0]];
        });

        // if favicon is a root path, add target url to beginning of favicon path
        if (substr($this->favicon[0], 0, 1) === '/'){

            $newUrl = $a_TargetURL;
            $newUrl .=$this->favicon[0];

            $this->favicon[0] = $newUrl;
        }

        $MetaData = array();
        $MetaData['description'] = isset($this->metas['description']) ? $this->metas['description'] : '';
        $MetaData['title'] = isset($this->metas['title']) ? $this->metas['title'] : '';
        $MetaData['image'] = isset($this->metas['image']) ? $this->metas['image'] : '';
        $MetaData['favicon'] = isset($this->favicon[0]) ? $this->favicon[0] : '';

        if(!$MetaData['title']){
            $title = "";
            if($titleElement = $crawler->filter('head > title')->first())
            {
                try{
                    $title = $titleElement->text();
                } catch (\InvalidArgumentException $e) {
                    $title = 'Title not accessible';
                }

            }
            $MetaData['title'] = $title;
        }

        if(!$MetaData['description']){
            $crawler->filterXPath('//meta[contains(@name, "description")]')->each(function (Crawler $node, $description) {
                $this->description = [$node->evaluate('substring-after(@content, "")')[0]];
            });

            if($this->description[0]){
                $MetaData['description'] = $this->description[0];
            }
        }
        
        return $MetaData;
    }

    /**
     * A method which utilizes goutte component to search Open Graph image
     *
     * @param $a_OriginalURL the original link that was entered by the user
     * @return null
     */
    private function getOriginalLinkMetaTags($a_OriginalURL)
    {
        ## here we use Goutte component to crawl the given site's content and header information
        $client = new Client();
        $client->setServerParameter('HTTP_USER_AGENT','Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0'); // set request's client agent
        $crawler = $client->request('GET', $a_OriginalURL); // send the request, get response into $crawler

        $this->metas = null;

        $crawler->filterXPath('//meta[contains(@property, "og:")]')->each(function (Crawler $node, $metas) {
            $this->metas[$node->evaluate('substring-after(@property, "og:")')[0]] = $node->attr('content');
        });

        $MetaData = array();
        $MetaData['image'] = isset($this->metas['image']) ? $this->metas['image'] : '';

        return $MetaData;
    }

    /**
     * This method receives an array containing header keys and values. Then checks if the iframe preventing header is set or not.
     *
     * @param $headers
     * @return bool
     */
    private function isXFrameBlocked($a_TargetURL)
    {

        //Amazon does some weird stuff where it redirects to a "sorry contact us for API access" page
        //Global News doesn't behave at all on mobile
        if(strpos(strtolower($a_TargetURL),'amazon.ca') != 0 || strpos(strtolower($a_TargetURL),'amazon.com') != 0 || strpos(strtolower($a_TargetURL),'ctvnews.ca') != 0 ){
            return true;
        }

        ## here we use Goutte component to crawl the given site's content and header information
        $client = new Client();
        $client->setServerParameter('HTTP_USER_AGENT','Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0'); // set request's client agent
        $crawler = $client->request('GET', $a_TargetURL); // send the request, get response into $crawler

        $headers = $client->getResponse()->getHeaders();

        foreach($headers as $key=>$value){
            if(strtolower($key)==strtolower('X-Frame-Options')){
                return true;
            }
            if (strtolower($key)==strtolower('Content-Security-Policy')){
               foreach($value as $item){
                   // check Content Security Policy for frame-ancestors self
                   if(strpos($item, "frame-ancestors 'self'") !== false){
                       return true;
                   }
               }
            }
        }

        return false;
    }
}
<?php

namespace App\Http\Controllers\www;

use Grav\Http\Controllers\Controller;
use Socialite;
use Grav\Http\Controllers\Auth\PublicAuthorization;
use Grav\Models\USR\User;
use Grav\Models\PPL\Person;
use App\Models\LBR\UserProfile;
use Illuminate\Support\Facades\Auth;
use Redirect;

class SocialLoginController extends Controller
{
    use PublicAuthorization;


    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
        Socialite::driver('facebook')->redirectUrl(url('/login/facebook/callback'));
    }

    /**
     * Redirect the user to the Facebook authentication page.
     *
     * @return Response
     */
    public function redirectToProvider()
    {
        return Socialite::driver('facebook')->fields([
            'id', 'name', 'first_name', 'last_name', 'email', 'birthday'
        ])->scopes([
            'user_birthday', 'user_location'
        ])->redirect();
    }


    /**
     * Obtain the user information from Facebook, create a PPLPeople and USRUsers records, then log the user in and redirect.
     *
     * @return Response
     */
    public function handleProviderCallback($account=null)
    {

        try {

            $facebookUser = Socialite::driver('facebook')->fields([
                'id', 'name', 'first_name', 'last_name', 'email', 'birthday', 'location', 'gender'
            ])->user();


            if(User::where('Username', '=', $facebookUser->id)->where('IsActive','=',1)->first()) {
                $checkUser = User::where('Username', '=', $facebookUser->id)->where('IsActive','=',1)->first();
                Auth::guard('web')->login($checkUser);

                return redirect()->to('/share-link/listing');
            }

            else{
                return $this->createAccount($facebookUser);
            }

        } catch (\Exception $e) {

            //if a user denies access to requested permissions
            return redirect()->to('/login');
        }

    }
    
    public function createAccount($facebookUser){
        $nameList = explode(" ",$facebookUser->name,2);
        $firstName = $nameList[0];
        $lastName = $nameList[1];
    
        $person = new Person();
        $person->FirstName = $firstName;
        $person->LastName = $lastName;
        $person->PrimaryEmail = $facebookUser->email;
        $person->save();
    
        $row = new User;
        $row->Username = $facebookUser->id;
        $row->PPLPeople_ID = $person->ID;
        $row->save();
    
        $profile = new UserProfile();
        $profile->IsPaidSubscription = 0;
        $profile->LBRColorSchemes_ID = 1;
        $profile->ImageType = 'Headshot';
        $profile->AccountExpiryDate = date("Y-m-d H:i:s",strtotime("+15 days"));    // we used +15 days because if it was +14 the UI was showing "13 days left", probably because of counting hours
        // down
        $profile->USRUsers_ID = $row->ID;
        if(isset($facebookUser->user['birthday'])) {
            $profile->Birthday = $facebookUser->user['birthday'];
        }
        if(isset($facebookUser->user['location']['name'])) {
            $profile->Location = $facebookUser->user['location']['name'];
        }
        if(isset($facebookUser->user['gender'])) {
            $profile->Gender = $facebookUser->user['gender'];
        }
        $profile->save();
    
        Auth::guard('web')->login($row);
        return redirect()->to('/home/checkExistingAccount');
    }

    public function index()
    {

    }
}
<?php
namespace App\Http\Controllers\www\FileStreamer;

use Grav\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;





class FileStreamController extends Controller
{
    /**
     * @Get("view/{file}", as="files.view")
     */
    public function view(File $file)
    {
        $response = new BinaryFileResponse($file->getAbsolutePath());
        $response->headers->set('Content-Disposition', 'inline; filename="' . $file->real_filename . '"');
        return $response;
    }

}
<?php
namespace App\Http\Controllers\www;

use Illuminate\Http\Request;
use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;

class ReporterController extends Controller
{
    public function __construct()
    {

    }

    /**
     * Based on LBRColorSchemes.ID received it returns LBRColorSchemes record
     *
     * @param Request $request
     * @param $data
     * @return Array App\AL\ServiceDTOs\ColorSchemes\ColorSchemeInfo
     */
    public function colorSchemes(Request $request, $data)
    {
        $ColorSchemeReporter = \App::make('App\AL\Services\ColorSchemes\ColorSchemeReporter');
        $ColorSchemeInfo = $ColorSchemeReporter->getColorSchemeInfo(['ID'=>$data]);

        return $ColorSchemeInfo;
    }

    /**
     * Based on LBRIframeTemplates.ID provided it returns IframeTemplateInfo record
     *
     *
     * @param Request $request
     * @param $data
     * @return Array App\AL\ServiceDTOs\IframeTemplates\IframeTemplateInfo
     */
    public function iframeTemplates(Request $request, $data)
    {
        $IframeTemplateReporter = \App::make('App\AL\Services\IframeTemplates\IframeTemplateReporter');
        $IframeTemplateInfo = $IframeTemplateReporter->getIframeTemplateInfo(['ID'=>$data]);

        return $IframeTemplateInfo;

    }
}
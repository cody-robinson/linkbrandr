<?php
namespace App\Http\Controllers\www;

use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;

class PublicController extends Controller
{
    
    public function index()
    {
        return view('home',compact('html','page_heading'));
    }

    public function showPublicIndex()
    {
        return view('www.publicIndex');
    }

    public function displayPrivacyPolicies()
    {
        return view('www.privacyPolicies');
    }

    public function displayContactForm()
    {
        return view('www.contact');
    }
    
    public function displayTerms()
    {
        return view('www.terms');
    }
    
}
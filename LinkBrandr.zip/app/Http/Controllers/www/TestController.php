<?php

namespace App\Http\Controllers\www;

use Grav\Http\Controllers\Controller;
use Grav\Http\Controllers\Auth\PublicAuthorization;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

class TestController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public $metas =[];


    public function userList()
    {
        $html = '';

        foreach(\Grav\Models\USR\User::all()->take(5) as $User) {
            $Person = $User->PPLPerson;
            $html .= "<strong>Username : $User->Username</strong><br>";
            $html .= "$Person->FirstName $Person->LastName<br><hr>";
        }

        $page_heading = "User List";
        return view('home', compact('html','page_heading'));
    }


    public function frameTest()
    {

        $client = new Client();
        $crawler = $client->request('GET', 'https://www.facebook.com');
        dump($client->getResponse()->getHeaders());
        dump($crawler);
    }

    public function grabOG($request)
    {
        phpinfo();
        dd();
        $target = $request->input('target');

        $client = new Client();
        $client->setServerParameter('HTTP_USER_AGENT','Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0');

        $client->followRedirects(true);
        $crawler = $client->request('GET', 'http://'.$target);

        $headers = $client->getResponse()->getHeaders();

        $crawler->filterXPath('//meta[contains(@property, "og:")]')->each(function (Crawler $node,$metas) {
            $this->metas[$node->evaluate('substring-after(@property, "og:")')[0]] = $node->attr('content');

        });
        dump($this->metas);

        dump($this->isXFrameBlocked($headers));
    }

    private function isXFrameBlocked($headers)
    {
        if(array_key_exists('X-Frame-Options', $headers)){
            if(array_search("DENY",$headers['X-Frame-Options'])!==false) {
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }

}



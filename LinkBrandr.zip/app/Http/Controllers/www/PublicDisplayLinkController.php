<?php
namespace App\Http\Controllers\www;


use App\Models\USR\User;
use Grav\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Mockery\Exception;
use Redirect;

use App\Helpers\SubscriptionHelper;
use Illuminate\Support\Facades\Auth;

use App\Models\LBR\IframeTemplate;
use App\Models\LBR\SplashTemplate;
use App\Models\LBR\ColorScheme;
use App\Models\LBR\UserProfile;


/**
 * This controller can be accessed publicly.
 *
 * Class PublicDisplayLinkController
 * @package App\Http\Controllers\www
 *
 */
class PublicDisplayLinkController extends Controller
{

    /**
     * Display shared link content to any public (not authenticated) user.
     *
     * @param Request $request
     * @param $slug
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function displayLink(Request $request, $slug)
    {

        ## show splash page preview - this is used when the See Preview button is clicked on the edit profile screen
        if ($slug == 'splash-preview'){

            $User = \Auth::guard('web')->user();
            $Profile = UserProfile::query()->where('USRUsers_ID','=',$User->ID)->first();

            $ProfileReporter = \App::make('App\AL\Services\Profile\ProfileReporter');   // instantiate profile reporter to use
            $ProfileInfo = $ProfileReporter->getProfileInfoFromID($Profile->ID);

            $splashParams = ['sharedLink'=>'', 'slug' => 'splash-preview', 'page_heading'=>'', 'user' => $Profile, 'ButtonColor'=>$ProfileInfo->ButtonColor, 'BackgroundColor'=>$ProfileInfo->BackgroundColor,
                             'title'=>$ProfileInfo->Title, 'description'=>$ProfileInfo->Description, 'image'=>$ProfileInfo->Image, 'favicon'=>''];

            return view('www.ShareLinks.PublicSharedLinkSplashView', $splashParams);
        }

        $page_heading = "Client Dashboard";

        ## if we hit here we know this user is not authenticated, and the owner of this link is subscribed active user

        $ProfileReporter = \App::make('App\AL\Services\Profile\ProfileReporter');  // here initializing reporter to use
        $ProfileInfo = $ProfileReporter->getProfileInfoFromSlug($slug);     // get Userprofile info based on the Slug provided, so we can still get this profiles brand information

        $link = $ProfileInfo->ShareLink;
        $user = $ProfileInfo->UserProfile;

        if($ActiveUser = User::query()->where('ID',"=",$user->USRUsers_ID)->first()){
            if($ActiveUser->IsActive == 0){
                abort(404);
            }
        }

        $title = $ProfileInfo->Title;
        $description = $ProfileInfo->Description;
        $image = $ProfileInfo->Image;
        $favicon = $ProfileInfo->Favicon;

        $CSSClassName = $ProfileInfo->CSSClassName;
        $ButtonColor = $ProfileInfo->ButtonColor;
        $BackgroundColor = $ProfileInfo->BackgroundColor;


        $iframeParams = ['sharedLink' => $link, 'slug' => $slug, 'page_heading' => $page_heading, 'userID' => $user->ID, 'user' => $user,
                         'CSSClassName'=>$CSSClassName, 'ButtonColor'=>$ButtonColor, 'BackgroundColor'=>$BackgroundColor,'title'=>$title, 'description'=>$description, 'image'=>$image, 'favicon'=>$favicon];
        $splashParams = ['sharedLink'=>$link, 'slug' => $slug, 'page_heading'=>$page_heading, 'user' => $user, 'ButtonColor'=>$ButtonColor, 'BackgroundColor'=>$BackgroundColor,
                         'title'=>$title, 'description'=>$description, 'image'=>$image, 'favicon'=>$favicon];

        if($ProfileInfo->IsIframeSupported) {
            ## if iframe is supported and share type is iframe, show brandr bar
            if($ProfileInfo->ShareType == "iframe") {
                return view('www.ShareLinks.PublicSharedLinkIframeView', $iframeParams);
            }
            ## if iframe is supported and share type is both, check for redirect parameter. show splash page if not set or redirect to brandr bar if set.
            else if($ProfileInfo->ShareType == "both") {

                $redirect = $request->input('showBrandr');
                if($redirect == 'true'){
                    return view('www.ShareLinks.PublicSharedLinkIframeView', $iframeParams);
                } else {
                    ## add redirectToBrandr param
                    return view('www.ShareLinks.PublicSharedLinkSplashView', ['sharedLink' => $link, 'slug' => $slug, 'page_heading' => $page_heading, 'userID' => $user->ID, 'user' => $user, 'CSSClassName'=>$CSSClassName, 'ButtonColor'=>$ButtonColor, 'BackgroundColor'=>$BackgroundColor,'title'=>$title, 'description'=>$description, 'image'=>$image, 'favicon'=>$favicon, 'redirectToBrandr'=>'true']);
                }

            }
            ## if share type is not iframe or both, show splash page
            else{
                return view('www.ShareLinks.PublicSharedLinkSplashView', $splashParams);
            }
        }
        ## iframe not supported, show splash page
        else{
            return view('www.ShareLinks.PublicSharedLinkSplashView', $splashParams);
        }


    }
}
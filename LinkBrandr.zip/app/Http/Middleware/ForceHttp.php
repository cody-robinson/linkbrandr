<?php

namespace App\Http\Middleware;

use Closure;

class ForceHttp
{
    /**
     * This middleware forces http on request
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!$request->secure()) {

            return $next($request);

        } else {

            $host = $request->server->get('HTTP_HOST');
            $requestUri = $request->server->get('REQUEST_URI');

            return redirect('http://'.$host.$requestUri);
        }
    }
}

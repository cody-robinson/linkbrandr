<?php

namespace App\Helpers;

use App\Http\Controllers\www\SubscriptionController;
use App\Models\LBR\UserProfile;
use Illuminate\Support\Facades\Auth;

use App\Models\LBR\SharedLink;

class SubscriptionHelper
{
    protected $Status; // active or expired
    protected $ExpiryDate;
    protected $IsPaid;


    private function SetParamsFromUser()
    {
        ## checking for current user
        if(Auth::guard('web')->user() && Auth::guard('web')->check()){
            $User = Auth::guard('web')->user();
            if($UserProfile = UserProfile::query()->where('USRUsers_ID',"=",$User->ID)->first())
            {
                $this->IsPaid = $UserProfile->IsPaidSubscription;
                $this->ExpiryDate = $UserProfile->AccountExpiryDate;

                if(strtotime($this->ExpiryDate) < time())
                {
                    $this->Status = "expired";
                }
                else{
                    $this->Status = "active";
                }
            }
        }
    }

    public static function CheckStatus()
    {

        $obj = new SubscriptionHelper();
        $obj->SetParamsFromUser();
        return $obj->Status;
    }

    public static function CheckStatusWithSlug($slug)
    {
        $obj = new SubscriptionHelper();

        if($SharedLink = SharedLink::query()->where("Slug","=",$slug)->first()){
            $Profile = $SharedLink->LBRUserProfile;
            $obj->IsPaid = $Profile->IsPaidSubscription;
            $obj->ExpiryDate = $Profile->AccountExpiryDate;

            if(strtotime($obj->ExpiryDate) < time())
            {
                $obj->Status = "expired";
            }
            else{
                $obj->Status = "active";
            }
            return $obj->Status;
        }

    }
}
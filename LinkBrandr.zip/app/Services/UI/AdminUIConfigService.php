<?php namespace App\Services\UI;

use Grav\UI\AdminUIService;
use Grav\UI\Contracts\IAdminUIConfigService;
use Grav\UI\InterfaceElements\Item;
use Grav\UI\Helpers\IconClass;

class AdminUIConfigService implements IAdminUIConfigService
{

    
    function configure(AdminUIService $service)
    {
        $service->setPageTitle('LinkBrandr');
        $service->navbar()->setTitle('LinkBrandr');
        $service->setClientLogo('/images/link-brandr-logo.png');

        $service->sidebar()->add('Home', '/')
            ->setIconAttributes(['class' => IconClass::Home]);

        $service->sidebar()->add('Setup')->with(
            function (Item $item) {
                $item->add('User Management', '/users/');
            }
        )
            ->setIconAttributes(['class' => IconClass::Users]);

    
        $service->navbar()->add('Admin User')->with(
            function (Item $item) {

                $item->add('Change Password')
                     ->setAnchorAttributes(['href' => '/password/change']);

                $item->add('Full Screen')
                     ->setAnchorAttributes(['onclick' => 'EnableFullScreen()']);

                $item->add('Log Out')
                     ->setAnchorAttributes(['href' => '/logout']);
            }
        );

    }
}

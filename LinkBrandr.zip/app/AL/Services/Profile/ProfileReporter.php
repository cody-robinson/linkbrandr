<?php

namespace App\AL\Services\Profile;

use App\AL\ServiceDTOs\Profile\ProfileInfo;

// model layer dependencies
use App\Models\LBR\SharedLink;
use App\Models\LBR\UserProfile;
use App\Models\LBR\IframeTemplate;
use App\Models\LBR\SplashTemplate;
use App\Models\LBR\ColorScheme;
use Mockery\Exception;

class ProfileReporter
{

    /**
     * Fetch Profile info based on given slug. It find's who shared this link and retrive the rest from that
     * Retrieve user profile info, shared link info, template and color info and return all of these as ProfileInfo
     *
     * @param $slug
     * @return ProfileInfo
     */
    public function getProfileInfoFromSlug($slug)
    {
        $ProfileInfo = new ProfileInfo();

        if($SharedLinkInfo = SharedLink::query()->where('Slug','=',$slug)->first())
        {

            $ProfileInfo->ShareType = $SharedLinkInfo->ShareType;
            $ProfileInfo->IsIframeSupported = $SharedLinkInfo->IsIframeSupported;
            $ProfileInfo->Slug = (isset($slug))? $slug: "";
            $ProfileInfo->ShareLink = $SharedLinkInfo->Link;
            $ProfileInfo->Title = $SharedLinkInfo->Title;
            $ProfileInfo->Description = $SharedLinkInfo->Description;
            $ProfileInfo->Image = $SharedLinkInfo->Image;
            $ProfileInfo->Favicon = $SharedLinkInfo->Favicon;

            if($UserProfile = UserProfile::find($SharedLinkInfo->LBRUserProfiles_ID)){
                $ProfileInfo->UserProfile = $UserProfile;

                if($SharedLinkInfo->ShareType == "iframe" || $SharedLinkInfo->ShareType == "both"){
                    $ProfileInfo->CSSClassName = ($ProfileInfo->IframeTemplate  = IframeTemplate::find($ProfileInfo->UserProfile->LBRIframeTemplates_ID))? $ProfileInfo->IframeTemplate->CSSClassName: null;
                }
                else{
                    $ProfileInfo->CSSClassName = ($ProfileInfo->SplashTemplate = SplashTemplate::find($UserProfile->LBRSplashTemplates_ID))? $ProfileInfo->SplashTemplate->CSSClassName: null;

                }

                if($Colors = json_decode(ColorScheme::find($UserProfile->LBRColorSchemes_ID)->Colors)){
                    $ProfileInfo->ButtonColor  = (isset($Colors[1]))? $Colors[1]: null;
                    $ProfileInfo->BackgroundColor = (isset($Colors[0]))? $Colors[0]: null;

                }
                else{
                    $ProfileInfo->ButtonColor = null;
                    $ProfileInfo->BackgroundColor = null;
                }
            }
            return $ProfileInfo;
        }
        else{
            header("location:/");
            exit();
        }


    }

    /**
     * Fetch Profile info based on LBRUserProfile_ID
     * Retrieve user profile info, shared link info, template and color info and return all of these as ProfileInfo
     *
     * @param $ID
     * @return ProfileInfo
     */
    public function getProfileInfoFromID($ID){
        $ProfileInfo = new ProfileInfo();

        if($UserProfile = UserProfile::find($ID)){
            $ProfileInfo->UserProfile = $UserProfile;

            $ProfileInfo->IframeTemplate  = ($BarTemplate = IframeTemplate::find($ProfileInfo->UserProfile->LBRIframeTemplates_ID))? $BarTemplate->CSSClassName: null;

            if($Colors = json_decode(ColorScheme::find($UserProfile->LBRColorSchemes_ID)->Colors)){
                $ProfileInfo->ButtonColor  = (isset($Colors[1]))? $Colors[1]: null;
                $ProfileInfo->BackgroundColor = (isset($Colors[0]))? $Colors[0]: null;

            }
            else{
                $ProfileInfo->ButtonColor = null;
                $ProfileInfo->BackgroundColor = null;
            }
            return $ProfileInfo;
        }
        else{
            header("location:/");
            exit();
        }

    }



}

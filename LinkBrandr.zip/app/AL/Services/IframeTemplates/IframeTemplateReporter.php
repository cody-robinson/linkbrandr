<?php

namespace App\AL\Services\IframeTemplates;

use App\AL\ServiceDTOs\IframeTemplates\IframeTemplateInfo;

// model layer dependencies
use App\Models\LBR\IframeTemplate;

class IframeTemplateReporter
{
    /**
     * Retrieve commonly required information about an employee.
     *
     * @param Array $parameters
     * @return Array App\AL\ServiceDTOs\IframeTemplates\IframeTemplateInfo
     */
    public function getIframeTemplateInfo($parameters)
    {

        $keys = array_keys($parameters);
        $matchingKeyList = array_intersect_key($parameters, get_class_vars(IframeTemplateInfo::class));

        if(count($matchingKeyList)==1)
        {
            $keyName = array_keys($matchingKeyList)[0];
            $IframeTemplates = IframeTemplate::where($keyName, '=', $matchingKeyList[$keyName])->get();
        }


        $info = [];
        foreach($IframeTemplates as $IframeTemplate)
        {

            $IframeTemplateInfo = new IframeTemplateInfo();
            $IframeTemplateInfo->ID = $IframeTemplate->ID;
            $IframeTemplateInfo->Name = $IframeTemplate->Name;
            $IframeTemplateInfo->CSSClassName = $IframeTemplate->CSSClassName;
            $info[] = $IframeTemplateInfo;
        }

        return $info;
    }



}

<?php

namespace App\AL\Services\ColorSchemes;

use App\AL\ServiceDTOs\ColorSchemes\ColorSchemeInfo;

// model layer dependencies
use App\Models\LBR\ColorScheme;

class ColorSchemeReporter
{
    /**
     * Retrieve commonly required information about a color scheme
     *
     * @param Array $parameters
     * @return Array App\AL\ServiceDTOs\ColorSchemes\ColorSchemeInfo
     */
    public function getColorSchemeInfo($parameters)
    {

        $keys = array_keys($parameters);

        $matchingKeyList = array_intersect_key($parameters, get_class_vars(ColorSchemeInfo::class));

        if(count($matchingKeyList)==1)
        {
            $keyName = array_keys($matchingKeyList)[0];
            $ColorSchemes = ColorScheme::where($keyName, '=', $matchingKeyList[$keyName])->get();
        }


        $info = [];
        foreach($ColorSchemes as $colorScheme)
        {

            $SchemeInfo = new ColorSchemeInfo();
            $SchemeInfo->ID = $colorScheme->ID;
            $SchemeInfo->SchemeName = $colorScheme->SchemeName;
            $SchemeInfo->Colors = $colorScheme->Colors;

            $info[] = $SchemeInfo;
        }

        return $info;
    }



}

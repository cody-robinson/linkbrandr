<?php

namespace App\AL\Services\SharedLinks;

use App\AL\ServiceDTOs\SharedLinks\LinkInfo;

// model layer dependencies
use App\Models\LBR\SharedLink;

class LinksReporter
{
    /**
     * Retrieve commonly required information about an employee.
     *
     * @param Array $parameters
     * @return Array App\AL\ServiceDTOs\SharedLinks\LinkInfo
     */
    public function getSharedLinksInfo($parameters)
    {

        $keys = array_keys($parameters);
        $matchingKeyList = array_intersect_key($parameters, get_class_vars(LinkInfo::class));

        if(count($matchingKeyList)==1)
        {
            $keyName = array_keys($matchingKeyList)[0];
            $SharedLinks = SharedLink::where($keyName, '=', $matchingKeyList[$keyName])->where('IsActive','=','1')->orderBy('DateAdded','DESC')->get();
        }


        $info = [];
        foreach($SharedLinks as $Link)
        {

            $LinkInfo = new LinkInfo();
            $LinkInfo->ID = $Link->ID;
            $LinkInfo->DateAdded = $Link->DateAdded;
            $LinkInfo->Description = $Link->Description;
            $LinkInfo->Link = $Link->Link;
            $LinkInfo->ShareType = $Link->ShareType;
            $LinkInfo->IsIframeSupported = $Link->IsIframeSupported;
            $LinkInfo->Title = $Link->Title;
            $LinkInfo->Image = $Link->Image;
            $LinkInfo->Favicon = $Link->Favicon;
            $LinkInfo->Slug = $Link->Slug;
            $LinkInfo->LBRUserProfiles_ID = $Link->LBRUserProfiles_ID;
            $info[] = $LinkInfo;


        }

        return $info;
    }



}

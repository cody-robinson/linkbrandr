<?php

namespace App\AL\Services\Users;

use App\AL\ServiceDTOs\Users\UserInfo;

// model layer dependencies
use App\Models\USR\User;
use App\Models\LBR\SharedLink;


class UserReporter
{

    /**
     * Fetch and return all user's info including it's userProfile and Person info
     *
     * @return array of UserInfo
     */
    public function fetchUsers()
    {

        $Users = User::query()->where('IsActive','=',1)->get();
        $Userlist = [];
        foreach($Users as $User){
            $UserInfo = new UserInfo();
            $UserInfo->ID = $User->ID;
            $UserInfo->PPLPeople_ID = $User->PPLPeople_ID;
            $UserInfo->IsActive = $User->IsActive;
            $UserInfo->Username = $User->Username;
            $UserInfo->Person = $User->PPLPerson;
            $UserInfo->UserProfile = (isset($User->LBRUserProfiles[0]))? $User->LBRUserProfiles[0]: null;

            if($Person = $User->PPLPerson){
                $UserInfo->FullName = $Person->FirstName.' '.$Person->LastName;
            }
            
            $UserInfo->SignupDate = date('m/d/Y',strtotime($User->DateAdded));
            
            $Userlist[] = $UserInfo;
        }

        return $Userlist;

    }

    /**
     * Fetch and return single user's info including it's userProfile and Person info
     *
     * @param $ID
     * @return UserInfo
     */
    public function fetchSingleUser($ID)
    {

        $User = User::find($ID);

        $UserInfo = new UserInfo();
        $UserInfo->ID = $User->ID;
        $UserInfo->PPLPeople_ID = $User->PPLPeople_ID;
        $UserInfo->IsActive = $User->IsActive;
        $UserInfo->Username = $User->Username;
        $UserInfo->Person = $User->PPLPerson;
        $UserInfo->UserProfile = (isset($User->LBRUserProfiles[0]))? $User->LBRUserProfiles[0]: null;
        $UserInfo->SharedLinks = ($UserInfo->UserProfile)? SharedLink::query()->where("LBRUserProfiles_ID","=",$UserInfo->UserProfile->ID)->get(): [];

        return $UserInfo;

    }


}

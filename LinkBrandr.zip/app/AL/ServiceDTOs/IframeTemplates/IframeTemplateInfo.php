<?php

namespace App\AL\ServiceDTOs\IframeTemplates;

class IframeTemplateInfo
{
    ### TODO: Document variable types in phpDoc
    public $ID;
    public $Name;
    public $CSSClassName;
}


<?php

namespace App\AL\ServiceDTOs\Users;

class UserInfo
{
    ### TODO: Document variable types in phpDoc

    public $ID;
    public $Username;
    public $PPLPeople_ID;
    public $IsActive;
    public $Person;
    public $UserProfile;
    public $SharedLinks;
    public $FullName;
    public $SignupDate;
}


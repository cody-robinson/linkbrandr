<?php

namespace App\AL\ServiceDTOs\SharedLinks;

class LinkInfo
{
    ### TODO: Document variable types in phpDoc
    public $ID;
    public $Link;
    public $LBRUserProfiles_ID;
    public $ShareType;
    public $IsIframeSupported;
    public $Description;
    public $Title;
    public $Image;
    public $Favicon;
    public $Slug;
}


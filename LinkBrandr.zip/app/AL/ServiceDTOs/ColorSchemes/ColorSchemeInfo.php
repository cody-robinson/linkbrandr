<?php

namespace App\AL\ServiceDTOs\ColorSchemes;

class ColorSchemeInfo
{
    ### TODO: Document variable types in phpDoc
    public $ID;
    public $SchemeName;
    public $Colors;

}


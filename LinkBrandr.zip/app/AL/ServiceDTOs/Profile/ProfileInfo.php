<?php

namespace App\AL\ServiceDTOs\Profile;

class ProfileInfo
{
    ### TODO: Document variable types in phpDoc

    public $UserProfile;
    public $IframeTemplate;
    public $SplashTemplate;
    public $ColorScheme;
    public $ShareLink;
    public $ShareType;
    public $IsIframeSupported;
    public $Description;
    public $Title;
    public $Image;
    public $Favicon;
    public $Slug;
    public $CSSClassName;
    public $ButtonColor;
    public $BackgroundColor;



}


<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property string SplashTempName
  * @property string SplashTempFile
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile[] LBRUserProfiles
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|SplashTemplate|SplashTemplate[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SplashTemplate findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SplashTemplate findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SplashTemplate|SplashTemplate[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static SplashTemplate|null first(array $columns = ['*'])
  * @method static SplashTemplate firstOrNew(int $attributes)
  * @method static SplashTemplate firstOrCreate(int $attributes)
  * @method static SplashTemplate firstOrFail(array $columns = ['*'])
  */

class SplashTemplate extends GModel
{
	protected $table = 'LBRSplashTemplates';


	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRUserProfiles()
	{
		return $this->hasMany('App\Models\LBR\UserProfile', 'LBRSplashTemplates_ID', 'ID');
	}





	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */

}

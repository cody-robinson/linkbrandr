<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property string BusinessName
  * @property string BusinessDescription
  * @property string Headline
  * @property string ButtonText
  * @property int USRUsers_ID
  * @property int LBRSplashTemplates_ID
  * @property int LBRIframeTemplates_ID
  * @property int LBRColorSchemes_ID
  * @property \Carbon\Carbon LastModified
  * @property \Carbon\Carbon DateAdded
  * @property string ProfileImage
  * @property string ImageType
  * @property string ImageOrientation
  * @property string SplashBackgroundImage
  * @property int LBRBackgroundImages_ID
  * @property string ProfileURL
  * @property \Carbon\Carbon AccountExpiryDate
  * @property string Birthday
  * @property string Location
  * @property string Gender
  * @property bool IsPaidSubscription
  * @property string StripeCustomerID
  * @property bool IsActive
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\USR\User USRUser
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\SplashTemplate LBRSplashTemplate
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\IframeTemplate LBRIframeTemplate
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\ColorScheme LBRColorScheme
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\BackgroundImage LBRBackgroundImage
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\SharedLink[] LBRSharedLinks
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfileTransaction[] LBRUserProfileTransactions
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfile|UserProfile[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfile findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfile findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfile|UserProfile[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static UserProfile|null first(array $columns = ['*'])
  * @method static UserProfile firstOrNew(int $attributes)
  * @method static UserProfile firstOrCreate(int $attributes)
  * @method static UserProfile firstOrFail(array $columns = ['*'])
  */

class UserProfile extends GModel
{
	protected $table = 'LBRUserProfiles';


	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function USRUser()
	{
		return $this->belongsTo('App\Models\USR\User', 'USRUsers_ID', 'ID');
	}

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRSplashTemplate()
	{
		return $this->belongsTo('App\Models\LBR\SplashTemplate', 'LBRSplashTemplates_ID', 'ID');
	}

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRIframeTemplate()
	{
		return $this->belongsTo('App\Models\LBR\IframeTemplate', 'LBRIframeTemplates_ID', 'ID');
	}

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRColorScheme()
	{
		return $this->belongsTo('App\Models\LBR\ColorScheme', 'LBRColorSchemes_ID', 'ID');
	}

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRBackgroundImage()
	{
		return $this->belongsTo('App\Models\LBR\BackgroundImage', 'LBRBackgroundImages_ID', 'ID');
	}


	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRSharedLinks()
	{
		return $this->hasMany('App\Models\LBR\SharedLink', 'LBRUserProfiles_ID', 'ID');
	}

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRUserProfileTransactions()
	{
		return $this->hasMany('App\Models\LBR\UserProfileTransaction', 'LBRUserProfiles_ID', 'ID');
	}





	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */

}

<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property int LBRUserProfiles_ID
  * @property decimal(5,2) Amount
  * @property string StripeReply
  * @property \Carbon\Carbon LastModified
  * @property \Carbon\Carbon DateAdded
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile LBRUserProfile
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfileTransaction|UserProfileTransaction[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfileTransaction findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfileTransaction findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserProfileTransaction|UserProfileTransaction[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static UserProfileTransaction|null first(array $columns = ['*'])
  * @method static UserProfileTransaction firstOrNew(int $attributes)
  * @method static UserProfileTransaction firstOrCreate(int $attributes)
  * @method static UserProfileTransaction firstOrFail(array $columns = ['*'])
  */

class UserProfileTransaction extends GModel
{
	protected $table = 'LBRUserProfileTransactions';

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRUserProfile()
	{
		return $this->belongsTo('App\Models\LBR\UserProfile', 'LBRUserProfiles_ID', 'ID');
	}






	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */

}

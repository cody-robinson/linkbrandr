<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property string Link
  * @property int LBRUserProfiles_ID
  * @property string Description
  * @property string ShareType
  * @property bool IsIframeSupported
  * @property string Title
  * @property string Slug
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon LastModified
  * @property bool IsActive
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile LBRUserProfile
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|SharedLink|SharedLink[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SharedLink findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SharedLink findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|SharedLink|SharedLink[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static SharedLink|null first(array $columns = ['*'])
  * @method static SharedLink firstOrNew(int $attributes)
  * @method static SharedLink firstOrCreate(int $attributes)
  * @method static SharedLink firstOrFail(array $columns = ['*'])
  */

class SharedLink extends GModel
{
	protected $table = 'LBRSharedLinks';

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
	public function LBRUserProfile()
	{
		return $this->belongsTo('App\Models\LBR\UserProfile', 'LBRUserProfiles_ID', 'ID');
	}






	/* Custom Code Start :: Do not alter this comment! */

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'ShareType',
        'Slug',
        'IsActive'
    ];

	/* Custom Code End :: Do not alter this comment!  */

}

<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property string SchemeName
  * @property string Colors
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile[] LBRUserProfiles
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|ColorScheme|ColorScheme[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|ColorScheme findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|ColorScheme findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|ColorScheme|ColorScheme[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static ColorScheme|null first(array $columns = ['*'])
  * @method static ColorScheme firstOrNew(int $attributes)
  * @method static ColorScheme firstOrCreate(int $attributes)
  * @method static ColorScheme firstOrFail(array $columns = ['*'])
  */

class ColorScheme extends GModel
{
	protected $table = 'LBRColorSchemes';


	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRUserProfiles()
	{
		return $this->hasMany('App\Models\LBR\UserProfile', 'LBRColorSchemes_ID', 'ID');
	}





	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */

}

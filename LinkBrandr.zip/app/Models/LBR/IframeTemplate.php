<?php

namespace App\Models\LBR;

use Grav\Database\Eloquent\GModel;

/**
  * @property int ID
  * @property string Name
  * @property string CSSClassName
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile[] LBRUserProfiles
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|IframeTemplate|IframeTemplate[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|IframeTemplate findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|IframeTemplate findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|IframeTemplate|IframeTemplate[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static IframeTemplate|null first(array $columns = ['*'])
  * @method static IframeTemplate firstOrNew(int $attributes)
  * @method static IframeTemplate firstOrCreate(int $attributes)
  * @method static IframeTemplate firstOrFail(array $columns = ['*'])
  */

class IframeTemplate extends GModel
{
	protected $table = 'LBRIframeTemplates';


	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRUserProfiles()
	{
		return $this->hasMany('App\Models\LBR\UserProfile', 'LBRIframeTemplates_ID', 'ID');
	}





	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */

}

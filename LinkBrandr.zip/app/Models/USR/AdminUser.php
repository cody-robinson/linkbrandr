<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Username
  * @property string Password
  * @property int PPLPeople_ID
  * @property bool IsActive
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon LastModified
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUser|AdminUser[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUser findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUser findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUser|AdminUser[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUser|null first(array $columns = ['*'])
  * @method static AdminUser firstOrNew(int $attributes)
  * @method static AdminUser firstOrCreate(int $attributes)
  * @method static AdminUser firstOrFail(array $columns = ['*'])
  */

class AdminUser extends \Grav\Models\USR\AdminUser
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminUsers_ID
  * @property string Domain
  * @property string Path
  * @property \Carbon\Carbon DateAdded
  * @property string Request
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLog|AdminUserAuditLog[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLog findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLog findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLog|AdminUserAuditLog[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUserAuditLog|null first(array $columns = ['*'])
  * @method static AdminUserAuditLog firstOrNew(int $attributes)
  * @method static AdminUserAuditLog firstOrCreate(int $attributes)
  * @method static AdminUserAuditLog firstOrFail(array $columns = ['*'])
  */

class AdminUserAuditLog extends \Grav\Models\USR\AdminUserAuditLog
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property string Path
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLogPath|AdminUserAuditLogPath[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLogPath findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLogPath findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuditLogPath|AdminUserAuditLogPath[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUserAuditLogPath|null first(array $columns = ['*'])
  * @method static AdminUserAuditLogPath firstOrNew(int $attributes)
  * @method static AdminUserAuditLogPath firstOrCreate(int $attributes)
  * @method static AdminUserAuditLogPath firstOrFail(array $columns = ['*'])
  */

class AdminUserAuditLogPath extends \Grav\Models\USR\AdminUserAuditLogPath
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

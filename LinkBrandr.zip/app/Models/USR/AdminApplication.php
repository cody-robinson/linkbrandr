<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Application
  * @property string Label
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplication|AdminApplication[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplication findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplication findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplication|AdminApplication[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminApplication|null first(array $columns = ['*'])
  * @method static AdminApplication firstOrNew(int $attributes)
  * @method static AdminApplication firstOrCreate(int $attributes)
  * @method static AdminApplication firstOrFail(array $columns = ['*'])
  */

class AdminApplication extends \Grav\Models\USR\AdminApplication
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

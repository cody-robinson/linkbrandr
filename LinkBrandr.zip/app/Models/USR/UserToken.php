<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRUsers_ID
  * @property string Token
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon ExpiryDate
  * @property \Carbon\Carbon LastModified
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|UserToken|UserToken[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserToken findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserToken findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserToken|UserToken[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static UserToken|null first(array $columns = ['*'])
  * @method static UserToken firstOrNew(int $attributes)
  * @method static UserToken firstOrCreate(int $attributes)
  * @method static UserToken firstOrFail(array $columns = ['*'])
  */

class UserToken extends \Grav\Models\USR\UserToken
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

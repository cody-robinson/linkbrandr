<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Username
  * @property string Message
  * @property \Carbon\Carbon DateAdded
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuthLog|AdminUserAuthLog[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuthLog findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuthLog findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserAuthLog|AdminUserAuthLog[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUserAuthLog|null first(array $columns = ['*'])
  * @method static AdminUserAuthLog firstOrNew(int $attributes)
  * @method static AdminUserAuthLog firstOrCreate(int $attributes)
  * @method static AdminUserAuthLog firstOrFail(array $columns = ['*'])
  */

class AdminUserAuthLog extends \Grav\Models\USR\AdminUserAuthLog
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

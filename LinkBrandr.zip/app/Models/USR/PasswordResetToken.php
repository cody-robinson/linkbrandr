<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRUsers_ID
  * @property string PasswordToken
  * @property bool HasBeenReset
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon ExpiryDate
  * @property \Carbon\Carbon LastModified
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|PasswordResetToken|PasswordResetToken[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|PasswordResetToken findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|PasswordResetToken findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|PasswordResetToken|PasswordResetToken[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static PasswordResetToken|null first(array $columns = ['*'])
  * @method static PasswordResetToken firstOrNew(int $attributes)
  * @method static PasswordResetToken firstOrCreate(int $attributes)
  * @method static PasswordResetToken firstOrFail(array $columns = ['*'])
  */

class PasswordResetToken extends \Grav\Models\USR\PasswordResetToken
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

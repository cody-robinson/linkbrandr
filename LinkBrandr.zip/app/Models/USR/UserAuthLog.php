<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Username
  * @property string Message
  * @property \Carbon\Carbon DateAdded
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|UserAuthLog|UserAuthLog[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserAuthLog findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserAuthLog findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserAuthLog|UserAuthLog[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static UserAuthLog|null first(array $columns = ['*'])
  * @method static UserAuthLog firstOrNew(int $attributes)
  * @method static UserAuthLog firstOrCreate(int $attributes)
  * @method static UserAuthLog firstOrFail(array $columns = ['*'])
  */

class UserAuthLog extends \Grav\Models\USR\UserAuthLog
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminUsers_ID
  * @property string Token
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon ExpiryDate
  * @property \Carbon\Carbon LastModified
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserToken|AdminUserToken[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserToken findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserToken findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserToken|AdminUserToken[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUserToken|null first(array $columns = ['*'])
  * @method static AdminUserToken firstOrNew(int $attributes)
  * @method static AdminUserToken firstOrCreate(int $attributes)
  * @method static AdminUserToken firstOrFail(array $columns = ['*'])
  */

class AdminUserToken extends \Grav\Models\USR\AdminUserToken
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

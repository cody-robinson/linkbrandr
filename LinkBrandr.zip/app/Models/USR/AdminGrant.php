<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminUsers_ID
  * @property int USRAdminApplications_ID
  * @property int USRAdminPermissions_ID
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminGrant|AdminGrant[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminGrant findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminGrant findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminGrant|AdminGrant[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminGrant|null first(array $columns = ['*'])
  * @method static AdminGrant firstOrNew(int $attributes)
  * @method static AdminGrant firstOrCreate(int $attributes)
  * @method static AdminGrant firstOrFail(array $columns = ['*'])
  */

class AdminGrant extends \Grav\Models\USR\AdminGrant
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Username
  * @property string Password
  * @property int PPLPeople_ID
  * @property bool IsActive
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon LastModified
  * @property string remember_token
  * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\LBR\UserProfile[] LBRUserProfiles
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|User|User[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|User findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|User findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|User|User[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static User|null first(array $columns = ['*'])
  * @method static User firstOrNew(int $attributes)
  * @method static User firstOrCreate(int $attributes)
  * @method static User firstOrFail(array $columns = ['*'])
  */

class User extends \Grav\Models\USR\User
{

	/**
     * @returns \Illuminate\Database\Eloquent\Relations\HasMany
     */
	public function LBRUserProfiles()
	{
		return $this->hasMany('App\Models\LBR\UserProfile', 'USRUsers_ID', 'ID');
	}

	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminRoles_ID
  * @property int USRAdminApplications_ID
  * @property int USRAdminPermissions_ID
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRoleGrant|AdminRoleGrant[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRoleGrant findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRoleGrant findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRoleGrant|AdminRoleGrant[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminRoleGrant|null first(array $columns = ['*'])
  * @method static AdminRoleGrant firstOrNew(int $attributes)
  * @method static AdminRoleGrant firstOrCreate(int $attributes)
  * @method static AdminRoleGrant firstOrFail(array $columns = ['*'])
  */

class AdminRoleGrant extends \Grav\Models\USR\AdminRoleGrant
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

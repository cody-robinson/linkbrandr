<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminApplications_ID
  * @property int USRAdminPermissions_ID
  * @property bool Locked
  * @property string Description
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplicationPermission|AdminApplicationPermission[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplicationPermission findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplicationPermission findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminApplicationPermission|AdminApplicationPermission[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminApplicationPermission|null first(array $columns = ['*'])
  * @method static AdminApplicationPermission firstOrNew(int $attributes)
  * @method static AdminApplicationPermission firstOrCreate(int $attributes)
  * @method static AdminApplicationPermission firstOrFail(array $columns = ['*'])
  */

class AdminApplicationPermission extends \Grav\Models\USR\AdminApplicationPermission
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

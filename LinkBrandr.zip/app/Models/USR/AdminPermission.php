<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Permission
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminPermission|AdminPermission[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminPermission findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminPermission findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminPermission|AdminPermission[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminPermission|null first(array $columns = ['*'])
  * @method static AdminPermission firstOrNew(int $attributes)
  * @method static AdminPermission firstOrCreate(int $attributes)
  * @method static AdminPermission firstOrFail(array $columns = ['*'])
  */

class AdminPermission extends \Grav\Models\USR\AdminPermission
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

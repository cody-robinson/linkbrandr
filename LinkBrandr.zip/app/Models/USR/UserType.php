<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string UserType
  * @property bool EditAllowed
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|UserType|UserType[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserType findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserType findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|UserType|UserType[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static UserType|null first(array $columns = ['*'])
  * @method static UserType firstOrNew(int $attributes)
  * @method static UserType firstOrCreate(int $attributes)
  * @method static UserType firstOrFail(array $columns = ['*'])
  */

class UserType extends \Grav\Models\USR\UserType
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property string Label
  * @property bool IsActive
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRole|AdminRole[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRole findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRole findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminRole|AdminRole[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminRole|null first(array $columns = ['*'])
  * @method static AdminRole firstOrNew(int $attributes)
  * @method static AdminRole firstOrCreate(int $attributes)
  * @method static AdminRole firstOrFail(array $columns = ['*'])
  */

class AdminRole extends \Grav\Models\USR\AdminRole
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

<?php

namespace App\Models\USR;

/**
  * @property int ID
  * @property int USRAdminUsers_ID
  * @property int USRAdminRoles_ID
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserRole|AdminUserRole[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserRole findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserRole findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|AdminUserRole|AdminUserRole[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static AdminUserRole|null first(array $columns = ['*'])
  * @method static AdminUserRole firstOrNew(int $attributes)
  * @method static AdminUserRole firstOrCreate(int $attributes)
  * @method static AdminUserRole firstOrFail(array $columns = ['*'])
  */

class AdminUserRole extends \Grav\Models\USR\AdminUserRole
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}

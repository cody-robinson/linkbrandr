<?php

namespace App\Models\PPL;

/**
  * @property int ID
  * @property int PPLSalutations_ID
  * @property string FirstName
  * @property string MiddleInitial
  * @property string LastName
  * @property string Title
  * @property string PrimaryEmail
  * @property string PrimaryPhone
  * @property \Carbon\Carbon DateAdded
  * @property \Carbon\Carbon LastModified
  * @property bool IsActive
  * 
  * -- Code Completion Helpers --  
  * @method static \Illuminate\Database\Eloquent\Collection|Person|Person[]|null find(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|Person findMany(int $ids, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|Person findOrFail(int $id, array $columns = ['*'])
  * @method static \Illuminate\Database\Eloquent\Collection|Person|Person[]|null findOrNew(int $id, array $columns = ['*'])
  * @method static Person|null first(array $columns = ['*'])
  * @method static Person firstOrNew(int $attributes)
  * @method static Person firstOrCreate(int $attributes)
  * @method static Person firstOrFail(array $columns = ['*'])
  */

class Person extends \Grav\Models\PPL\Person
{



	/* Custom Code Start :: Do not alter this comment! *//* Custom Code End :: Do not alter this comment!  */
}
